package com.example.barci.domain;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "Player")
public class Player extends EntityID<Long> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "alias", nullable = false, unique = true)
    private String alias;

    public Player() { }

    public Player(Long id, String alias) {
        setId(id);
        this.alias = alias;
    }

    public Player(String alias) {
        this.alias = alias;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    @Override
    public String toString() {
        return "Player{" +
                "id=" + getId() +
                ", alias='" + alias + '\'' +
                '}';
    }
}