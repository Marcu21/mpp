package com.example.barci.networking;

public interface IGameObserver {
    void scoreboardUpdated();
}