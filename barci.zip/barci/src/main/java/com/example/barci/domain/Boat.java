package com.example.barci.domain;

import java.io.Serializable;

public class Boat extends EntityID<Long> implements Serializable {

    private Long id;

    public Boat() {}

    public Boat(Long id) {
        setId(id);
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Boat{" +
                "id=" + id +
                '}';
    }
}
