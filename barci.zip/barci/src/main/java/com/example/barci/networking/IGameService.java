package com.example.barci.networking;

import com.example.barci.domain.Game;
import com.example.barci.domain.GameAttempt;
import com.example.barci.domain.BoatPosition;
import com.example.barci.domain.dto.GameResultDTO;

import java.util.List;

public interface IGameService {
    void addObserver(IGameObserver observer);
    void removeObserver(IGameObserver observer);

    Game startGame(String alias);
    String makeAttempt(Long gameId, int row, int col);

    List<GameResultDTO> getResultsForAllPlayers();
    List<GameResultDTO> getDetailedResultsForPlayer(String alias);
    List<GameAttempt> getAttemptsForGame(Long gameId);
    List<BoatPosition> getBoatPositionForGame(Long gameId);
}
