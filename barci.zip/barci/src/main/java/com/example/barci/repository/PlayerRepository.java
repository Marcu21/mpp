package com.example.barci.repository;

import com.example.barci.domain.Player;

public interface PlayerRepository extends Repository<Player, Long> {
}