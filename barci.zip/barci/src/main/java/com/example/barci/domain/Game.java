package com.example.barci.domain;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "Game")
public class Game extends EntityID<Long> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "player_id", nullable = false)
    private Long playerId;

    @Column(name = "boat_id", nullable = false)
    private Long boatId;

    @Column(nullable = false)
    private int score;

    @Column(nullable = false)
    private LocalDateTime startTime;

    private LocalDateTime endTime;

    public Game() {}

    public Game(Long id, Long playerId, Long boatId, int score, LocalDateTime startTime, LocalDateTime endTime) {
        setId(id);
        this.playerId = playerId;
        this.boatId = boatId;
        this.score = score;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public Game(Long playerId, Long boatId, LocalDateTime startTime) {
        this.playerId = playerId;
        this.boatId = boatId;
        this.startTime = startTime;
        this.score = 0;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Long getPlayerId() {
        return playerId;
    }

    public void setPlayerId(Long playerId) {
        this.playerId = playerId;
    }

    public Long getBoatId() { return boatId; }

    public void setBoatId(Long boatId) { this.boatId = boatId; }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }
}
