package com.example.barci.domain.dto;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

public class GameResultDTO implements Serializable {

    private Long gameId;
    private String alias;
    private int score;
    private LocalDateTime startTime;
    private int guessed;

    private List<PosDTO> boatPosition;
    private List<PosDTO> attempts;

    public GameResultDTO(Long gameId,
                         String alias,
                         int score,
                         LocalDateTime startTime,
                         int guessed,
                         List<PosDTO> boatPosition,
                         List<PosDTO> attempts) {
        this.gameId = gameId;
        this.alias = alias;
        this.score = score;
        this.startTime = startTime;
        this.guessed = guessed;
        this.boatPosition = boatPosition;
        this.attempts = attempts;
    }

    public Long getGameId() { return gameId; }
    public String getAlias() { return alias; }
    public int getScore() { return score; }
    public LocalDateTime getStartTime() { return startTime; }
    public int getGuessed() { return guessed; }
    public List<PosDTO> getBoatPosition() { return boatPosition; }
    public List<PosDTO> getAttempts() { return attempts; }

    public static class PosDTO implements Serializable {
        private int row;
        private int col;

        public PosDTO() {}

        public PosDTO(int row, int col) {
            this.row = row;
            this.col = col;
        }
        public int getRow() { return row; }
        public void setRow(int row) {this.row = row;}

        public int getCol() { return col; }
        public void setCol(int col) {this.col = col;}
    }
}
