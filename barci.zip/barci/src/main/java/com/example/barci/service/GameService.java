package com.example.barci.service;

import com.example.barci.domain.*;
import com.example.barci.domain.dto.GameResultDTO;
import com.example.barci.domain.dto.RestDTO;
import com.example.barci.networking.IGameObserver;
import com.example.barci.networking.IGameService;
import com.example.barci.repository.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

public class GameService implements IGameService {

    private final PlayerRepository playerRepo;
    private final GameRepository gameRepo;
    private final GameAttemptRepository attemptRepo;
    private final BoatRepository boatRepo;
    private final BoatPositionRepository boatPositionRepo;
    private final List<IGameObserver> observers = new ArrayList<>();

    private final Random random = new Random();

    public GameService(PlayerRepository playerRepo,
                       GameRepository gameRepo,
                       GameAttemptRepository attemptRepo,
                       BoatRepository boatRepo,
                       BoatPositionRepository boatPositionRepo) {
        this.playerRepo = playerRepo;
        this.gameRepo = gameRepo;
        this.attemptRepo = attemptRepo;
        this.boatRepo = boatRepo;
        this.boatPositionRepo = boatPositionRepo;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        observers.remove(observer);
    }

    @Override
    public Game startGame(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            player = new Player(null, alias);
            playerRepo.add(player);
        }

        List<Boat> boats = (List<Boat>) boatRepo.findAll();
        if (boats.isEmpty()) {
            throw new RuntimeException("Nu exista configuratii Boat.");
        }
        Boat chosenBoat = boats.get(random.nextInt(boats.size()));

        Game game = new Game(player.getId(), chosenBoat.getId(), LocalDateTime.now());
        gameRepo.add(game);

        return game;
    }

    @Override
    public String makeAttempt(Long gameId, int row, int col) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }

        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId) && a.getRow() == row && a.getCol() == col) {
                return "Ai incercat deja aceasta pozitie!";
            }
        }

        String result = procesareBarca(game, row, col);

        if (getAttemptsForGame(gameId).size() == 3) {
            game.setEndTime(LocalDateTime.now());
        }

        gameRepo.update(game);

        if (game.getEndTime() != null) {
            notifyGameFinished();
            return buildEndMessage(result, gameId);
        }

        return result;
    }


    private String procesareBarca(Game game, int row, int col) {
        Long boatId = game.getBoatId();
        Long gameId = game.getId();

        int dist = distanceToBoat(boatId, row, col);

        if (dist == 0) {
            GameAttempt attempt = new GameAttempt(gameId, row, col, 1);
            game.setScore(game.getScore() + 5);
            attemptRepo.add(attempt);
            return "Ai nimerit o parte din barca!";
        } else {
            GameAttempt attempt = new GameAttempt(gameId, row, col, 0);
            game.setScore(game.getScore() - 3);
            attemptRepo.add(attempt);
            return "Ai ratat. Distanta euclidiana pana la barca este: " + dist;
        }
    }




    private int distanceToBoat(Long boatId, int row, int col) {

        double minDist = Double.MAX_VALUE;

        for (BoatPosition bp : boatPositionRepo.findAll()) {
            if (!bp.getBoatId().equals(boatId))
                continue;

            if (bp.getRow() == row && bp.getCol() == col) {
                return 0;
            }

            double d = Math.sqrt(
                    Math.pow(bp.getRow() - row, 2) +
                            Math.pow(bp.getCol() - col, 2));

            if (d < minDist) {
                minDist = d;
            }
        }

        return (int) Math.round(minDist);
    }

    private String buildEndMessage(String baseMessage, Long gameId) {
        StringBuilder sb = new StringBuilder(baseMessage);
        sb.append("\nBarca a fost la: ");
        Game game =  gameRepo.findById(gameId);

        Long boatId = game.getBoatId();
        for (BoatPosition b : boatPositionRepo.findAll()) {
            if (b.getBoatId().equals(boatId)) {
                sb.append("(").append(b.getRow()).append(",").append(b.getCol()).append(") ");
            }
        }
        sb.append("\nPunctaj: ").append(game.getScore());

        return sb.toString();
    }


    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getEndTime() != null) {
                Player p = playerRepo.findById(g.getPlayerId());
                results.add(new GameResultDTO(g.getId(), p.getAlias(), g.getScore(), g.getStartTime(), countGuessedForGame(g.getId()), new ArrayList<>(), new ArrayList<>()));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Integer.compare(a.getGuessed(), b.getGuessed());
        });
        return results;
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) throw new RuntimeException("Jucator inexistent.");

        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getPlayerId().equals(player.getId()) && g.getEndTime() != null) {

                List<GameResultDTO.PosDTO> boats = new ArrayList<>();
                for (BoatPosition b : boatPositionRepo.findAll()) {
                    if (b.getBoatId().equals(g.getBoatId())) {
                        boats.add(new GameResultDTO.PosDTO(b.getRow(), b.getCol()));
                    }
                }

                List<GameResultDTO.PosDTO> attempts = new ArrayList<>();
                for (GameAttempt a : attemptRepo.findAll()) {
                    if (a.getGameId().equals(g.getId())) {
                        attempts.add(new GameResultDTO.PosDTO(a.getRow(), a.getCol()));
                    }
                }

                results.add(new GameResultDTO(g.getId(), alias, g.getScore(), g.getStartTime(), countGuessedForGame(g.getId()), boats, attempts));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Integer.compare(a.getGuessed(), b.getGuessed());
        });
        return results;
    }

    @Override
    public List<GameAttempt> getAttemptsForGame(Long gameId) {
        List<GameAttempt> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId)) {
                attempts.add(a);
            }
        }
        return attempts;
    }

    @Override
    public List<BoatPosition> getBoatPositionForGame(Long gameId) {
        Game game  = gameRepo.findById(gameId);
        List<BoatPosition> boatPositions = new ArrayList<>();
        for (BoatPosition b : boatPositionRepo.findAll()) {
            if (b.getBoatId().equals(game.getBoatId())) {
                boatPositions.add(b);
            }
        }
        return boatPositions;
    }

    private void notifyGameFinished() {
        for (IGameObserver observer : observers) {
            try {
                observer.scoreboardUpdated();
            } catch (Exception e) {
                System.err.println("Eroare notificare: " + e.getMessage());
            }
        }
    }

    public Boat addBoat(List<GameResultDTO.PosDTO> positions) {
        if (positions == null || positions.size() != 3) {
            throw new RuntimeException("Trebuie exact 3 pozitii");
        }

        int r1 = positions.get(0).getRow(), c1 = positions.get(0).getCol();
        int r2 = positions.get(1).getRow(), c2 = positions.get(1).getCol();
        int r3 = positions.get(2).getRow(), c3 = positions.get(2).getCol();

        if ((r1 == r2 && c1 == c2) || (r1 == r3 && c1 == c3) || (r2 == r3 && c2 == c3)) {
            throw new RuntimeException("Pozitiile trebuie sa fie distincte");
        }

        if (!isValid(r1, c1) || !isValid(r2, c2) || !isValid(r3, c3)) {
            throw new RuntimeException("Pozitiile trebuie sa fie in intervalul [1,5]");
        }

        boolean linie = r1 == r2 && r2 == r3;
        boolean coloana = c1 == c2 && c2 == c3;

        if (!linie && !coloana) {
            throw new RuntimeException("Pozitiile nu sunt pe aceeasi linie sau coloana");
        }

        if (linie) {
            if (!suntConsecutive(c1, c2, c3)) {
                throw new RuntimeException("Pozitiile nu sunt consecutive pe linie");
            }
        } else {
            if (!suntConsecutive(r1, r2, r3)) {
                throw new RuntimeException("Pozitiile nu sunt consecutive pe coloana");
            }
        }

        Boat boat = new Boat();
        boatRepo.add(boat);
        Long boatId = boat.getId();

        for (GameResultDTO.PosDTO p : positions) {
            boatPositionRepo.add(new BoatPosition(boatId, p.getRow(), p.getCol()));
        }

        return boat;
    }


    private boolean isValid(int row, int col) {
        return row >= 1 && row <= 5 && col >= 1 && col <= 5;
    }

    private boolean suntConsecutive(int a, int b, int c) {
        return (a == b - 1 && b == c - 1) ||
                (b == a - 1 && a == c - 1) ||
                (a == c - 1 && c == b - 1);
    }


    public int countGuessedForGame(Long gameId) {
        List<GameAttempt> attempts = getAttemptsForGame(gameId);
        int guessed = 0;
        for (GameAttempt a : attempts) {
            if (a.getGameId().equals(gameId) && a.getGuessed() == 1) {
                guessed++;
            }
        }
        return guessed;
    }


    public List<RestDTO> getAllBoats() {
        List<RestDTO> restBoats = new ArrayList<>();
        for (Boat b : boatRepo.findAll()) {
            List<GameResultDTO.PosDTO> positions = new ArrayList<>();
            for (BoatPosition bp : boatPositionRepo.findAll()) {
                if (bp.getBoatId().equals(b.getId())) {
                    positions.add(new GameResultDTO.PosDTO(bp.getRow(), bp.getCol()));
                }
            }
            restBoats.add(new RestDTO(positions));
        }
        return restBoats;
    }
}
