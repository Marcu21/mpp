package com.example.barci.utils;

import com.example.barci.repository.*;
import com.example.barci.repository.db.BoatDBRepository;
import com.example.barci.repository.db.GameAttemptDBRepository;
import com.example.barci.repository.hibernate.HibernateGameRepository;
import com.example.barci.repository.db.BoatPositionDBRepository;
import com.example.barci.repository.hibernate.HibernatePlayerRepository;
import com.example.barci.service.GameService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public PlayerRepository playerRepository() {
        return new HibernatePlayerRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public BoatRepository boatRepository() {return new BoatDBRepository();}

    @Bean
    public BoatPositionRepository boatPositionRepository() {return new BoatPositionDBRepository();}

    @Bean
    public GameAttemptRepository gameAttemptRepository() {
        return new GameAttemptDBRepository();
    }

    @Bean
    public GameRepository gameRepository() {
        return new HibernateGameRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public GameService gameService() {
        return new GameService(
                playerRepository(),
                gameRepository(),
                gameAttemptRepository(),
                boatRepository(),
                boatPositionRepository()
        );
    }
}
