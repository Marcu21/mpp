package com.example.barci.repository.db;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.example.barci.domain.BoatPosition;
import com.example.barci.repository.BoatPositionRepository;
import com.example.barci.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class BoatPositionDBRepository implements BoatPositionRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public BoatPositionDBRepository() {
        logger.info("Initializing BoatPositionRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(BoatPosition boatPosition) {
        logger.traceEntry("Saving boatPosition {}", boatPosition);
        String sql = "INSERT INTO BoatPosition (boat_id, row, col) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setLong(1, boatPosition.getBoatId());
            stmt.setInt(2, boatPosition.getRow());
            stmt.setInt(3, boatPosition.getCol());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    boatPosition.setId(keys.getLong(1));
                }
            }

            logger.trace("Saved {}", boatPosition);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }

        logger.traceExit();
    }

    @Override
    public Iterable<BoatPosition> findAll() {
        logger.traceEntry();
        List<BoatPosition> boatPositions = new ArrayList<>();
        String sql = "SELECT * FROM BoatPosition";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                BoatPosition boatPosition = extractBoatPosition(rs);
                boatPositions.add(boatPosition);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(boatPositions);
        return boatPositions;
    }

    @Override
    public void delete(BoatPosition boatPosition) {
        logger.traceEntry("Deleting boatPosition {}", boatPosition);
        String sql = "DELETE FROM BoatPosition WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, boatPosition.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", boatPosition);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public void update(BoatPosition boatPosition) {
        logger.traceEntry("Updating boatPosition {}", boatPosition);
        String sql = "UPDATE BoatPosition SET boat_id=?, row=?, col=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, boatPosition.getBoatId());
            stmt.setInt(2, boatPosition.getRow());
            stmt.setInt(3, boatPosition.getCol());
            stmt.setLong(4, boatPosition.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", boatPosition);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public BoatPosition findById(Long id) {
        logger.traceEntry("Finding boatPosition by id {}", id);
        String sql = "SELECT * FROM BoatPosition WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    BoatPosition boatPosition = extractBoatPosition(rs);
                    logger.traceExit(boatPosition);
                    return boatPosition;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<BoatPosition> getAll() {
        return (Collection<BoatPosition>) findAll();
    }

    private BoatPosition extractBoatPosition(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        Long boatId = rs.getLong("boat_id");
        int row = rs.getInt("row");
        int col = rs.getInt("col");
        return new BoatPosition(id, boatId, row, col);
    }
}
