package com.example.barci.server;

import com.example.barci.networking.RequestHandler;
import com.example.barci.repository.GameAttemptRepository;
import com.example.barci.repository.GameRepository;
import com.example.barci.repository.PlayerRepository;
import com.example.barci.repository.BoatRepository;
import com.example.barci.repository.BoatPositionRepository;
import com.example.barci.repository.db.*;
import com.example.barci.repository.hibernate.HibernatePlayerRepository;
import com.example.barci.repository.hibernate.HibernateGameRepository;
import com.example.barci.service.GameService;
import com.example.barci.utils.HibernateUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    private static final int PORT = 5555;

    public static void main(String[] args) {
        PlayerRepository playerRepo   = new HibernatePlayerRepository(HibernateUtil.getSessionFactory());
        BoatRepository boatRepo     = new BoatDBRepository();
        GameRepository gameRepo     = new HibernateGameRepository(HibernateUtil.getSessionFactory());
        GameAttemptRepository attemptRepo = new GameAttemptDBRepository();
        BoatPositionRepository boatPositionRepo = new BoatPositionDBRepository();

        GameService service = new GameService(playerRepo, gameRepo, attemptRepo, boatRepo, boatPositionRepo);

        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket client = server.accept();
                new Thread(new RequestHandler(service, client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
