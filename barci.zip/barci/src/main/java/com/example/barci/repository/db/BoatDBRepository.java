package com.example.barci.repository.db;

import com.example.barci.domain.Boat;
import com.example.barci.repository.BoatRepository;
import com.example.barci.utils.JdbcUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class BoatDBRepository implements BoatRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public BoatDBRepository() {
        logger.info("Initializing BoatRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(Boat boat) {
        logger.traceEntry("Saving boat {}", boat);
        String sql = "INSERT INTO Boat DEFAULT VALUES";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    boat.setId(keys.getLong(1));
                }
            }

            logger.trace("Saved {}", boat);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }

        logger.traceExit();
    }

    @Override
    public Iterable<Boat> findAll() {
        logger.traceEntry();
        List<Boat> boats = new ArrayList<>();
        String sql = "SELECT * FROM Boat";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Boat boat = extractBoat(rs);
                boats.add(boat);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(boats);
        return boats;
    }

    @Override
    public void delete(Boat boat) {
        logger.traceEntry("Deleting boat {}", boat);
        String sql = "DELETE FROM Boat WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, boat.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", boat);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public void update(Boat boat) {
        logger.traceEntry("Updating boat {}", boat);
        logger.traceExit();
    }

    @Override
    public Boat findById(Long id) {
        logger.traceEntry("Finding boat by id {}", id);
        String sql = "SELECT * FROM Boat WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Boat boat = extractBoat(rs);
                    logger.traceExit(boat);
                    return boat;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Boat> getAll() {
        return (Collection<Boat>) findAll();
    }

    private Boat extractBoat(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        return new Boat(id);
    }
}
