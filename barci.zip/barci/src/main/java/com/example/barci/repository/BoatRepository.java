package com.example.barci.repository;

import com.example.barci.domain.Boat;

public interface BoatRepository extends Repository<Boat, Long>{
}
