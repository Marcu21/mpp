package com.example.barci.controller;

import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import com.example.barci.domain.Game;
import com.example.barci.domain.dto.GameResultDTO;
import com.example.barci.networking.GameServiceProxy;
import com.example.barci.networking.IGameObserver;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class GameController implements IGameObserver {

    @FXML private TextField aliasField;
    @FXML private TextArea messageArea;
    @FXML private GridPane grid;

    @FXML private TableView<GameResultDTO> leaderboardTable;
    @FXML private TableColumn<GameResultDTO, String> colAlias;
    @FXML private TableColumn<GameResultDTO, Integer> colScore;
    @FXML private TableColumn<GameResultDTO, String> colStart;
    @FXML private TableColumn<GameResultDTO, Integer> colGuessed;

    private final GameServiceProxy service = new GameServiceProxy("localhost", 5555);

    private Long currentGameId = null;
    private String currentAlias = null;

    @FXML
    public void initialize() {
        initLeaderboardTable();
        populateGrid();
    }

    private void initLeaderboardTable() {
        colAlias.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAlias()));
        colScore.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getScore()));
        colStart.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().getStartTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")))
        );
        colGuessed.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getGuessed()));
    }

    private void populateGrid() {
        grid.getChildren().clear();

        for (int r = 1; r <= 5; r++) {
            for (int c = 1; c <= 5; c++) {
                Button btn = new Button(r + "," + c);
                btn.setPrefSize(60, 60);
                final int row = r;
                final int col = c;
                btn.setOnAction(ev -> handleMove(row, col));
                grid.add(btn, c - 1, r - 1);
            }
        }
    }

    @FXML
    public void handleStartGame() {
        int ok = 1;
        if (currentAlias != null)
        {
            ok = 0;
        }
        currentAlias = aliasField.getText().trim();
        if (currentAlias.isEmpty()) {
            messageArea.setText("Introdu un alias valid.");
            return;
        }

        try {
            if( ok == 1) {
                service.addObserver(this);
            }
            Game game = service.startGame(currentAlias);
            this.currentGameId = game.getId();
            messageArea.setText("Joc pornit!");

            updateLeaderboard();
        } catch (Exception e) {
            messageArea.setText("Eroare la pornirea jocului: " + e.getMessage());
        }
    }

    private void handleMove(int row, int col) {
        if (currentGameId == null) {
            messageArea.setText("Mai intai porneste un joc.");
            return;
        }

        try {
            String result = service.makeAttempt(currentGameId, row, col);
            messageArea.setText(result);

            if (result.contains("Punctaj")) {
                currentGameId = null;
                updateLeaderboard();
            }

        } catch (Exception e) {
            messageArea.setText("Eroare la mutare: " + e.getMessage());
        }
    }

    private void updateLeaderboard() {
        try {
            List<GameResultDTO> results = service.getResultsForAllPlayers();
            leaderboardTable.getItems().setAll(results);
        } catch (Exception e) {
            messageArea.setText("Eroare la actualizarea clasamentului: " + e.getMessage());
        }
    }

    @Override
    public void scoreboardUpdated() {
        Platform.runLater(this::updateLeaderboard);
    }

    public void handleDisconnect() {
        try {
            service.removeObserver(this);
            messageArea.setText("Deconectare reusita.");
        } catch (Exception e) {
            messageArea.setText("Eroare la deconectare: " + e.getMessage());
        }
    }
}
