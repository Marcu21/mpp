package com.example.barci.repository;

import com.example.barci.domain.Game;

public interface GameRepository extends Repository<Game, Long> {
}
