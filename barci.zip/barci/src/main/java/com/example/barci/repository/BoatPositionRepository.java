package com.example.barci.repository;

import com.example.barci.domain.BoatPosition;

public interface BoatPositionRepository extends Repository<BoatPosition, Long>{
}

