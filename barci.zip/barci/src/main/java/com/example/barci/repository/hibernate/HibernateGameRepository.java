package com.example.barci.repository.hibernate;

import com.example.barci.domain.Game;
import com.example.barci.repository.GameRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.Collection;

public class HibernateGameRepository implements GameRepository {

    private final SessionFactory sessionFactory;

    public HibernateGameRepository(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void add(Game game) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.persist(game);
            tran.commit();
        }
    }

    @Override
    public Iterable<Game> findAll() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("from Game", Game.class).list();
        }
    }

    @Override
    public Game findById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Game.class, id);
        }
    }

    @Override
    public void update(Game game) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.merge(game);
            tran.commit();
        }
    }

    @Override
    public void delete(Game game) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.remove(session.contains(game) ? game : session.merge(game));
            tran.commit();
        }
    }

    @Override
    public Collection<Game> getAll() {
        return (Collection<Game>) findAll();
    }
}
