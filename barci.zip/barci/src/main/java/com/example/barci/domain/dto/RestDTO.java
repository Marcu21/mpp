package com.example.barci.domain.dto;

import java.util.List;

public class RestDTO {
    private List<GameResultDTO.PosDTO> positions;

    public RestDTO() {}

    public RestDTO(List<GameResultDTO.PosDTO> positions) {
        this.positions = positions;
    }

    public List<GameResultDTO.PosDTO> getPositions() {
        return positions;
    }

    public void setPositions(List<GameResultDTO.PosDTO> positions) {
        this.positions = positions;
    }
}
