package com.example.barci.rest;

import com.example.barci.domain.dto.GameResultDTO;
import com.example.barci.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/results")
public class GameResultRestController {

    private final GameService gameService;

    public GameResultRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @GetMapping("/min1/{alias}")
    public ResponseEntity<List<GameResultDTO>> getResultsForPlayer(@PathVariable String alias) {
        try {
            List<GameResultDTO> results = new ArrayList<>();
            for(GameResultDTO g: gameService.getDetailedResultsForPlayer(alias)) {
                if(g.getGuessed() >= 1)
                    results.add(g);
            }
            return new ResponseEntity<>(results, HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
