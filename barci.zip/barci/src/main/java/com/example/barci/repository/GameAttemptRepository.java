package com.example.barci.repository;

import com.example.barci.domain.GameAttempt;

public interface GameAttemptRepository extends Repository<GameAttempt, Long> {
}