package com.example.barci.rest;

import com.example.barci.domain.Boat;
import com.example.barci.domain.dto.RestDTO;
import com.example.barci.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/boats")
public class BoatRestController {

    private final GameService gameService;

    public BoatRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @PostMapping
    public ResponseEntity<Boat> addBoatAtPosition(@RequestBody RestDTO dto) {
        try {
            Boat saved = gameService.addBoat(dto.getPositions());
            return new ResponseEntity<>(saved, HttpStatus.CREATED);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping
    public ResponseEntity<List<RestDTO>> getAllBoats() {
        return new ResponseEntity<>(gameService.getAllBoats(), HttpStatus.OK);
    }

}



/*
{
POST http://localhost:8080/api/boats

  "positions": [
    { "row": 4, "col": 2 },
    { "row": 4, "col": 3 },
    { "row": 4, "col": 4 }
  ]
}
 */