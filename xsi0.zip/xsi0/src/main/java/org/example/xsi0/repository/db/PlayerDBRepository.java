package org.example.xsi0.repository.db;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.xsi0.domain.Player;
import org.example.xsi0.repository.PlayerRepository;
import org.example.xsi0.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class PlayerDBRepository implements PlayerRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public PlayerDBRepository() {
        logger.info("Initializing PlayerDBRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(Player player) {
        logger.traceEntry("Saving player {}", player);
        String sql = "INSERT INTO Player (alias) VALUES (?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, player.getAlias());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    player.setId(keys.getLong(1));
                }
            }
            logger.trace("Saved {}", player);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<Player> findAll() {
        logger.traceEntry();
        List<Player> players = new ArrayList<>();
        String sql = "SELECT * FROM Player";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Long id = rs.getLong("id");
                String alias = rs.getString("alias");
                Player p = new Player(id, alias);
                players.add(p);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit(players);
        return players;
    }

    @Override
    public void delete(Player player) {
        logger.traceEntry("Deleting player {}", player);
        String sql = "DELETE FROM Player WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, player.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", player);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public void update(Player player) {
        logger.traceEntry("Updating player {}", player);
        String sql = "UPDATE Player SET alias=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, player.getAlias());
            stmt.setLong(2, player.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", player);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public Player findById(Long id) {
        logger.traceEntry("Finding player by id {}", id);
        String sql = "SELECT * FROM Player WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String alias = rs.getString("alias");
                    Player p = new Player(id, alias);
                    logger.traceExit(p);
                    return p;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Player> getAll() {
        return (Collection<Player>) findAll();
    }
}