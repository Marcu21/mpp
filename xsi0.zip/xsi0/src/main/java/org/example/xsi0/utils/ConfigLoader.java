package org.example.xsi0.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigLoader {
    private static final String CONFIG_FILE = "db.config";

    public static Properties loadProperties() {
        Properties properties = new Properties();
        try (InputStream input = ConfigLoader.class.getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (input == null) {
                throw new RuntimeException("Fisierul db.config nu a fost gasit!");
            }
            properties.load(input);
        } catch (IOException e) {
            throw new RuntimeException("Eroare la citirea fisierului db.config!", e);
        }
        return properties;
    }
}
