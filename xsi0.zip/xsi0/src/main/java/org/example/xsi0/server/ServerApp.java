package org.example.xsi0.server;

import org.example.xsi0.networking.RequestHandler;
import org.example.xsi0.repository.GameAttemptRepository;
import org.example.xsi0.repository.GameRepository;
import org.example.xsi0.repository.PlayerRepository;
import org.example.xsi0.repository.db.*;
import org.example.xsi0.repository.db.PlayerDBRepository;
import org.example.xsi0.repository.hibernate.HibernateGameRepository;
import org.example.xsi0.service.GameService;
import org.example.xsi0.utils.HibernateUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    private static final int PORT = 5555;

    public static void main(String[] args) {
        PlayerRepository playerRepo   = new PlayerDBRepository();
        GameRepository gameRepo     = new HibernateGameRepository(HibernateUtil.getSessionFactory());
        GameAttemptRepository attemptRepo = new GameAttemptDBRepository();

        GameService service = new GameService(playerRepo, gameRepo, attemptRepo);

        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket client = server.accept();
                new Thread(new RequestHandler(service, client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
