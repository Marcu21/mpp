package org.example.xsi0.utils;

import org.example.xsi0.repository.*;
import org.example.xsi0.repository.db.GameAttemptDBRepository;
import org.example.xsi0.repository.db.PlayerDBRepository;
import org.example.xsi0.repository.hibernate.HibernateGameRepository;
import org.example.xsi0.service.GameService;
import org.example.xsi0.utils.HibernateUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public PlayerRepository playerRepository() {
        return new PlayerDBRepository();
    }

    @Bean
    public GameAttemptRepository gameAttemptRepository() {
        return new GameAttemptDBRepository();
    }

    @Bean
    public GameRepository gameRepository() {
        return new HibernateGameRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public GameService gameService() {
        return new GameService(
                playerRepository(),
                gameRepository(),
                gameAttemptRepository()
        );
    }
}
