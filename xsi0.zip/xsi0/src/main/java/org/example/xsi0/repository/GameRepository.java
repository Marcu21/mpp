package org.example.xsi0.repository;

import org.example.xsi0.domain.Game;

public interface GameRepository extends Repository<Game, Long> {
}
