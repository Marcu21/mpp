package org.example.xsi0.service;

import org.example.xsi0.domain.*;
import org.example.xsi0.domain.dto.GameResultDTO;
import org.example.xsi0.networking.IGameObserver;
import org.example.xsi0.networking.IGameService;
import org.example.xsi0.repository.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GameService implements IGameService {

    private final PlayerRepository playerRepo;
    private final GameRepository gameRepo;
    private final GameAttemptRepository attemptRepo;
    private final List<IGameObserver> observers = new ArrayList<>();

    private final Random random = new Random();

    public GameService(PlayerRepository playerRepo,
                       GameRepository gameRepo,
                       GameAttemptRepository attemptRepo) {
        this.playerRepo = playerRepo;
        this.gameRepo = gameRepo;
        this.attemptRepo = attemptRepo;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        observers.remove(observer);
    }

    @Override
    public Game startGame(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            player = new Player(null, alias);
            playerRepo.add(player);
        }

        Game game = new Game(player.getId(), LocalDateTime.now());
        game.setScore(0);
        gameRepo.add(game);

        return game;
    }


    @Override
    public String makeAttempt(Long gameId, int row, int col) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }


        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId) && a.getRow() == row && a.getCol() == col) {
                return "Pozitia este deja ocupata!";
            }
        }

        GameAttempt attempt = new GameAttempt(gameId, row, col);
        attemptRepo.add(attempt);

        String result = procesareXsi0(game, row, col);

        gameRepo.update(game);
        if (game.getEndTime() != null) {
            notifyGameFinished();
        }

        return result;
    }

    private String procesareXsi0(Game game, int row, int col) {
        List<GameAttempt> attempts = getAttemptsForGame(game.getId());

        //verifica daca jucatorul a castigat
        if (verificaCastig(attempts, true)) {
            game.setEndTime(LocalDateTime.now());
            game.setResult("win");
            game.setScore(game.getScore() + 10);
            return "Ai castigat! +10 puncte.";
        }

        //verifica sunt locuri libere
        if (attempts.size() >= 9) {
            game.setEndTime(LocalDateTime.now());
            game.setResult("draw");
            game.setScore(game.getScore() + 5);
            return "Remiza! +5 puncte.";
        }

        //mutare random a calculatorului (0)
        List<int[]> freePositions = pozitiiLibere(attempts);
        if(!freePositions.isEmpty()) {
            int[] pos = freePositions.get(random.nextInt(freePositions.size()));
            GameAttempt computerAttempt = new GameAttempt(game.getId(), pos[0], pos[1]);
            attemptRepo.add(computerAttempt);
            attempts.add(computerAttempt);

            List<GameAttempt> updatedAttempts = getAttemptsForGame(game.getId());
            //verifica daca calculatorul a castigat
            if (verificaCastig(updatedAttempts, false)) {
                game.setEndTime(LocalDateTime.now());
                game.setResult("lose");
                return "Calculatorul a castigat! -10 puncte.";
            }
        }

        return "Mutare efectuata. E randul tau!";
    }

    private List<int[]> pozitiiLibere(List<GameAttempt> attempts) {
        Set<String> ocupate = new HashSet<>();
        for (GameAttempt a : attempts) {
            ocupate.add(a.getRow() + "," + a.getCol());
        }

        List<int[]> libere = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String poz = i + "," + j;
                if (!ocupate.contains(poz)) {
                    libere.add(new int[]{i, j});
                }
            }
        }
        return libere;
    }


    private boolean verificaCastig(List<GameAttempt> attempts, boolean jucator) {
        char[][] tabla = new char[3][3];

        int index = 0;
        for (GameAttempt a : attempts) {
            char simbol;
            if (index % 2 == 0) {
                simbol = 'X';
            } else {
                simbol = 'O';
            }
            tabla[a.getRow()][a.getCol()] = simbol;
            index++;
        }

        char c;
        if (jucator) {
            c = 'X';
        } else {
            c = 'O';
        }

        for (int i = 0; i < 3; i++) {
            if (tabla[i][0] == c && tabla[i][1] == c && tabla[i][2] == c) return true;
            if (tabla[0][i] == c && tabla[1][i] == c && tabla[2][i] == c) return true;
        }

        if (tabla[0][0] == c && tabla[1][1] == c && tabla[2][2] == c) return true;
        if (tabla[0][2] == c && tabla[1][1] == c && tabla[2][0] == c) return true;

        return false;
    }




    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getEndTime() != null) {
                Player p = playerRepo.findById(g.getPlayerId());
                Duration d = Duration.between(g.getStartTime(), g.getEndTime());
                results.add(new GameResultDTO(g.getId(), p.getAlias(), g.getScore(), d.getSeconds(), new ArrayList<>()));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Long.compare(a.getDurationSeconds(), b.getDurationSeconds());
        });
        return results;
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            throw new RuntimeException("Jucatorul nu exista.");
        }

        List<GameResultDTO> results = new ArrayList<>();

        for (Game g : gameRepo.findAll()) {
            if (g.getPlayerId().equals(player.getId())
                    && g.getEndTime() != null
                    && "win".equalsIgnoreCase(g.getResult())) {

                long duration = Duration.between(g.getStartTime(), g.getEndTime()).getSeconds();

                List<GameResultDTO.PosDTO> attempts = new ArrayList<>();
                for (GameAttempt a : attemptRepo.findAll()) {
                    if (a.getGameId().equals(g.getId())) {
                        attempts.add(new GameResultDTO.PosDTO(a.getRow(), a.getCol()));
                    }
                }

                GameResultDTO dto = new GameResultDTO(
                        g.getId(),
                        alias,
                        g.getScore(),
                        duration,
                        attempts
                );
                results.add(dto);
            }
        }

        results.sort(Comparator.comparingLong(GameResultDTO::getDurationSeconds).reversed());

        return results;
    }


    @Override
    public List<GameAttempt> getAttemptsForGame(Long gameId) {
        List<GameAttempt> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId)) {
                attempts.add(a);
            }
        }
        return attempts;
    }


    private void notifyGameFinished() {
        for (IGameObserver observer : observers) {
            try {
                observer.scoreboardUpdated();
            } catch (Exception e) {
                System.err.println("Eroare notificare: " + e.getMessage());
            }
        }
    }

    public GameAttempt addGameAttempt(GameAttempt gameAttempt) {
        if (gameAttempt == null || gameAttempt.getGameId() == null) {
            throw new IllegalArgumentException("Datele pentru mutare sunt invalide.");
        }

        for (GameAttempt g : attemptRepo.findAll()) {
            if (g.getGameId().equals(gameAttempt.getGameId()) &&
                    g.getRow() == gameAttempt.getRow() &&
                    g.getCol() == gameAttempt.getCol()) {
                throw new IllegalArgumentException("Aceasta pozitie este deja ocupata.");
            }
        }

        attemptRepo.add(gameAttempt);
        return gameAttempt;
    }

}
