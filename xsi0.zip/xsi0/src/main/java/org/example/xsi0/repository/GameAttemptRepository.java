package org.example.xsi0.repository;

import org.example.xsi0.domain.GameAttempt;

public interface GameAttemptRepository extends Repository<GameAttempt, Long> {
}