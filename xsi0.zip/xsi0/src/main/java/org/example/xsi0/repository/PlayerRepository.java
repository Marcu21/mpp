package org.example.xsi0.repository;

import org.example.xsi0.domain.Player;

public interface PlayerRepository extends Repository<Player, Long> {
}