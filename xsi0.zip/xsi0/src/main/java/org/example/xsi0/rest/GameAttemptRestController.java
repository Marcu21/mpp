package org.example.xsi0.rest;

import org.example.xsi0.domain.GameAttempt;
import org.example.xsi0.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/attempts")
public class GameAttemptRestController {

    private final GameService gameService;

    public GameAttemptRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @PostMapping
    public ResponseEntity<GameAttempt> createGameAttempt(@RequestBody GameAttempt gameAttempt) {
        try {
            GameAttempt saved = gameService.addGameAttempt(gameAttempt);
            return new ResponseEntity<>(saved, HttpStatus.CREATED);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}