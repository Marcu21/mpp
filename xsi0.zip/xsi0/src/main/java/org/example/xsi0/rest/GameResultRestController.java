package org.example.xsi0.rest;

import org.example.xsi0.domain.dto.GameResultDTO;
import org.example.xsi0.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/results")
public class GameResultRestController {

    private final GameService gameService;

    public GameResultRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @GetMapping("/{alias}")
    public ResponseEntity<List<GameResultDTO>> getResultsForPlayer(@PathVariable String alias) {
        try {
            List<GameResultDTO> results = gameService.getDetailedResultsForPlayer(alias);
            return new ResponseEntity<>(results, HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
