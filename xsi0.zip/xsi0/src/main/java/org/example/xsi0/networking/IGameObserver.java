package org.example.xsi0.networking;

public interface IGameObserver {
    void scoreboardUpdated();
}