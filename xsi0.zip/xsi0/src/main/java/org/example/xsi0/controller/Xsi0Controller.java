package org.example.xsi0.controller;

import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import org.example.xsi0.domain.Game;
import org.example.xsi0.domain.GameAttempt;
import org.example.xsi0.domain.dto.GameResultDTO;
import org.example.xsi0.networking.GameServiceProxy;
import org.example.xsi0.networking.IGameObserver;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Xsi0Controller implements IGameObserver {

    @FXML
    private TextField aliasField;
    @FXML private TextArea messageArea;
    @FXML private GridPane grid;

    @FXML private TableView<GameResultDTO> leaderboardTable;
    @FXML private TableColumn<GameResultDTO, String> colAlias;
    @FXML private TableColumn<GameResultDTO, Integer> colScore;
    @FXML private TableColumn<GameResultDTO, String> colDuration;

    private final GameServiceProxy service = new GameServiceProxy("localhost", 5555);

    private Long currentGameId = null;
    private String currentAlias = null;

    @FXML
    public void initialize() {
        initLeaderboardTable();
        populateGrid();
    }

    private void initLeaderboardTable() {
        colAlias.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAlias()));
        colScore.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getScore()));
        colDuration.setCellValueFactory(data -> {
            long seconds = data.getValue().getDurationSeconds();
            String formatted = String.format("%02d:%02d", seconds / 60, seconds % 60);
            return new SimpleStringProperty(formatted);
        });
    }

    private void populateGrid() {
        grid.getChildren().clear();

        for (int r = 1; r <= 3; r++) {
            for (int c = 1; c <= 3; c++) {
                Button btn = new Button(r + "," + c);
                btn.setPrefSize(60, 60);
                final int row = r;
                final int col = c;
                btn.setOnAction(ev -> handleMove(row - 1, col - 1));
                grid.add(btn, c - 1, r - 1);
            }
        }
    }

    @FXML
    public void handleStartGame() {
        int ok = 1;
        if (currentAlias != null)
        {
            ok = 0;
        }
        currentAlias = aliasField.getText().trim();
        if (currentAlias.isEmpty()) {
            messageArea.setText("Introdu un alias valid.");
            return;
        }

        try {
            if(ok == 1)
            {
                service.addObserver(this);
            }

            Game game = service.startGame(currentAlias);
            this.currentGameId = game.getId();
            refreshGrid();
            messageArea.setText("Joc pornit!");

            updateLeaderboard();
        } catch (Exception e) {
            messageArea.setText("Eroare la pornirea jocului: " + e.getMessage());
        }
    }

    private void handleMove(int row, int col) {
        if (currentGameId == null) {
            messageArea.setText("Mai intai porneste un joc.");
            return;
        }

        try {
            String result = service.makeAttempt(currentGameId, row, col);
            messageArea.setText(result);
            refreshGrid();

            if (result.contains("puncte")) {
                currentGameId = null;
                updateLeaderboard();
            }
        } catch (Exception e) {
            messageArea.setText("Eroare la mutare: " + e.getMessage());
        }
    }

    private void updateLeaderboard() {
        try {
            List<GameResultDTO> results = service.getResultsForAllPlayers();
            leaderboardTable.getItems().setAll(results);
        } catch (Exception e) {
            messageArea.setText("Eroare la actualizarea clasamentului: " + e.getMessage());
        }
    }

    @Override
    public void scoreboardUpdated() {
        Platform.runLater(this::updateLeaderboard);
    }

    public void handleDisconnect() {
        try {
            service.removeObserver(this);
            messageArea.setText("Deconectare reusita.");
        } catch (Exception e) {
            messageArea.setText("Eroare la deconectare: " + e.getMessage());
        }
    }

    private void refreshGrid() {
        try {
            List<GameAttempt> attempts = service.getAttemptsForGame(currentGameId);

            Map<String, Integer> posIndexMap = new HashMap<>();
            for (int i = 0; i < attempts.size(); i++) {
                GameAttempt move = attempts.get(i);
                String key = move.getRow() + "," + move.getCol();
                posIndexMap.put(key, i);
            }

            for (var node : grid.getChildren()) {
                if (node instanceof Button btn) {
                    Integer row = GridPane.getRowIndex(btn);
                    Integer col = GridPane.getColumnIndex(btn);
                    if (row == null || col == null) continue;

                    String key = row + "," + col;
                    if (posIndexMap.containsKey(key)) {
                        int moveIndex = posIndexMap.get(key);
                        String symbol = getSymbolAt(moveIndex);
                        btn.setText(symbol);
                        btn.setDisable(true);
                    } else {
                        btn.setText("");
                        btn.setDisable(false);
                    }
                }
            }
        } catch (Exception e) {
            messageArea.setText("Eroare la refresh grid: " + e.getMessage());
        }
    }



    private String getSymbolAt(int index) {
        return (index % 2 == 0) ? "X" : "O";
    }


    /*
    private void refreshGrid() {
    try {
        List<GameResultDTO.PosDTO> attempts = service.getAttemptsForGame(currentGameId);

        int index = 0;
        for (GameResultDTO.PosDTO move : attempts) {
            int row = move.getRow();
            int col = move.getCol();
            String symbol = (index % 2 == 0) ? "X" : "O";
            index++;

            for (var node : grid.getChildren()) {
                if (node instanceof Button btn) {
                    Integer r = GridPane.getRowIndex(btn);
                    Integer c = GridPane.getColumnIndex(btn);
                    if (r != null && c != null && r == row && c == col) {
                        btn.setText(symbol);
                        btn.setDisable(true);
                        break;
                    }
                }
            }
        }
    } catch (Exception e) {
        messageArea.setText("Eroare la refresh grid: " + e.getMessage());
    }
}

     */
}