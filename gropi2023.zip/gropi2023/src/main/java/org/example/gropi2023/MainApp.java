package org.example.gropi2023;

public class MainApp {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
