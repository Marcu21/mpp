package org.example.gropi2023.networking;

import java.io.Serializable;

public class Response implements Serializable {
    private String type;
    private Object data;

    public Response(String type, Object data) {
        this.type = type;
        this.data = data;
    }

    public String getType() {
        return type;
    }

    public Object getData() {
        return data;
    }
}
