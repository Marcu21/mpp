package org.example.gropi2023.utils;

import org.example.gropi2023.repository.*;
import org.example.gropi2023.repository.db.GameAttemptDBRepository;
import org.example.gropi2023.repository.db.HoleDBRepository;
import org.example.gropi2023.repository.db.PlayerDBRepository;
import org.example.gropi2023.repository.hibernate.HibernateGameRepository;
import org.example.gropi2023.service.GameService;
import org.example.gropi2023.utils.HibernateUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public PlayerRepository playerRepository() {
        return new PlayerDBRepository();
    }

    @Bean
    public HoleRepository holeRepository() {
        return new HoleDBRepository();
    }

    @Bean
    public GameAttemptRepository gameAttemptRepository() {
        return new GameAttemptDBRepository();
    }

    @Bean
    public GameRepository gameRepository() {
        return new HibernateGameRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public GameService gameService() {
        return new GameService(
                playerRepository(),
                gameRepository(),
                gameAttemptRepository(),
                holeRepository()
        );
    }
}
