package org.example.gropi2023.controller;

import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.gropi2023.domain.Game;
import org.example.gropi2023.domain.dto.GameResultDTO;
import org.example.gropi2023.networking.GameServiceProxy;
import org.example.gropi2023.networking.IGameObserver;

import java.util.List;

public class GameController implements IGameObserver {

    @FXML private TextField aliasField;
    @FXML private TextArea messageArea;
    @FXML private GridPane grid;

    @FXML private TableView<GameResultDTO> leaderboardTable;
    @FXML private TableColumn<GameResultDTO, String> colAlias;
    @FXML private TableColumn<GameResultDTO, Integer> colScore;
    @FXML private TableColumn<GameResultDTO, String> colDuration;

    private final GameServiceProxy service = new GameServiceProxy("localhost", 5555);

    private Long currentGameId = null;
    private String currentAlias = null;
    private int currentRow = 1;

    @FXML
    public void initialize() {
        initLeaderboardTable();
        populateGrid();
    }

    private void initLeaderboardTable() {
        colAlias.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAlias()));
        colScore.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getScore()));
        colDuration.setCellValueFactory(data -> {
            long seconds = data.getValue().getDurationSeconds();
            String formatted = String.format("%02d:%02d", seconds / 60, seconds % 60);
            return new SimpleStringProperty(formatted);
        });
    }

    private void populateGrid() {
        grid.getChildren().clear();

        for (int r = 1; r <= 4; r++) {
            for (int c = 1; c <= 4; c++) {
                Button btn = new Button(r + "," + c);
                btn.setPrefSize(60, 60);
                final int row = r;
                final int col = c;
                btn.setOnAction(ev -> handleMove(row, col));
                grid.add(btn, c - 1, r - 1);
            }
        }
    }

    @FXML
    public void handleStartGame() {
        int ok = 1;
        if (currentAlias != null) {
            ok = 0;
        }
        currentAlias = aliasField.getText().trim();
        if (currentAlias.isEmpty()) {
            messageArea.setText("Introdu un alias valid.");
            return;
        }

        try {
            if(ok == 1) {
                service.addObserver(this);
            }

            Game game = service.startGame(currentAlias);
            this.currentGameId = game.getId();
            this.currentRow = 1;
            messageArea.setText("Joc pornit! Selecteaza o pozitie pe linia 1.");

            updateLeaderboard();
        } catch (Exception e) {
            messageArea.setText("Eroare la pornirea jocului: " + e.getMessage());
        }
    }

    private void handleMove(int row, int col) {
        if (currentGameId == null) {
            messageArea.setText("Mai intai porneste un joc.");
            return;
        }

        if (row != currentRow) {
            messageArea.setText("Trebuie sa alegi o pozitie pe linia " + currentRow + ".");
            return;
        }

        try {
            String result = service.makeAttempt(currentGameId, row, col);
            messageArea.setText(result);

            if (result.contains("Joc terminat") || result.contains("Felicitari")) {
                currentGameId = null;
                updateLeaderboard();
            } else {
                currentRow++;
            }

        } catch (Exception e) {
            messageArea.setText("Eroare la mutare: " + e.getMessage());
        }
    }

    private void updateLeaderboard() {
        try {
            List<GameResultDTO> results = service.getResultsForAllPlayers();
            leaderboardTable.getItems().setAll(results);
        } catch (Exception e) {
            messageArea.setText("Eroare la actualizarea clasamentului: " + e.getMessage());
        }
    }

    @Override
    public void scoreboardUpdated() {
        Platform.runLater(this::updateLeaderboard);
    }

    public void handleDisconnect() {
        try {
            service.removeObserver(this);
            messageArea.setText("Deconectare reusita.");
        } catch (Exception e) {
            messageArea.setText("Eroare la deconectare: " + e.getMessage());
        }
    }
}
