package org.example.gropi2023.rest;

import org.example.gropi2023.domain.Hole;
import org.example.gropi2023.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/holes")
public class HoleRestController {

    private final GameService gameService;

    public HoleRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @PostMapping
    public ResponseEntity<Hole> createHole(@RequestBody Hole hole) {
        try {
            Hole saved = gameService.addHole(hole);
            return new ResponseEntity<>(saved, HttpStatus.CREATED);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
