package org.example.gropi2023.repository;

import org.example.gropi2023.domain.GameAttempt;

public interface GameAttemptRepository extends Repository<GameAttempt, Long> {
}