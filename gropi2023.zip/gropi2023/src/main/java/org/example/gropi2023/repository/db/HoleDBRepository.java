package org.example.gropi2023.repository.db;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.gropi2023.domain.Hole;
import org.example.gropi2023.repository.HoleRepository;
import org.example.gropi2023.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class HoleDBRepository implements HoleRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public HoleDBRepository() {
        logger.info("Initializing HoleDBRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(Hole hole) {
        logger.traceEntry("Saving hole {}", hole);
        String sql = "INSERT INTO Hole (game_id, row, col) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setLong(1, hole.getGameId());
            stmt.setInt(2, hole.getRow());
            stmt.setInt(3, hole.getCol());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    hole.setId(keys.getLong(1));
                }
            }

            logger.trace("Saved {}", hole);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }

        logger.traceExit();
    }

    @Override
    public Iterable<Hole> findAll() {
        logger.traceEntry();
        List<Hole> holes = new ArrayList<>();
        String sql = "SELECT * FROM Hole";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Hole hole = extractHole(rs);
                holes.add(hole);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(holes);
        return holes;
    }

    @Override
    public void delete(Hole hole) {
        logger.traceEntry("Deleting hole {}", hole);
        String sql = "DELETE FROM Hole WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, hole.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", hole);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public void update(Hole hole) {
        logger.traceEntry("Updating hole {}", hole);
        String sql = "UPDATE Hole SET game_id=?, row=?, col=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, hole.getGameId());
            stmt.setInt(2, hole.getRow());
            stmt.setInt(3, hole.getCol());
            stmt.setLong(4, hole.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", hole);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public Hole findById(Long id) {
        logger.traceEntry("Finding hole by id {}", id);
        String sql = "SELECT * FROM Hole WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Hole hole = extractHole(rs);
                    logger.traceExit(hole);
                    return hole;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Hole> getAll() {
        return (Collection<Hole>) findAll();
    }

    private Hole extractHole(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        Long gameId = rs.getLong("game_id");
        int row = rs.getInt("row");
        int col = rs.getInt("col");
        return new Hole(id, gameId, row, col);
    }
}
