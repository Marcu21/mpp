package org.example.gropi2023.networking;

public interface IGameObserver {
    void scoreboardUpdated();
}