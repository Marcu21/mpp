package org.example.gropi2023.service;

import org.example.gropi2023.domain.*;
import org.example.gropi2023.domain.dto.GameResultDTO;
import org.example.gropi2023.networking.IGameObserver;
import org.example.gropi2023.networking.IGameService;
import org.example.gropi2023.repository.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GameService implements IGameService {

    private final PlayerRepository playerRepo;
    private final GameRepository gameRepo;
    private final GameAttemptRepository attemptRepo;
    private final HoleRepository holeRepo;
    private final List<IGameObserver> observers = new ArrayList<>();

    private final Random random = new Random();

    public GameService(PlayerRepository playerRepo,
                       GameRepository gameRepo,
                       GameAttemptRepository attemptRepo,
                       HoleRepository holeRepo) {
        this.playerRepo = playerRepo;
        this.gameRepo = gameRepo;
        this.attemptRepo = attemptRepo;
        this.holeRepo = holeRepo;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        observers.remove(observer);
    }

    @Override
    public Game startGame(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            player = new Player(null, alias);
            playerRepo.add(player);
        }

        Game game = new Game(player.getId(), LocalDateTime.now());
        gameRepo.add(game);

        Set<String> existingPositions = new HashSet<>();

        for (int row = 1; row <= 4; row++) {
            int col;
            String key;
            do {
                col = random.nextInt(4) + 1;
                key = row + "," + col;
            } while (existingPositions.contains(key));

            holeRepo.add(new Hole(game.getId(), row, col));
            existingPositions.add(key);
        }

        int extraRow = random.nextInt(4) + 1;
        while (true) {
            int col = random.nextInt(4) + 1;
            String key = extraRow + "," + col;
            if (!existingPositions.contains(key)) {
                holeRepo.add(new Hole(game.getId(), extraRow, col));
                break;
            }
        }

        return game;
    }

    @Override
    public String makeAttempt(Long gameId, int row, int col) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }

        int expectedRow = getAttemptsForGame(gameId).size() + 1;
        if (row != expectedRow) {
            return "Trebuie sa alegi o pozitie de pe linia " + expectedRow + "!";
        }

        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId) && a.getRow() == row && a.getCol() == col) {
                return "Pozitia este deja ocupata!";
            }
        }

        GameAttempt attempt = new GameAttempt(gameId, LocalDateTime.now(), row, col);
        attemptRepo.add(attempt);

        String result = procesareGropi(game, row, col);

        gameRepo.update(game);
        if (game.getEndTime() != null) {
            notifyGameFinished();
        }

        return result;
    }


    private String procesareGropi(Game game, int row, int col) {
        if (isHoleAtPosition(game.getId(), row, col)) {
            game.setEndTime(LocalDateTime.now());
            return buildEndMessage("Ai cazut in groapa. Joc terminat.", game.getId());
        }

        game.setScore(game.getScore() + row);

        if (row == 4) {
            game.setEndTime(LocalDateTime.now());
            return buildEndMessage("Ai castigat! Felicitari!", game.getId());
        }

        return "Pas corect. Continua la linia urmatoare.";
    }

    private boolean isHoleAtPosition(Long gameId, int row, int col) {
        for (Hole h : holeRepo.findAll()) {
            if (h.getGameId().equals(gameId) && h.getRow() == row && h.getCol() == col) {
                return true;
            }
        }
        return false;
    }

    private String buildEndMessage(String baseMessage, Long gameId) {
        StringBuilder sb = new StringBuilder(baseMessage);
        sb.append("\nGropile au fost la: ");
        for (Hole h : holeRepo.findAll()) {
            if (h.getGameId().equals(gameId)) {
                sb.append("(").append(h.getRow()).append(",").append(h.getCol()).append(") ");
            }
        }
        return sb.toString();
    }







/*    @Override
    public String makeAttempt(Long gameId, int row, int col) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }

        int expectedRow = getAttemptsForGame(gameId).size() + 1;
        if (row != expectedRow) {
            return "Trebuie sa alegi o pozitie de pe linia " + expectedRow + "!";
        }

        GameAttempt attempt = new GameAttempt(gameId, LocalDateTime.now(), row, col);
        attemptRepo.add(attempt);

        boolean isHole = false;
        for (Hole h : holeRepo.findAll()) {
            if (h.getGameId().equals(gameId) && h.getRow() == row && h.getCol() == col) {
                isHole = true;
                break;
            }
        }

        if (isHole) {
            game.setEndTime(LocalDateTime.now());
            gameRepo.update(game);
            notifyGameFinished();

            StringBuilder holesMsg = new StringBuilder("Ai cazut in groapa. Joc terminat.\nGropile au fost la: ");
            for (Hole h : holeRepo.findAll()) {
                if (h.getGameId().equals(gameId)) {
                    holesMsg.append("(").append(h.getRow()).append(",").append(h.getCol()).append(") ");
                }
            }

            return holesMsg.toString();
        }


        game.setScore(game.getScore() + row);

        if (row == 4) {
            game.setEndTime(LocalDateTime.now());
            gameRepo.update(game);
            notifyGameFinished();

            StringBuilder holesMsg = new StringBuilder("Ai castigat! Felicitari!\nGropile au fost la: ");
            for (Hole h : holeRepo.findAll()) {
                if (h.getGameId().equals(gameId)) {
                    holesMsg.append("(").append(h.getRow()).append(",").append(h.getCol()).append(") ");
                }
            }

            return holesMsg.toString();
        }


        gameRepo.update(game);
        return "Pas corect. Continua la linia urmatoare.";
    }*/

    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getEndTime() != null) {
                Player p = playerRepo.findById(g.getPlayerId());
                Duration d = Duration.between(g.getStartTime(), g.getEndTime());
                results.add(new GameResultDTO(g.getId(), p.getAlias(), g.getScore(), d.getSeconds(), new ArrayList<>(), new ArrayList<>()));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Long.compare(a.getDurationSeconds(), b.getDurationSeconds());
        });
        return results;
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) throw new RuntimeException("Jucator inexistent.");

        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getPlayerId().equals(player.getId()) && g.getEndTime() != null) {
                Duration d = Duration.between(g.getStartTime(), g.getEndTime());

                List<GameResultDTO.PosDTO> holes = new ArrayList<>();
                for (Hole h : holeRepo.findAll()) {
                    if (h.getGameId().equals(g.getId())) {
                        holes.add(new GameResultDTO.PosDTO(h.getRow(), h.getCol()));
                    }
                }

                List<GameResultDTO.PosDTO> attempts = new ArrayList<>();
                for (GameAttempt a : attemptRepo.findAll()) {
                    if (a.getGameId().equals(g.getId())) {
                        attempts.add(new GameResultDTO.PosDTO(a.getRow(), a.getCol()));
                    }
                }

                results.add(new GameResultDTO(g.getId(), alias, g.getScore(), d.getSeconds(), holes, attempts));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Long.compare(a.getDurationSeconds(), b.getDurationSeconds());
        });
        return results;
    }

    @Override
    public List<GameAttempt> getAttemptsForGame(Long gameId) {
        List<GameAttempt> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId)) {
                attempts.add(a);
            }
        }
        return attempts;
    }

    @Override
    public List<Hole> getHolesForGame(Long gameId) {
        List<Hole> holes = new ArrayList<>();
        for (Hole h : holeRepo.findAll()) {
            if (h.getGameId().equals(gameId)) {
                holes.add(h);
            }
        }
        return holes;
    }

    private void notifyGameFinished() {
        for (IGameObserver observer : observers) {
            try {
                observer.scoreboardUpdated();
            } catch (Exception e) {
                System.err.println("Eroare notificare: " + e.getMessage());
            }
        }
    }

    public Hole addHole(Hole hole) {
        if (hole == null || hole.getGameId() == null) {
            throw new IllegalArgumentException("Datele pentru groapa sunt invalide.");
        }

        for (Hole h : holeRepo.findAll()) {
            if (h.getGameId().equals(hole.getGameId()) &&
                    h.getRow() == hole.getRow() &&
                    h.getCol() == hole.getCol()) {
                throw new IllegalArgumentException("Aceasta pozitie este deja ocupata de o groapa.");
            }
        }

        holeRepo.add(hole);
        return hole;
    }

}
