package org.example.gropi2023.server;

import org.example.gropi2023.networking.RequestHandler;
import org.example.gropi2023.repository.GameAttemptRepository;
import org.example.gropi2023.repository.GameRepository;
import org.example.gropi2023.repository.HoleRepository;
import org.example.gropi2023.repository.PlayerRepository;
import org.example.gropi2023.repository.db.*;
import org.example.gropi2023.repository.db.PlayerDBRepository;
import org.example.gropi2023.repository.hibernate.HibernateGameRepository;
import org.example.gropi2023.service.GameService;
import org.example.gropi2023.utils.HibernateUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    private static final int PORT = 5555;

    public static void main(String[] args) {
        PlayerRepository playerRepo   = new PlayerDBRepository();
        HoleRepository holeRepo     = new HoleDBRepository();
        GameRepository gameRepo     = new HibernateGameRepository(HibernateUtil.getSessionFactory());
        GameAttemptRepository attemptRepo = new GameAttemptDBRepository();

        GameService service = new GameService(playerRepo, gameRepo, attemptRepo, holeRepo);

        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket client = server.accept();
                new Thread(new RequestHandler(service, client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
