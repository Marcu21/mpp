package org.example.gropi2023.repository;

import org.example.gropi2023.domain.Hole;

public interface HoleRepository extends Repository<Hole, Long>{
}
