package org.example.gropi2023.repository;

import org.example.gropi2023.domain.Player;

public interface PlayerRepository extends Repository<Player, Long> {
}