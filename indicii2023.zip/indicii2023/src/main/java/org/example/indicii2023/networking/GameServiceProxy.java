package org.example.indicii2023.networking;

import org.example.indicii2023.domain.Game;
import org.example.indicii2023.domain.Hint;
import org.example.indicii2023.domain.dto.GameResultDTO;

import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class GameServiceProxy implements IGameService {
    private final String host;
    private final int port;

    private ObjectInputStream input;
    private ObjectOutputStream output;
    private Socket connection;
    private boolean isConnected = false;


    private final Object lock = new Object();
    private final BlockingQueue<Response> responses = new LinkedBlockingQueue<>();

    private IGameObserver client;

    public GameServiceProxy(String host, int port) {
        this.host = host;
        this.port = port;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        this.client = observer;
        try {
            initializeConnection();
            sendRequest(new Request("addObserver", null));
            Response response = readResponse();
            if (!response.getType().equals("ok"))
                throw new RuntimeException((String) response.getData());
        } catch (Exception e) {
            throw new RuntimeException("Cannot connect proxy: " + e.getMessage(), e);
        }
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        try {
            sendRequest(new Request("removeObserver", null));
            closeConnection();
        } catch (Exception ignored) {
        }
    }


    private void initializeConnection() throws IOException {
        if (isConnected) return;

        connection = new Socket(host, port);
        output = new ObjectOutputStream(connection.getOutputStream());
        output.flush();
        input = new ObjectInputStream(connection.getInputStream());

        new Thread(new ReaderThread()).start();
        isConnected = true;
    }



    @Override
    public Game startGame(String alias) throws Exception {
        sendRequest(new Request("startGame", new Object[]{alias}));
        Response response = readResponse();

        if (response.getType().equals("ok")) {
            return (Game) response.getData();
        } else {
            throw new Exception((String) response.getData());
        }
    }

    @Override
    public String makeAttempt(Long gameId, int row, int col) throws Exception {
        sendRequest(new Request("makeAttempt", new Object[]{gameId, row, col}));
        Response response = readResponse();

        if (response.getType().equals("ok")) {
            return (String) response.getData();
        } else {
            throw new Exception((String) response.getData());
        }
    }

    @Override
    public Hint addHint(Hint hint) throws Exception {
        sendRequest(new Request("addHint", new Object[]{hint}));
        Response response = readResponse();

        if (response.getType().equals("ok")) {
            return (Hint) response.getData();
        } else {
            throw new Exception((String) response.getData());
        }
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) throws Exception {
        sendRequest(new Request("getDetailedResults", new Object[]{alias}));
        Response response = readResponse();

        if (response.getType().equals("ok")) {
            return (List<GameResultDTO>) response.getData();
        } else {
            throw new Exception((String) response.getData());
        }
    }

    @Override
    public List<GameResultDTO> getResultsForAllPlayers() throws Exception {
        sendRequest(new Request("getResultsForAllPlayers", null));
        Response response = readResponse();

        if (response.getType().equals("ok")) {
            return (List<GameResultDTO>) response.getData();
        } else {
            throw new Exception((String) response.getData());
        }
    }

    private void sendRequest(Request request) throws IOException {
        synchronized (lock) {
            output.writeObject(request);
            output.flush();
        }
    }

    private Response readResponse() throws InterruptedException {
        return responses.take();
    }

    private class ReaderThread implements Runnable {
        public void run() {
            try {
                while (true) {
                    Object obj = input.readObject();
                    if (obj instanceof Response response && "gameFinished".equals(response.getType()) && client != null) {
                        client.gameFinished();
                    } else if (obj instanceof Response r) {
                        responses.put(r);
                    }
                }
            } catch (Exception e) {
                System.out.println("[Client] Reader thread stopped: " + e.getMessage());
            }
        }
    }

    private void closeConnection() throws IOException {
        if (input != null) input.close();
        if (output != null) output.close();
        if (connection != null) connection.close();
    }

}
