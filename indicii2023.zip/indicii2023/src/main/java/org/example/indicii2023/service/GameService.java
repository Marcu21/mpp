package org.example.indicii2023.service;

import org.example.indicii2023.domain.Game;
import org.example.indicii2023.domain.Hint;
import org.example.indicii2023.domain.Player;
import org.example.indicii2023.domain.GameAttempt;
import org.example.indicii2023.domain.dto.GameResultDTO;
import org.example.indicii2023.networking.IGameObserver;
import org.example.indicii2023.networking.IGameService;
import org.example.indicii2023.repository.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GameService implements IGameService {

    private final PlayerRepository playerRepo;
    private final HintRepository hintRepo;
    private final GameRepository gameRepo;
    private final GameAttemptRepository attemptRepo;
    private final List<IGameObserver> observers = new ArrayList<>();

    private final Random random = new Random();

    public GameService(PlayerRepository playerRepo, HintRepository hintRepo,
                       GameRepository gameRepo, GameAttemptRepository attemptRepo) {
        this.playerRepo = playerRepo;
        this.hintRepo = hintRepo;
        this.gameRepo = gameRepo;
        this.attemptRepo = attemptRepo;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        observers.remove(observer);
    }

    @Override
    public Game startGame(String alias) {
        Player player = null;
        Iterable<Player> players = playerRepo.findAll();
        for (Player p : players) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            player = new Player(null, alias);
            playerRepo.add(player);
        }

        List<Hint> hints = (List<Hint>) hintRepo.findAll();
        if (hints.isEmpty()) {
            throw new RuntimeException("Nu exista configuratii Hint.");
        }
        Hint chosenHint = hints.get(random.nextInt(hints.size()));

        Game game = new Game(player.getId(), chosenHint.getRow(), chosenHint.getCol(), LocalDateTime.now());
        gameRepo.add(game);

        return game;
    }

    public String makeAttempt(Long gameId, int row, int col) {
        Game game = gameRepo.findById(gameId);
        if (game == null) return "Joc inexistent.";
        if (game.isCompleted()) return "Jocul este deja terminat.";

        game.setAttempts(game.getAttempts() + 1);
        int targetRow = game.getTargetRow();
        int targetCol = game.getTargetCol();

        boolean guessed = row == targetRow && col == targetCol;
        String hintText = "";
        String feedback = "";

        if (guessed) {
            Iterable<Hint> hints = hintRepo.findAll();
            for (Hint h : hints) {
                if (h.getRow() == targetRow && h.getCol() == targetCol) {
                    hintText = h.getText();
                    break;
                }
            }

            game.setCompleted(true);
            game.setEndTime(LocalDateTime.now());
            feedback = "Corect! Mesajul era: \"" + hintText + "\"";
            notifyGameFinished();

        } else {
            if (row < targetRow) hintText = "mai jos";
            else if (row > targetRow) hintText = "mai sus";

            if (col < targetCol) {
                if (!hintText.isEmpty()) hintText += " si ";
                hintText += "mai la dreapta";
            } else if (col > targetCol) {
                if (!hintText.isEmpty()) hintText += " si ";
                hintText += "mai la stanga";
            }

            feedback = "Gresit. Incearca " + hintText + ".";

            if (game.getAttempts() == 4) {
                game.setCompleted(true);
                game.setEndTime(LocalDateTime.now());
                game.setAttempts(10);
                hintText = "";
                feedback = " Ai epuizat toate incercarile. Joc terminat!";
                notifyGameFinished();
            }
        }

        GameAttempt attempt = new GameAttempt(gameId, row, col, hintText, guessed);
        attemptRepo.add(attempt);


        gameRepo.update(game);
        return feedback;
    }



    public List<Game> getCompletedGamesForPlayer(String alias) {
        Player player = null;
        Iterable<Player> players = playerRepo.findAll();
        for (Player p : players) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            throw new RuntimeException("Jucator inexistent.");
        }

        List<Game> allGames = (List<Game>) gameRepo.findAll();
        List<Game> result = new java.util.ArrayList<>();

        for (Game g : allGames) {
            if (g.getPlayerId().equals(player.getId()) && g.isCompleted()) {
                result.add(g);
            }
        }

        return result;
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        List<GameResultDTO> results = new ArrayList<>();

        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            throw new RuntimeException("Jucator inexistent.");
        }

        for (Game game : gameRepo.findAll()) {
            if (game.getPlayerId().equals(player.getId()) && game.isCompleted()) {

                List<GameResultDTO.AttemptDTO> attemptList = new ArrayList<>();
                String finalHintText = "";

                if (game.getAttempts() < 10) {
                    for (Hint h : hintRepo.findAll()) {
                        if (h.getRow() == game.getTargetRow() && h.getCol() == game.getTargetCol()) {
                            finalHintText = h.getText();
                            break;
                        }
                    }
                }

                for (GameAttempt a : attemptRepo.findAll()) {
                    if (a.getGameId().equals(game.getId())) {
                        String hintToShow = "";

                        if (a.isGuessed() && game.getAttempts() < 10) {
                            hintToShow = finalHintText;
                        } else if (!a.isGuessed()) {
                            hintToShow = a.getHintText();
                        }

                        attemptList.add(new GameResultDTO.AttemptDTO(a.getRow(), a.getCol(), hintToShow));
                    }
                }

                GameResultDTO dto = new GameResultDTO(game.getId(), alias, game.getStartTime(), game.getAttempts(), finalHintText, attemptList
                );

                results.add(dto);
            }
        }

        return results;
    }



    @Override
    public Hint addHint(Hint hint) {
        if (hint == null) {
            throw new IllegalArgumentException("Hint-ul nu poate fi null");
        }

        try {
            hintRepo.add(hint);
            return hint;
        } catch (RuntimeException e) {
            System.err.println("Eroare la adaugarea hintului: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        List<GameResultDTO> results = new ArrayList<>();

        for (Player player : playerRepo.findAll()) {
            List<GameResultDTO> playerResults = getDetailedResultsForPlayer(player.getAlias());
            results.addAll(playerResults);
        }

        results.sort(Comparator.comparingInt(GameResultDTO::getAttempts));

        return results;
    }

    private void notifyGameFinished() {
        for (IGameObserver observer : observers) {
            try {
                observer.gameFinished();
            } catch (Exception e) {
                System.err.println("Eroare notificare: " + e.getMessage());
            }
        }
    }



}