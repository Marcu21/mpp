package org.example.indicii2023.rest;

import org.example.indicii2023.domain.dto.GameResultDTO;
import org.example.indicii2023.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:5174", "http://localhost:5175"})
@RestController
@RequestMapping("/api/game")
public class GameRestController {

    private final GameService gameService;

    public GameRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @GetMapping("/results/details/{alias}")
    public ResponseEntity<List<GameResultDTO>> getCompletedGamesForPlayer(@PathVariable String alias) {
        try {
            List<GameResultDTO> results = gameService.getDetailedResultsForPlayer(alias);
            return new ResponseEntity<>(results, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}