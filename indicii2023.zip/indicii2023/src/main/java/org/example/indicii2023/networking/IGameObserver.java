package org.example.indicii2023.networking;

import org.example.indicii2023.domain.dto.GameResultDTO;

public interface IGameObserver {
    void gameFinished() throws Exception;
}
