package org.example.indicii2023.domain;

import java.io.Serializable;

public class Hint extends EntityID<Long> implements Serializable {

    private static final long serialVersionUID = 1L;

    private int row;
    private int col;
    private String text;

    public Hint() {}

    public Hint(int row, int col, String text) {
        this.row = row;
        this.col = col;
        this.text = text;
    }

    public int getRow() { return row; }
    public void setRow(int row) { this.row = row; }

    public int getCol() { return col; }
    public void setCol(int col) { this.col = col; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    @Override
    public String toString() {
        return "Hint{" +
                "row=" + row +
                ", col=" + col +
                ", text='" + text + '\'' +
                '}';
    }
}