package org.example.indicii2023.server;

import org.example.indicii2023.networking.RequestHandler;
import org.example.indicii2023.repository.*;
import org.example.indicii2023.repository.hibernate.HibernateGameRepository;
import org.example.indicii2023.service.GameService;
import org.example.indicii2023.utils.HibernateUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    private static final int PORT = 5555;

    public static void main(String[] args) {
        PlayerRepository playerRepo   = new PlayerDBRepository();
        HintRepository hintRepo     = new HintDBRepository();
        GameRepository gameRepo     = new HibernateGameRepository(HibernateUtil.getSessionFactory());
        GameAttemptRepository attemptRepo = new GameAttemptDBRepository();

        GameService service = new GameService(playerRepo, hintRepo, gameRepo, attemptRepo);

        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket client = server.accept();
                new Thread(new RequestHandler(service, client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
