package org.example.indicii2023.repository;

import org.example.indicii2023.domain.Game;

public interface GameRepository extends Repository<Game, Long> {
}