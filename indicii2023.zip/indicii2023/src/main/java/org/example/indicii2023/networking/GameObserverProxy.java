package org.example.indicii2023.networking;

import org.example.indicii2023.domain.dto.GameResultDTO;

import java.io.ObjectOutputStream;

public class GameObserverProxy implements IGameObserver {
    private final ObjectOutputStream output;

    public GameObserverProxy(ObjectOutputStream output) {
        this.output = output;
    }

    @Override
    public void gameFinished() throws Exception {
        synchronized (output) {
            output.writeObject(new Response("gameFinished", null));
            output.flush();
        }
    }
}