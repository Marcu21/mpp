package org.example.indicii2023.domain;

import org.example.indicii2023.domain.EntityID;
import java.io.Serializable;

public class GameAttempt extends EntityID<Long> implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long gameId;
    private int row;
    private int col;
    private String hintText;
    private boolean guessed;

    public GameAttempt() {}

    public GameAttempt(Long gameId, int row, int col, String hintText, boolean guessed) {
        this.gameId   = gameId;
        this.row      = row;
        this.col      = col;
        this.hintText = hintText;
        this.guessed  = guessed;
    }

    public Long getGameId()          { return gameId; }
    public void setGameId(Long gameId){ this.gameId = gameId; }

    public int  getRow()             { return row; }
    public void setRow(int row)      { this.row = row; }

    public int  getCol()             { return col; }
    public void setCol(int col)      { this.col = col; }

    public String getHintText()      { return hintText; }
    public void setHintText(String hintText){ this.hintText = hintText; }

    public boolean isGuessed()       { return guessed; }
    public void setGuessed(boolean guessed){ this.guessed = guessed; }

    @Override
    public String toString() {
        return "GameAttempt{" +
                "gameId=" + gameId +
                ", row=" + row +
                ", col=" + col +
                ", hintText='" + hintText + '\'' +
                ", guessed=" + guessed +
                '}';
    }
}
