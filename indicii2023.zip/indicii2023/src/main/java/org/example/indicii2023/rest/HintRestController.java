package org.example.indicii2023.rest;

import org.example.indicii2023.domain.Hint;
import org.example.indicii2023.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/hints")
public class HintRestController {

    private final GameService gameService;

    public HintRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @PostMapping
    public ResponseEntity<Hint> createHint(@RequestBody Hint hint) {
        try {
            Hint saved = gameService.addHint(hint);
            return new ResponseEntity<>(saved, HttpStatus.CREATED);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}