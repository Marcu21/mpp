package org.example.indicii2023.domain.dto;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

public class GameResultDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long gameId;
    private String alias;
    private LocalDateTime startTime;
    private int attempts;
    private String finalHintText;
    private List<AttemptDTO> attemptsDetails;

    public GameResultDTO() { }

    public GameResultDTO(Long gameId, String alias, LocalDateTime startTime,
                         int attempts, String finalHintText, List<AttemptDTO> attemptsDetails) {
        this.gameId = gameId;
        this.alias = alias;
        this.startTime = startTime;
        this.attempts = attempts;
        this.finalHintText = finalHintText;
        this.attemptsDetails = attemptsDetails;
    }

    public Long getGameId() { return gameId; }
    public void setGameId(Long gameId) { this.gameId = gameId; }

    public String getAlias() { return alias; }
    public void setAlias(String alias) { this.alias = alias; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public int getAttempts() { return attempts; }
    public void setAttempts(int attempts) { this.attempts = attempts; }

    public String getFinalHintText() { return finalHintText; }
    public void setFinalHintText(String finalHintText) { this.finalHintText = finalHintText; }

    public List<AttemptDTO> getAttemptsDetails() { return attemptsDetails; }
    public void setAttemptsDetails(List<AttemptDTO> attemptsDetails) { this.attemptsDetails = attemptsDetails; }

    public static class AttemptDTO implements Serializable {

        private static final long serialVersionUID = 1L;

        private int row;
        private int col;
        private String hintText;

        public AttemptDTO() { }

        public AttemptDTO(int row, int col, String hintText) {
            this.row = row;
            this.col = col;
            this.hintText = hintText;
        }

        public int getRow() { return row; }
        public void setRow(int row) { this.row = row; }

        public int getCol() { return col; }
        public void setCol(int col) { this.col = col; }

        public String getHintText() { return hintText; }
        public void setHintText(String hintText) { this.hintText = hintText; }
    }
}
