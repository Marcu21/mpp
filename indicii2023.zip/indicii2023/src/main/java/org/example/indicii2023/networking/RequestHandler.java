package org.example.indicii2023.networking;

import org.example.indicii2023.domain.Hint;
import org.example.indicii2023.domain.Player;
import org.example.indicii2023.domain.dto.GameResultDTO;
import org.example.indicii2023.service.GameService;
import org.example.indicii2023.domain.Game;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

public class RequestHandler implements Runnable {
    private final IGameService service;
    private final Socket clientSocket;

    public RequestHandler(IGameService service, Socket clientSocket) {
        this.service = service;
        this.clientSocket = clientSocket;
    }

    public void run() {
        try (ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream())) {

            out.flush();

            while (true) {
                Object obj = in.readObject();
                if (obj instanceof Request req) {
                    Response resp = handleRequest(req, out);
                    out.writeObject(resp);
                    out.flush();
                }
            }
        } catch (Exception e) {
            System.out.println("[Server] Client disconnected or error: " + e.getMessage());
        }
    }

    private Response handleRequest(Request request, ObjectOutputStream out) {
        String type = request.getType();
        Object[] data = request.getData();

        try {
            return switch (type) {
                case "addObserver" -> {
                    IGameObserver observer = new GameObserverProxy(out);
                    service.addObserver(observer);
                    yield new Response("ok", null);
                }
                case "removeObserver" -> {
                    IGameObserver observer = new GameObserverProxy(out);
                    service.removeObserver(observer);
                    yield new Response("ok", null);
                }
                case "startGame" -> {
                    String alias = (String) data[0];
                    Game game = service.startGame(alias);
                    yield new Response("ok", game);
                }
                case "makeAttempt" -> {
                    Long gameId = (Long) data[0];
                    int row = (Integer) data[1];
                    int col = (Integer) data[2];
                    String result = service.makeAttempt(gameId, row, col);
                    yield new Response("ok", result);
                }
                case "getDetailedResults" -> {
                    String alias = (String) data[0];
                    List<GameResultDTO> results = service.getDetailedResultsForPlayer(alias);
                    yield new Response("ok", results);
                }
                case "getResultsForAllPlayers" -> {
                    List<GameResultDTO> results = service.getResultsForAllPlayers();
                    yield new Response("ok", results);
                }
                case "addHint" -> {
                    Hint hint = (Hint) data[0];
                    Hint saved = service.addHint(hint);
                    yield new Response("ok", saved);
                }
                default -> new Response("error", "Unknown request type: " + type);
            };
        } catch (Exception e) {
            return new Response("error", e.getMessage());
        }
    }
}