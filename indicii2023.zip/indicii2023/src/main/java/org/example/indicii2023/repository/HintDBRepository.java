package org.example.indicii2023.repository;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.indicii2023.domain.Hint;
import org.example.indicii2023.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class HintDBRepository implements HintRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public HintDBRepository() {
        logger.info("Initializing HintDBRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(Hint hint) {
        logger.traceEntry("Saving hint {}", hint);
        String sql = "INSERT INTO Hint (row, col, text) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, hint.getRow());
            stmt.setInt(2, hint.getCol());
            stmt.setString(3, hint.getText());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    hint.setId(keys.getLong(1));
                }
            }
            logger.trace("Saved {}", hint);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<Hint> findAll() {
        logger.traceEntry();
        List<Hint> hints = new ArrayList<>();
        String sql = "SELECT * FROM Hint";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Long id = rs.getLong("id");
                int row = rs.getInt("row");
                int col = rs.getInt("col");
                String text = rs.getString("text");
                Hint h = new Hint(row, col, text);
                h.setId(id);
                hints.add(h);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit(hints);
        return hints;
    }

    @Override
    public void delete(Hint hint) {
        logger.traceEntry("Deleting hint {}", hint);
        String sql = "DELETE FROM Hint WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, hint.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", hint);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public void update(Hint hint) {
        logger.traceEntry("Updating hint {}", hint);
        String sql = "UPDATE Hint SET row=?, col=?, text=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, hint.getRow());
            stmt.setInt(2, hint.getCol());
            stmt.setString(3, hint.getText());
            stmt.setLong(4, hint.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", hint);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public Hint findById(Long id) {
        logger.traceEntry("Finding hint by id {}", id);
        String sql = "SELECT * FROM Hint WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int row = rs.getInt("row");
                    int col = rs.getInt("col");
                    String text = rs.getString("text");
                    Hint h = new Hint(row, col, text);
                    h.setId(id);
                    logger.traceExit(h);
                    return h;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Hint> getAll() {
        return (Collection<Hint>) findAll();
    }
}