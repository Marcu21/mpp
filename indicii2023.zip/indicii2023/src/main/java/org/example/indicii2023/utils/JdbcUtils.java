package org.example.indicii2023.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtils {
    private Connection connection;
    private final String dbUrl;

    public JdbcUtils() {
        Properties props = ConfigLoader.loadProperties();
        this.dbUrl = props.getProperty("jdbc.url");
        initializeConnection();
    }

    private void initializeConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(dbUrl);
                System.out.println("Conexiune reusita la baza de date");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Eroare la conectarea la baza de date: " + e.getMessage());
        }
    }

    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                initializeConnection();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Conexiunea la baza de date a fost inchisa");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
