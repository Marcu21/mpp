package org.example.indicii2023.domain;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "Game")
public class Game extends EntityID<Long> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "player_id", nullable = false)
    private Long playerId;

    @Column(nullable = false)
    private int targetRow;

    @Column(nullable = false)
    private int targetCol;

    @Column(nullable = false)
    private int attempts;

    @Column(nullable = false)
    private boolean completed;

    @Column(nullable = false)
    private LocalDateTime startTime;

    private LocalDateTime endTime;

    public Game() {}

    public Game(Long playerId, int targetRow, int targetCol, LocalDateTime startTime) {
        this.playerId = playerId;
        this.targetRow = targetRow;
        this.targetCol = targetCol;
        this.attempts = 0;
        this.completed = false;
        this.startTime = startTime;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Long getPlayerId() { return playerId; }
    public void setPlayerId(Long playerId) { this.playerId = playerId; }

    public int getTargetRow() { return targetRow; }
    public void setTargetRow(int targetRow) { this.targetRow = targetRow; }

    public int getTargetCol() { return targetCol; }
    public void setTargetCol(int targetCol) { this.targetCol = targetCol; }

    public int getAttempts() { return attempts; }
    public void setAttempts(int attempts) { this.attempts = attempts; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
}
