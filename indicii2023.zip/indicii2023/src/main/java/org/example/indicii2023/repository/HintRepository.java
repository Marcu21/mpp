package org.example.indicii2023.repository;

import org.example.indicii2023.domain.Hint;

public interface HintRepository extends Repository<Hint, Long> {
}