package org.example.indicii2023.utils;

import org.example.indicii2023.repository.*;
import org.example.indicii2023.repository.hibernate.HibernateGameRepository;
import org.example.indicii2023.utils.JdbcUtils;
import org.example.indicii2023.service.GameService;
import org.example.indicii2023.utils.HibernateUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public PlayerRepository playerRepository() {
        return new PlayerDBRepository();
    }

    @Bean
    public HintRepository hintRepository() {
        return new HintDBRepository();
    }

    @Bean
    public GameAttemptRepository gameAttemptRepository() {
        return new GameAttemptDBRepository();
    }

    @Bean
    public GameRepository gameRepository() {
        return new HibernateGameRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public GameService gameService() {
        return new GameService(
                playerRepository(),
                hintRepository(),
                gameRepository(),
                gameAttemptRepository()
        );
    }
}
