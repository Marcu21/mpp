package org.example.indicii2023.controller;

import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.indicii2023.domain.dto.GameResultDTO;
import org.example.indicii2023.networking.GameServiceProxy;
import org.example.indicii2023.networking.IGameObserver;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class GameController implements IGameObserver {

    @FXML private TextField  aliasField;
    @FXML private TextArea   messageArea;
    @FXML private GridPane   grid;

    @FXML private TableView<GameResultDTO> leaderboardTable;
    @FXML private TableColumn<GameResultDTO,String> colAlias;
    @FXML private TableColumn<GameResultDTO,String> colStart;
    @FXML private TableColumn<GameResultDTO,Integer> colAttempts;
    @FXML private TableColumn<GameResultDTO,String> colHint;

    private final GameServiceProxy service = new GameServiceProxy("localhost", 5555);

    private Long   currentGameId  = null;
    private String currentAlias   = null;
    private int    attemptCount   = 0;

    private static final int MAX_TRIES = 4;

    @FXML
    public void initialize() throws Exception {
        initLeaderboardTable();
        populateGrid();
    }


    private void initLeaderboardTable() {
        colAlias.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getAlias())
        );

        colStart.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().getStartTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")))
        );

        colAttempts.setCellValueFactory(data ->
                new SimpleObjectProperty<>(data.getValue().getAttempts())
        );

        colHint.setCellValueFactory(data -> {
            GameResultDTO dto = data.getValue();
            String finalHint = "";

            if (dto.getAttempts() < 10) {
                List<GameResultDTO.AttemptDTO> attempts = dto.getAttemptsDetails();
                for (GameResultDTO.AttemptDTO a : attempts) {
                    if (!a.getHintText().isEmpty()) {
                        finalHint = a.getHintText();
                    }
                }
            }

            return new SimpleStringProperty(finalHint);
        });

    }

    @FXML
    public void handleStartGame() {
        int ok = 1;
        if (currentAlias != null)
        {
            ok = 0;
        }
        currentAlias  = aliasField.getText().trim();
        if (currentAlias.isEmpty()) {
            messageArea.setText("Aliasul nu poate fi gol!");
            return;
        }

        try {
            if( ok == 1) {
                service.addObserver(this);
            }
            currentGameId = service.startGame(currentAlias).getId();
            attemptCount  = 0;
            messageArea.setText("Joc pornit! Alege o pozitie (max. 4 incercari).");
            updateLeaderboard();
        } catch (Exception e) {
            messageArea.setText("Eroare: " + e.getMessage());
        }
    }

    private void populateGrid() {
        grid.getChildren().clear();

        for (int r = 1; r <= 4; r++) {
            for (int c = 1; c <= 4; c++) {
                Button cell = new Button(r + "," + c);
                int row = r, col = c;
                cell.setPrefSize(60, 60);
                cell.setOnAction(ev -> handleAttempt(row, col));
                grid.add(cell, col - 1, row - 1);
            }
        }
    }

    private void handleAttempt(int row, int col) {
        if (currentGameId == null) {
            messageArea.setText("Porneste mai intai un joc.");
            return;
        }
        if (attemptCount >= MAX_TRIES) {
            messageArea.setText("Ai epuizat cele 4 incercari");
            return;
        }

        attemptCount++;

        try {
            String result = service.makeAttempt(currentGameId, row, col);
            messageArea.setText(result);

            boolean guessed = result.startsWith("Corect");
            boolean noMoreTries = !guessed && attemptCount >= MAX_TRIES;

            if (guessed || noMoreTries) {
                finalizeGame(guessed);
            }
        } catch (Exception e) {
            messageArea.setText("Eroare la incercare: " + e.getMessage());
        }
    }

    private void finalizeGame(boolean guessed) {
        currentGameId = null;
        updateLeaderboard();
    }

    private void updateLeaderboard() {
        try {
            List<GameResultDTO> results = service.getResultsForAllPlayers();
            leaderboardTable.getItems().setAll(results);
        } catch (Exception e) {
            messageArea.setText("Eroare la actualizarea clasamentului: " + e.getMessage());
        }
    }

    @Override
    public void gameFinished() {
        Platform.runLater(this::updateLeaderboard);
    }

    public void handleDisconnect() {
        try {
            service.removeObserver(this);
            messageArea.setText("Deconectare reusita.");
        } catch (Exception e) {
            messageArea.setText("Eroare la deconectare: " + e.getMessage());
        }
    }
}