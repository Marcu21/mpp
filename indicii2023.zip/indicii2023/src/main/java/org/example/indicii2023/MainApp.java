package org.example.indicii2023;
import javafx.application.Application;

public class MainApp {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
