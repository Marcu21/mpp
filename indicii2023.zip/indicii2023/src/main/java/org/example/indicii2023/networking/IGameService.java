package org.example.indicii2023.networking;

import org.example.indicii2023.domain.Game;
import org.example.indicii2023.domain.Hint;
import org.example.indicii2023.domain.dto.GameResultDTO;

import java.util.List;

public interface IGameService {
    void addObserver(IGameObserver observer);
    void removeObserver(IGameObserver observer);
    Game startGame(String alias) throws Exception;
    String makeAttempt(Long gameId, int row, int col) throws Exception;
    List<GameResultDTO> getDetailedResultsForPlayer(String alias) throws Exception;
    Hint addHint(Hint hint) throws Exception;
    List<GameResultDTO> getResultsForAllPlayers() throws Exception;
}