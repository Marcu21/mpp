package org.example.cuvinte.networking;

public interface IGameObserver {
    void scoreboardUpdated();
}