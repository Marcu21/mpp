package org.example.cuvinte.repository;

import org.example.cuvinte.domain.GameAttempt;

public interface GameAttemptRepository extends Repository<GameAttempt, Long> {
}