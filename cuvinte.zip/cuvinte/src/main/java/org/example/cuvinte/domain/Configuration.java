package org.example.cuvinte.domain;

import java.io.Serializable;

public class Configuration extends EntityID<Long> implements Serializable {

    private static final long serialVersionUID = 1L;

    private String letters;

    private String words;

    public Configuration() {
    }

    public Configuration(String letters, String words) {
        this.letters = letters;
        this.words = words;
    }

    public Configuration(Long id, String letters, String words) {
        setId(id);
        this.letters = letters;
        this.words = words;
    }

    public String getLetters() {
        return letters;
    }

    public void setLetters(String letters) {
        this.letters = letters;
    }

    public String getWords() {
        return words;
    }

    public void setWords(String words) {
        this.words = words;
    }
}