package org.example.cuvinte.domain;

import java.io.Serializable;

public class GameAttempt extends EntityID<Long> implements Serializable {

    private Long id;
    private Long gameId;
    private String word;
    private int correct;

    public GameAttempt() {}

    public GameAttempt(Long id, Long gameId, String word, int correct) {
        setId(id);
        this.gameId = gameId;
        this.word = word;
        this.correct = correct;
    }

    public GameAttempt(Long gameId, String word, int correct) {
        this.gameId = gameId;
        this.word = word;
        this.correct = correct;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public int getCorrect() {
        return correct;
    }

    public void setCorrect(int correct) {
        this.correct = correct;
    }
}
