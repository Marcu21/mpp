package org.example.cuvinte.repository;

import org.example.cuvinte.domain.Player;

public interface PlayerRepository extends Repository<Player, Long> {
}