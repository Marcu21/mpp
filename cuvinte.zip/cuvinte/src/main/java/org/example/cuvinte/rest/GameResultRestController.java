package org.example.cuvinte.rest;

import org.example.cuvinte.domain.dto.GameResultDTO;
import org.example.cuvinte.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/results")
public class GameResultRestController {

    private final GameService gameService;

    public GameResultRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @GetMapping("/min2/{alias}")
    public ResponseEntity<List<GameResultDTO>> getResultsForPlayerMin2Guessed(@PathVariable String alias) {
        try {
            List<GameResultDTO> result = gameService.getResultsForPlayerMin2Guessed(alias);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

}
