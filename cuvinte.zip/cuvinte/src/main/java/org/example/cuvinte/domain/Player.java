package org.example.cuvinte.domain;

import java.io.Serializable;

public class Player extends EntityID<Long> implements Serializable {

    private static final long serialVersionUID = 1L;

    private String alias;

    public Player() { }

    public Player(Long id, String alias) {
        setId(id);
        this.alias = alias;
    }

    public Player(String alias) {
        this.alias = alias;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    @Override
    public String toString() {
        return "Player{" +
                "id=" + getId() +
                ", alias='" + alias + '\'' +
                '}';
    }
}