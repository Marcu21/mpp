package org.example.cuvinte.repository;

import java.util.Collection;

public interface Repository<T, Tid> {
    void add(T elem);
    void delete(T elem);
    void update(T elem);
    T findById(Tid id);
    Iterable<T> findAll();
    Collection<T> getAll();

}

