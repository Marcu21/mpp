package org.example.cuvinte.networking;

import org.example.cuvinte.domain.Configuration;
import org.example.cuvinte.domain.Game;
import org.example.cuvinte.domain.GameAttempt;
import org.example.cuvinte.domain.dto.GameResultDTO;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class GameServiceProxy implements IGameService {

    private final String host;
    private final int port;
    private IGameObserver client;
    private String alias;

    private ObjectInputStream input;
    private ObjectOutputStream output;
    private Socket connection;

    private final Object lock = new Object();
    private final BlockingQueue<Response> responses = new LinkedBlockingQueue<>();

    public GameServiceProxy(String host, int port) {
        this.host = host;
        this.port = port;
    }

    private void initializeConnection() throws IOException {
        connection = new Socket(host, port);
        output = new ObjectOutputStream(connection.getOutputStream());
        output.flush();
        input = new ObjectInputStream(connection.getInputStream());
        new Thread(new ReaderThread()).start();
    }

    private void closeConnection() throws IOException {
        if (input != null) input.close();
        if (output != null) output.close();
        if (connection != null) connection.close();
    }

    private void sendRequest(Request req) throws IOException {
        synchronized (lock) {
            output.writeObject(req);
            output.flush();
        }
    }

    private Response readResponse() throws InterruptedException {
        return responses.take();
    }

    @Override
    public void addObserver(IGameObserver observer) {
        this.client = observer;
        try {
            initializeConnection();
            sendRequest(new Request("addObserver", null));
            Response response = readResponse();
            if (!response.getType().equals("ok"))
                throw new RuntimeException((String) response.getData());
        } catch (Exception e) {
            throw new RuntimeException("Cannot connect proxy: " + e.getMessage(), e);
        }
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        try {
            sendRequest(new Request("removeObserver", null));
            closeConnection();
        } catch (Exception ignored) {
        }
    }

    @Override
    public Game startGame(String alias) {
        try {
            sendRequest(new Request("startGame", new Object[]{alias}));
            Response resp = readResponse();
            if (!resp.getType().equals("ok"))
                throw new RuntimeException((String) resp.getData());
            return (Game) resp.getData();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String makeAttempt(Long gameId, String word) {
        try {
            sendRequest(new Request("makeAttempt", new Object[]{gameId, word}));
            Response resp = readResponse();
            if (!resp.getType().equals("ok"))
                throw new RuntimeException((String) resp.getData());
            return (String) resp.getData();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        try {
            sendRequest(new Request("getResultsForAllPlayers", null));
            Response resp = readResponse();
            if (!resp.getType().equals("ok"))
                throw new RuntimeException((String) resp.getData());
            return (List<GameResultDTO>) resp.getData();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        try {
            sendRequest(new Request("getDetailedResults", new Object[]{alias}));
            Response resp = readResponse();
            if (!resp.getType().equals("ok"))
                throw new RuntimeException((String) resp.getData());
            return (List<GameResultDTO>) resp.getData();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<GameAttempt> getAttemptsForGame(Long gameId) {
        try {
            sendRequest(new Request("getAttemptsForGame", new Object[]{gameId}));
            Response resp = readResponse();
            if (!resp.getType().equals("ok"))
                throw new RuntimeException((String) resp.getData());
            return (List<GameAttempt>) resp.getData();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Game getGameById(Long gameId) {
        try {
            sendRequest(new Request("getGameById", new Object[]{gameId}));
            Response resp = readResponse();
            if (!resp.getType().equals("ok"))
                throw new RuntimeException((String) resp.getData());
            return (Game) resp.getData();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Configuration getConfigurationById(Long configId) {
        try {
            sendRequest(new Request("getConfigurationById", new Object[]{configId}));
            Response resp = readResponse();
            if (!resp.getType().equals("ok"))
                throw new RuntimeException((String) resp.getData());
            return (Configuration) resp.getData();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private class ReaderThread implements Runnable {
        public void run() {
            try {
                while (true) {
                    Object obj = input.readObject();
                    if (obj instanceof Response resp) {
                        if ("scoreboardUpdated".equals(resp.getType())) {
                            if (client != null) client.scoreboardUpdated();
                        } else {
                            responses.put(resp);
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println("[Proxy] Reader stopped: " + e.getMessage());
            }
        }
    }
}
