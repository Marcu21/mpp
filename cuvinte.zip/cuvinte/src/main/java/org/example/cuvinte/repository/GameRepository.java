package org.example.cuvinte.repository;

import org.example.cuvinte.domain.Game;

public interface GameRepository extends Repository<Game, Long> {
}
