package org.example.cuvinte.repository;

import org.example.cuvinte.domain.Configuration;

public interface ConfigurationRepository extends Repository<Configuration, Long> {
}