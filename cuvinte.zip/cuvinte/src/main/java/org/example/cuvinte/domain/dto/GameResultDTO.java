package org.example.cuvinte.domain.dto;

import java.io.Serializable;
import java.util.List;

public class GameResultDTO implements Serializable {

    private Long gameId;
    private String alias;
    private int score;
    private String startTime;
    private List<String> correctWords;
    private List<PosDTO> attempts;

    public GameResultDTO(Long gameId,
                         String alias,
                         int score,
                         String startTime,
                         List<String> correctWords,
                         List<PosDTO> attempts) {
        this.gameId = gameId;
        this.alias = alias;
        this.score = score;
        this.startTime = startTime;
        this.correctWords = correctWords;
        this.attempts = attempts;
    }

    public Long getGameId() { return gameId; }
    public String getAlias() { return alias; }
    public int getScore() { return score; }
    public List<String> getCorrectWords() { return correctWords; }
    public String getStartTime() { return startTime; }
    public List<PosDTO> getAttempts() { return attempts; }

    public static class PosDTO implements Serializable {
        private String word;
        private int correct;

        public PosDTO(String word, int correct) {
            this.word = word;
            this.correct = correct;
        }
        public String getWord() { return word; }
        public int getCorrect() { return correct; }
    }
}
