package org.example.cuvinte.utils;

import org.example.cuvinte.repository.*;
import org.example.cuvinte.repository.db.GameAttemptDBRepository;
import org.example.cuvinte.repository.db.PlayerDBRepository;
import org.example.cuvinte.repository.db.ConfigurationDBRepository;
import org.example.cuvinte.repository.hibernate.HibernateGameRepository;
import org.example.cuvinte.service.GameService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public PlayerRepository playerRepository() {
        return new PlayerDBRepository();
    }

    @Bean
    public GameAttemptRepository gameAttemptRepository() {
        return new GameAttemptDBRepository();
    }

    @Bean
    public GameRepository gameRepository() {
        return new HibernateGameRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public ConfigurationRepository configurationRepository() {return new ConfigurationDBRepository();}

    @Bean
    public GameService gameService() {
        return new GameService(
                playerRepository(),
                gameRepository(),
                gameAttemptRepository(),
                configurationRepository()
        );
    }
}
