package org.example.cuvinte.networking;

import org.example.cuvinte.domain.Configuration;
import org.example.cuvinte.domain.Game;
import org.example.cuvinte.domain.GameAttempt;
import org.example.cuvinte.domain.dto.GameResultDTO;

import java.util.List;

public interface IGameService {
    void addObserver(IGameObserver observer);
    void removeObserver(IGameObserver observer);

    Game startGame(String alias);
    String makeAttempt(Long gameId, String word);

    List<GameResultDTO> getResultsForAllPlayers();
    List<GameResultDTO> getDetailedResultsForPlayer(String alias);
    List<GameAttempt> getAttemptsForGame(Long gameId);

    Game getGameById(Long gameId);
    Configuration getConfigurationById(Long configId);
}
