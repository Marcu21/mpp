package com.example.litere.domain;

import java.io.Serializable;

public class Pair extends EntityID<Long> implements Serializable {

    private Long id;
    private String letter;
    private int value;

    public Pair() {}

    public Pair(Long id, String letter, int value) {
        setId(id);
        this.letter = letter;
        this.value = value;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public String getLetter() {
        return letter;
    }

    public void setLetter(String letter) {
        this.letter = letter;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Boat{" +
                "id=" + id +
                '}';
    }
}
