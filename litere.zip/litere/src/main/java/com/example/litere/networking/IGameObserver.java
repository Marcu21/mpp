package com.example.litere.networking;

public interface IGameObserver {
    void scoreboardUpdated();
}