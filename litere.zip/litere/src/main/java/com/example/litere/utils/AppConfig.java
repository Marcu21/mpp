package com.example.litere.utils;

import com.example.litere.repository.*;
import com.example.litere.repository.db.PairDBRepository;
import com.example.litere.repository.db.GamePairDBRepository;
import com.example.litere.repository.db.GameAttemptDBRepository;
import com.example.litere.repository.hibernate.HibernateGameRepository;
import com.example.litere.repository.hibernate.HibernatePlayerRepository;
import com.example.litere.service.GameService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public PlayerRepository playerRepository() {
        return new HibernatePlayerRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public PairRepository pairRepository() {return new PairDBRepository();}

    @Bean
    public GamePairDBRepository gamePairDBRepository() {return new GamePairDBRepository();}

    @Bean
    public GameAttemptRepository gameAttemptRepository() {
        return new GameAttemptDBRepository();
    }

    @Bean
    public GameRepository gameRepository() {
        return new HibernateGameRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public GameService gameService() {
        return new GameService(
                playerRepository(),
                gameRepository(),
                gameAttemptRepository(),
                pairRepository(),
                gamePairDBRepository()
        );
    }
}
