package com.example.litere.rest;

import com.example.litere.domain.Pair;
import com.example.litere.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/pairs")
public class PairRestController {

    private final GameService gameService;

    public PairRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @PutMapping("/{gameId}")
    public ResponseEntity<List<Pair>> updatePairsForGame(@PathVariable Long gameId, @RequestBody List<Pair> pairs) {
        try {
            List<Pair> updated = gameService.modifyPairsForGame(gameId, pairs);
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/{gameId}")
    public ResponseEntity<List<Pair>> getPairsForGame(@PathVariable Long gameId) {
        try {
            List<Pair> pairs = gameService.getPairsForGame(gameId);
            return new ResponseEntity<>(pairs, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}


/*
PUT http://localhost:8080/api/pairs/6

[
  { "letter": "J", "value": 5 },
  { "letter": "K", "value": 6 },
  { "letter": "L", "value": 7 },
  { "letter": "M", "value": 8 }
]

 */