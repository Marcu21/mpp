package com.example.litere.repository;

import com.example.litere.domain.GamePair;

public interface GamePairRepository extends Repository<GamePair, Long>{
}

