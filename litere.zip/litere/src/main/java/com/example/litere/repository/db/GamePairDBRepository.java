package com.example.litere.repository.db;

import com.example.litere.domain.GamePair;
import com.example.litere.repository.GamePairRepository;
import com.example.litere.utils.JdbcUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class GamePairDBRepository implements GamePairRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public GamePairDBRepository() {
        logger.info("Initializing GamePairRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(GamePair gamePair) {
        logger.traceEntry("Saving gamePair {}", gamePair);
        String sql = "INSERT INTO GamePair (game_id, pair_id) VALUES (?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setLong(1, gamePair.getGameId());
            stmt.setLong(2, gamePair.getPairId());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    gamePair.setId(keys.getLong(1));
                }
            }

            logger.trace("Saved {}", gamePair);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }

        logger.traceExit();
    }

    @Override
    public Iterable<GamePair> findAll() {
        logger.traceEntry();
        List<GamePair> gamePairs = new ArrayList<>();
        String sql = "SELECT * FROM GamePair";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                GamePair gamePair = extractGamePair(rs);
                gamePairs.add(gamePair);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(gamePairs);
        return gamePairs;
    }

    @Override
    public void delete(GamePair gamePair) {
        logger.traceEntry("Deleting gamePair {}", gamePair);
        String sql = "DELETE FROM GamePair WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, gamePair.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", gamePair);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public void update(GamePair gamePair) {
        logger.traceEntry("Updating gamePair {}", gamePair);
        String sql = "UPDATE GamePair SET game_id=?, pair_id=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, gamePair.getGameId());
            stmt.setLong(2, gamePair.getPairId());
            stmt.setLong(3, gamePair.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", gamePair);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public GamePair findById(Long id) {
        logger.traceEntry("Finding gamePair by id {}", id);
        String sql = "SELECT * FROM GamePair WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    GamePair gamePair = extractGamePair(rs);
                    logger.traceExit(gamePair);
                    return gamePair;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<GamePair> getAll() {
        return (Collection<GamePair>) findAll();
    }

    private GamePair extractGamePair(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        Long gameId = rs.getLong("game_id");
        Long pairId = rs.getLong("pair_id");
        return new GamePair(id, gameId, pairId);
    }
}
