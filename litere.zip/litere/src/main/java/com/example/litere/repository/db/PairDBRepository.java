package com.example.litere.repository.db;

import com.example.litere.domain.Pair;
import com.example.litere.repository.PairRepository;
import com.example.litere.utils.JdbcUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class PairDBRepository implements PairRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public PairDBRepository() {
        logger.info("Initializing PairRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(Pair pair) {
        logger.traceEntry("Saving pair {}", pair);
        String sql = "INSERT INTO Pair (letter, value) VALUES (?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, pair.getLetter());
            stmt.setInt(2, pair.getValue());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    pair.setId(keys.getLong(1));
                }
            }

            logger.trace("Saved {}", pair);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }

        logger.traceExit();
    }

    @Override
    public Iterable<Pair> findAll() {
        logger.traceEntry();
        List<Pair> pairs = new ArrayList<>();
        String sql = "SELECT * FROM Pair";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Pair pair = extractPair(rs);
                pairs.add(pair);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(pairs);
        return pairs;
    }

    @Override
    public void delete(Pair pair) {
        logger.traceEntry("Deleting pair {}", pair);
        String sql = "DELETE FROM Pair WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, pair.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", pair);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public void update(Pair pair) {
        logger.traceEntry("Updating pair {}", pair);
        logger.traceExit();
    }

    @Override
    public Pair findById(Long id) {
        logger.traceEntry("Finding pair by id {}", id);
        String sql = "SELECT * FROM Pair WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Pair pair = extractPair(rs);
                    logger.traceExit(pair);
                    return pair;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Pair> getAll() {
        return (Collection<Pair>) findAll();
    }

    private Pair extractPair(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        String letter = rs.getString("letter");
        int value = rs.getInt("value");
        return new Pair(id, letter, value);
    }
}
