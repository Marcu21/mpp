package com.example.litere.service;

import com.example.litere.domain.*;
import com.example.litere.domain.dto.GameResultDTO;
import com.example.litere.networking.IGameObserver;
import com.example.litere.networking.IGameService;
import com.example.litere.repository.*;

import java.time.LocalDateTime;
import java.util.*;

public class GameService implements IGameService {

    private final PlayerRepository playerRepo;
    private final GameRepository gameRepo;
    private final GameAttemptRepository attemptRepo;
    private final PairRepository pairRepo;
    private final GamePairRepository gamePairRepo;
    private final List<IGameObserver> observers = new ArrayList<>();

    private final Random random = new Random();

    public GameService(PlayerRepository playerRepo,
                       GameRepository gameRepo,
                       GameAttemptRepository attemptRepo,
                       PairRepository pairRepo,
                       GamePairRepository gamePairRepo) {
        this.playerRepo = playerRepo;
        this.gameRepo = gameRepo;
        this.attemptRepo = attemptRepo;
        this.pairRepo = pairRepo;
        this.gamePairRepo = gamePairRepo;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        observers.remove(observer);
    }

    @Override
    public Game startGame(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            player = new Player(null, alias);
            playerRepo.add(player);
        }

        List<Pair> pairs = (List<Pair>) pairRepo.findAll();
        if (pairs.isEmpty()) {
            throw new RuntimeException("Nu exista Pairs.");
        }

        Game game = new Game(player.getId(), LocalDateTime.now());
        gameRepo.add(game);

        Set<Long> usedPairIds = new HashSet<>();
        Random random = new Random();

        while (usedPairIds.size() < 4) {
            Pair pair = pairs.get(random.nextInt(pairs.size()));
            if (usedPairIds.add(pair.getId())) {
                gamePairRepo.add(new GamePair(game.getId(), pair.getId()));
            }
        }

        return game;
    }

    @Override
    public String makeAttempt(Long gameId, String playerLetter) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }

        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId) && a.getPlayerLetter().equalsIgnoreCase(playerLetter)){
                return "Ai incercat deja aceasta litera!";
            }
        }

        Pair playerPair = null;

        for (Pair p : getPairsForGame(gameId)) {
            if (p.getLetter().equalsIgnoreCase(playerLetter)) {
                playerPair = p;
                break;
            }
        }

        if (playerPair == null) {
            return "Litera nu este valida.";
        }

        String result = procesareLitere(game, playerPair);

        if (getAttemptsForGame(gameId).size() == 4) {
            game.setEndTime(LocalDateTime.now());
        }

        gameRepo.update(game);

        if (game.getEndTime() != null) {
            notifyGameFinished();
            return buildEndMessage(result, gameId);
        }

        return result;
    }


    private String procesareLitere(Game game, Pair playerPair) {
        Set<String> pairsUsedServer = new HashSet<>();
        for (GameAttempt a : getAttemptsForGame(game.getId())) {
            pairsUsedServer.add(a.getServerLetter().toLowerCase());
        }

        List<Pair> pairsRemainedServer = new ArrayList<>();
        for (Pair p : getPairsForGame(game.getId())) {
            if (!pairsUsedServer.contains(p.getLetter().toLowerCase())) {
                pairsRemainedServer.add(p);
            }
        }

        Pair serverPair = pairsRemainedServer.get(random.nextInt(pairsRemainedServer.size()));

        GameAttempt attempt = new GameAttempt(
                game.getId(),
                playerPair.getLetter(), playerPair.getValue(),
                serverPair.getLetter(), serverPair.getValue()
        );
        attemptRepo.add(attempt);

        if (playerPair.getValue() > serverPair.getValue()) {
            game.setScore(game.getScore() + playerPair.getValue() + serverPair.getValue());
            return "Ai castigat runda! Serverul a ales: (" + serverPair.getLetter() + serverPair.getValue() + ")\n+" + (playerPair.getValue() + serverPair.getValue()) + " puncte";
        } else if (playerPair.getValue() < serverPair.getValue()) {
            game.setScore(game.getScore() - playerPair.getValue());
            return "Ai pierdut runda! Serverul a ales: (" + serverPair.getLetter() + serverPair.getValue() + ")\n-" + playerPair.getValue() + " puncte";
        } else {
            return "Egalitate! Serverul a ales: (" + serverPair.getLetter() + serverPair.getValue() + ")\nNu ai castigat sau pierdut puncte";
        }

    }



    private String buildEndMessage(String baseMessage, Long gameId) {
        Game game = gameRepo.findById(gameId);
        StringBuilder sb = new StringBuilder(baseMessage);
        sb.append("\nPunctaj final: ").append(game.getScore());

        return sb.toString();
    }


    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getEndTime() != null) {
                Player p = playerRepo.findById(g.getPlayerId());
                results.add(new GameResultDTO(g.getId(), p.getAlias(), g.getScore(), g.getStartTime(), new ArrayList<>(), new ArrayList<>()));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : a.getStartTime().compareTo(b.getStartTime());
        });
        return results;
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) throw new RuntimeException("Jucator inexistent.");

        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getPlayerId().equals(player.getId()) && g.getEndTime() != null) {

                List<GameResultDTO.ChoiceDTO> playerChoices = new ArrayList<>();
                List<GameResultDTO.ChoiceDTO> serverChoices = new ArrayList<>();
                for (GameAttempt a : attemptRepo.findAll()) {
                    if (a.getGameId().equals(g.getId())) {
                        playerChoices.add(new GameResultDTO.ChoiceDTO(a.getPlayerLetter(), a.getPlayerValue()));
                        serverChoices.add(new GameResultDTO.ChoiceDTO(a.getServerLetter(), a.getServerValue()));
                    }
                }

                results.add(new GameResultDTO(g.getId(), alias, g.getScore(), g.getStartTime(), playerChoices, serverChoices));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : a.getStartTime().compareTo(b.getStartTime());
        });
        return results;
    }

    @Override
    public List<GameAttempt> getAttemptsForGame(Long gameId) {
        List<GameAttempt> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId)) {
                attempts.add(a);
            }
        }
        return attempts;
    }

    @Override
    public List<Pair> getPairsForGame(Long gameId) {
        Game game  = gameRepo.findById(gameId);
        if (game == null) {
            throw new RuntimeException("Joc inexistent.");
        }
        List<Pair> pairs = new ArrayList<>();
        for (GamePair gp : gamePairRepo.findAll()) {
            if (gp.getGameId().equals(gameId)) {
                Pair pair = pairRepo.findById(gp.getPairId());
                if (pair != null) {
                    pairs.add(pair);
                }
            }
        }
        return pairs;
    }

    private void notifyGameFinished() {
        for (IGameObserver observer : observers) {
            try {
                observer.scoreboardUpdated();
            } catch (Exception e) {
                System.err.println("Eroare notificare: " + e.getMessage());
            }
        }
    }

    public List<GameResultDTO> getGamesWithDraw(String alias) {
        List<GameResultDTO> filtered = new ArrayList<>();
        for (GameResultDTO dto : getDetailedResultsForPlayer(alias)) {
            List<GameResultDTO.ChoiceDTO> playerChoices = dto.getPlayerChoices();
            List<GameResultDTO.ChoiceDTO> serverChoices = dto.getServerChoices();

            for (int i = 0; i < playerChoices.size() && i < serverChoices.size(); i++) {
                if (playerChoices.get(i).getLetter()
                        .equalsIgnoreCase(serverChoices.get(i).getLetter())) {
                    filtered.add(dto);
                    break;
                }
            }
        }

        return filtered;
    }

    public List<Pair> modifyPairsForGame(Long gameId, List<Pair> newPairs) {
        Game game = gameRepo.findById(gameId);
        if (game == null) {
            throw new RuntimeException("Joc inexistent.");
        }

        for (GamePair gp : gamePairRepo.findAll()) {
            if (gp.getGameId().equals(gameId)) {
                gamePairRepo.delete(gp);
            }
        }

        List<Pair> addedPairs = new ArrayList<>();
        for (Pair pair : newPairs) {
            pairRepo.add(pair);
            GamePair gamePair = new GamePair(gameId, pair.getId());
            gamePairRepo.add(gamePair);
            addedPairs.add(pair);
        }

        return addedPairs;
    }


}
