package com.example.litere.domain;

import java.io.Serializable;

public class GamePair extends EntityID<Long> implements Serializable {

    private Long id;
    private Long gameId;
    private Long pairId;

    public GamePair() {}

    public GamePair(Long id, Long gameId, Long pairId) {
        setId(id);
        this.gameId = gameId;
        this.pairId = pairId;
    }

    public GamePair(Long gameId, Long pairId) {
        this.gameId = gameId;
        this.pairId = pairId;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public Long getPairId() {
        return pairId;
    }

    public void setPairId(Long pairId) {
        this.pairId = pairId;
    }
}
