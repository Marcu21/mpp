package com.example.litere.repository;

import com.example.litere.domain.Game;

public interface GameRepository extends Repository<Game, Long> {
}
