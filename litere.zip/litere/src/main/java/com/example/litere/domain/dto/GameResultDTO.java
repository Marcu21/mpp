package com.example.litere.domain.dto;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

public class GameResultDTO implements Serializable {

    private Long gameId;
    private String alias;
    private int score;
    private LocalDateTime startTime;

    private List<ChoiceDTO> playerChoices;
    private List<ChoiceDTO> serverChoices;

    public GameResultDTO(Long gameId,
                         String alias,
                         int score,
                         LocalDateTime startTime,
                         List<ChoiceDTO> playerChoices,
                         List<ChoiceDTO> serverChoices) {
        this.gameId = gameId;
        this.alias = alias;
        this.score = score;
        this.startTime = startTime;
        this.playerChoices = playerChoices;
        this.serverChoices = serverChoices;
    }

    public Long getGameId() { return gameId; }
    public String getAlias() { return alias; }
    public int getScore() { return score; }
    public LocalDateTime getStartTime() { return startTime; }
    public List<ChoiceDTO> getPlayerChoices() { return playerChoices; }
    public List<ChoiceDTO> getServerChoices() { return serverChoices; }

    public static class ChoiceDTO implements Serializable {
        private String letter;
        private int value;

        public ChoiceDTO() {}

        public ChoiceDTO(String letter, int value) {
            this.letter = letter;
            this.value = value;
        }
        public String getLetter() { return letter; }
        public void setLetter(String letter) { this.letter = letter; }

        public int getValue() { return value; }
        public void setValue(int value) { this.value = value; }
    }
}
