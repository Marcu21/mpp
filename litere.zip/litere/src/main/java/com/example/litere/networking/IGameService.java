package com.example.litere.networking;

import com.example.litere.domain.GamePair;
import com.example.litere.domain.Game;
import com.example.litere.domain.GameAttempt;
import com.example.litere.domain.Pair;
import com.example.litere.domain.dto.GameResultDTO;

import java.util.List;

public interface IGameService {
    void addObserver(IGameObserver observer);
    void removeObserver(IGameObserver observer);

    Game startGame(String alias);
    String makeAttempt(Long gameId, String playerLetter);

    List<GameResultDTO> getResultsForAllPlayers();
    List<GameResultDTO> getDetailedResultsForPlayer(String alias);
    List<GameAttempt> getAttemptsForGame(Long gameId);
    List<Pair> getPairsForGame(Long gameId);
}
