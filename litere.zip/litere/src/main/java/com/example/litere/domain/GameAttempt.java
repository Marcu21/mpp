package com.example.litere.domain;

import java.io.Serializable;

public class GameAttempt extends EntityID<Long> implements Serializable {

    private Long id;
    private Long gameId;
    private String playerLetter;
    private int playerValue;
    private String serverLetter;
    private int serverValue;

    public GameAttempt() {}

    public GameAttempt(Long id, Long gameId, String playerLetter, int playerValue, String serverLetter, int serverValue) {
        setId(id);
        this.gameId = gameId;
        this.playerLetter = playerLetter;
        this.playerValue = playerValue;
        this.serverLetter = serverLetter;
        this.serverValue = serverValue;
    }

    public GameAttempt(Long gameId, String playerLetter, int playerValue, String serverLetter, int serverValue) {
        this.gameId = gameId;
        this.playerLetter = playerLetter;
        this.playerValue = playerValue;
        this.serverLetter = serverLetter;
        this.serverValue = serverValue;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public String getPlayerLetter() {return playerLetter;}

    public void setPlayerLetter(String playerLetter) {this.playerLetter = playerLetter;}

    public int getPlayerValue() {
        return playerValue;
    }

    public void setPlayerValue(int playerValue) {
        this.playerValue = playerValue;
    }

    public String getServerLetter() {
        return serverLetter;
    }

    public void setServerLetter(String serverLetter) {
        this.serverLetter = serverLetter;
    }

    public int getServerValue() {
        return serverValue;
    }

    public void setServerValue(int serverValue) {
        this.serverValue = serverValue;
    }
}
