package com.example.litere.repository;

import com.example.litere.domain.Pair;

public interface PairRepository extends Repository<Pair, Long>{
}
