package com.example.litere.repository;

import com.example.litere.domain.GameAttempt;

public interface GameAttemptRepository extends Repository<GameAttempt, Long> {
}