package com.example.litere.server;

import com.example.litere.networking.RequestHandler;
import com.example.litere.repository.*;
import com.example.litere.repository.db.*;
import com.example.litere.repository.hibernate.HibernateGameRepository;
import com.example.litere.repository.hibernate.HibernatePlayerRepository;
import com.example.litere.service.GameService;
import com.example.litere.utils.HibernateUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    private static final int PORT = 5555;

    public static void main(String[] args) {
        PlayerRepository playerRepo   = new HibernatePlayerRepository(HibernateUtil.getSessionFactory());
        PairRepository pairRepo     = new PairDBRepository();
        GameRepository gameRepo     = new HibernateGameRepository(HibernateUtil.getSessionFactory());
        GameAttemptRepository attemptRepo = new GameAttemptDBRepository();
        GamePairRepository gamePairRepository = new GamePairDBRepository();

        GameService service = new GameService(playerRepo, gameRepo, attemptRepo, pairRepo, gamePairRepository);

        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket client = server.accept();
                new Thread(new RequestHandler(service, client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
