package com.example.litere.controller;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;
import com.example.litere.domain.Pair;
import com.example.litere.domain.Game;
import com.example.litere.domain.GameAttempt;
import com.example.litere.domain.dto.GameResultDTO;
import com.example.litere.networking.GameServiceProxy;
import com.example.litere.networking.IGameObserver;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LitereController implements IGameObserver {

    @FXML
    private TextField aliasField;
    @FXML private TextArea messageArea;

    @FXML private TableView<GameResultDTO> leaderboardTable;
    @FXML private TableColumn<GameResultDTO, String> colAlias;
    @FXML private TableColumn<GameResultDTO, Integer> colScore;
    @FXML private TableColumn<GameResultDTO, String> colStart;

    private final GameServiceProxy service = new GameServiceProxy("localhost", 5555);

    private Long currentGameId = null;
    private String currentAlias = null;
    @FXML private TextField literaField;
    @FXML private Label lettersAndValueLabel;


    @FXML
    public void initialize() {
        initLeaderboardTable();
    }

    private void initLeaderboardTable() {
        colAlias.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAlias()));
        colScore.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getScore()));
        colStart.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().getStartTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")))
        );
    }

    private void updateLettersAndValue(String letters) {
        lettersAndValueLabel.setText(letters);
    }

    @FXML
    public void handleStartGame() {
        int ok = 1;
        if (currentAlias != null)
        {
            ok = 0;
        }
        currentAlias = aliasField.getText().trim();
        if (currentAlias.isEmpty()) {
            messageArea.setText("Introdu un alias valid.");
            return;
        }

        try {
            if(ok == 1) {
                service.addObserver(this);
            }

            Game game = service.startGame(currentAlias);
            this.currentGameId = game.getId();
            List<Pair> letters = service.getPairsForGame(currentGameId);
            StringBuilder lettersString = new StringBuilder();
            for (Pair pair : letters) {
                lettersString.append(" (").append(pair.getLetter()).append(" ").append(pair.getValue()).append("), ");
            }
            updateLettersAndValue(lettersString.toString());
            messageArea.setText("Joc pornit!");

            updateLeaderboard();
        } catch (Exception e) {
            messageArea.setText("Eroare la pornirea jocului: " + e.getMessage());
        }
    }

    @FXML
    private void handleSubmit() {
        if (currentGameId == null) {
            messageArea.setText("Mai intai porneste un joc.");
            return;
        }

        String litera = literaField.getText().trim();
        if (litera.isEmpty()) {
            messageArea.setText("Introdu o litera");
            return;
        }

        try {
            String rezultat = service.makeAttempt(currentGameId, litera);
            messageArea.setText(rezultat);
            literaField.clear();

            if (rezultat.contains("Punctaj")) {
                currentGameId = null;
                updateLeaderboard();
            }

        } catch (Exception e) {
            messageArea.setText("Eroare la trimiterea cuvantului: " + e.getMessage());
        }
    }

    private void updateLeaderboard() {
        try {
            List<GameResultDTO> results = service.getResultsForAllPlayers();
            leaderboardTable.getItems().setAll(results);
        } catch (Exception e) {
            messageArea.setText("Eroare la actualizarea clasamentului: " + e.getMessage());
        }
    }

    @Override
    public void scoreboardUpdated() {
        Platform.runLater(this::updateLeaderboard);
    }

    public void handleDisconnect() {
        try {
            service.removeObserver(this);
            messageArea.setText("Deconectare reusita.");
        } catch (Exception e) {
            messageArea.setText("Eroare la deconectare: " + e.getMessage());
        }
    }


}