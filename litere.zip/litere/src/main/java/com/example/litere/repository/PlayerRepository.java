package com.example.litere.repository;

import com.example.litere.domain.Player;

public interface PlayerRepository extends Repository<Player, Long> {
}