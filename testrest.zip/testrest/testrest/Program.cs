﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        using HttpClient client = new HttpClient();

        Console.WriteLine("GET /api/curse:");
        var getResponse1 = await client.GetAsync("http://localhost:8080/api/curse");
        string getBody1 = await getResponse1.Content.ReadAsStringAsync();
        Console.WriteLine(getBody1);

        string json = """
                      {
                          "capacitateMotor": 150,
                          "nrParticipanti": 0,
                          "participanti": []
                      }
                      """;

        var postContent = new StringContent(json, Encoding.UTF8, "application/json");
        var postResponse = await client.PostAsync("http://localhost:8080/api/curse", postContent);
        string postBody = await postResponse.Content.ReadAsStringAsync();
        Console.WriteLine("POST /api/curse:");
        Console.WriteLine(postBody);

        Console.WriteLine("GET /api/curse:");
        var getResponse2 = await client.GetAsync("http://localhost:8080/api/curse");
        string getBody2 = await getResponse2.Content.ReadAsStringAsync();
        Console.WriteLine(getBody2);
    }
}