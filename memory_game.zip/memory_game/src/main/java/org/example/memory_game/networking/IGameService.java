package org.example.memory_game.networking;

import org.example.memory_game.domain.Game;
import org.example.memory_game.domain.GameAttempt;
import org.example.memory_game.domain.dto.GameResultDTO;

import java.util.List;

public interface IGameService {
    void addObserver(IGameObserver observer);
    void removeObserver(IGameObserver observer);

    Game startGame(String alias);
    String makeAttempt(Long gameId, int row, int col);

    List<GameResultDTO> getResultsForAllPlayers();
    List<GameResultDTO> getDetailedResultsForPlayer(String alias);
    List<GameAttempt> getAttemptsForGame(Long gameId);

    Game getGameById(Long gameId);
}
