package org.example.memory_game.rest;

import org.example.memory_game.domain.Game;
import org.example.memory_game.domain.dto.RestDTO;
import org.example.memory_game.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/configurations")
public class GameAttemptRestController {

    private final GameService gameService;

    public GameAttemptRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @PutMapping
    public ResponseEntity<Game> modifyGameConfiguration(@RequestBody RestDTO request) {
        try {
            Game saved = gameService.modifyConfiguration(request.getGameId(), request.getConfiguration());
            return new ResponseEntity<>(saved, HttpStatus.CREATED);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}