package org.example.memory_game.domain.dto;

import java.io.Serializable;
import java.util.List;

public class GameResultDTO implements Serializable {

    private Long gameId;
    private String alias;
    private int score;
    private String configuration;
    private Long duration;


    private List<PosDTO> attempts;

    public GameResultDTO(Long gameId,
                         String alias,
                         int score,
                         String configuration,
                         Long duration,
                         List<PosDTO> attempts) {
        this.gameId = gameId;
        this.alias = alias;
        this.score = score;
        this.configuration = configuration;
        this.duration = duration;
        this.attempts = attempts;
    }

    public Long getGameId() { return gameId; }
    public String getAlias() { return alias; }
    public int getScore() { return score; }
    public String getConfiguration() { return configuration; }
    public Long getDuration() { return duration; }
    public List<PosDTO> getAttempts() { return attempts; }

    public static class PosDTO implements Serializable {
        private int pos1;
        private int pos2;

        public PosDTO(int pos1, int pos2) {
            this.pos1 = pos1;
            this.pos2 = pos2;
        }
        public int getPos1() { return pos1; }
        public int getPos2() { return pos2; }
    }
}
