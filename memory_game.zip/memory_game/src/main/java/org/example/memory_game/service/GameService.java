package org.example.memory_game.service;

import org.example.memory_game.domain.*;
import org.example.memory_game.domain.dto.GameResultDTO;
import org.example.memory_game.networking.IGameObserver;
import org.example.memory_game.networking.IGameService;
import org.example.memory_game.repository.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GameService implements IGameService {

    private final PlayerRepository playerRepo;
    private final GameRepository gameRepo;
    private final GameAttemptRepository attemptRepo;
    private final WordRepository wordRepo;
    private final List<IGameObserver> observers = new ArrayList<>();

    private final Random random = new Random();

    public GameService(PlayerRepository playerRepo,
                       GameRepository gameRepo,
                       GameAttemptRepository attemptRepo,
                       WordRepository wordRepo) {
        this.playerRepo = playerRepo;
        this.gameRepo = gameRepo;
        this.attemptRepo = attemptRepo;
        this.wordRepo = wordRepo;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        observers.remove(observer);
    }

    @Override
    public Game startGame(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            player = new Player(null, alias);
            playerRepo.add(player);
        }

        Set<String> cuvinte = new HashSet<>();
        List<Word> allWords = (List<Word>) wordRepo.findAll();
        Random random = new Random();

        while (cuvinte.size() < 5) {
            cuvinte.add(allWords.get(random.nextInt(allWords.size())).getText());
        }

        List<String> configuratie = new ArrayList<>();
        for (String c : cuvinte) {
            configuratie.add(c);
            configuratie.add(c);
        }

        Collections.shuffle(configuratie);

        String configurationString = String.join(",", configuratie);


        Game game = new Game(player.getId(), configurationString, LocalDateTime.now());
        game.setScore(0);
        gameRepo.add(game);

        return game;
    }


    @Override
    public String makeAttempt(Long gameId, int pos1, int pos2) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }

        String result = procesareMemoryGame(game, pos1, pos2);

        gameRepo.update(game);
        if (game.getEndTime() != null) {
            notifyGameFinished();
        }

        return result;
    }

    private String procesareMemoryGame(Game game, int pos1, int pos2) {
        String[] configuratie = game.getConfiguration().split(",");

        String cuvant1 = configuratie[pos1];
        String cuvant2 = configuratie[pos2];

        boolean perecheCorecta = cuvant1.equals(cuvant2);
        int puncte, correct;

        if (perecheCorecta) {
            puncte = -2;
            correct = 1;
        } else {
            puncte = 3;
            correct = 0;
        }

        game.setScore(game.getScore() + puncte);

        GameAttempt attempt = new GameAttempt(game.getId(), pos1, pos2, correct);
        attemptRepo.add(attempt);

        List<GameAttempt> attempts = getAttemptsForGame(game.getId());

        int perechiGasite = 0;
        for (GameAttempt a : attempts) {
            if (a.getCorrect() == 1) {
                perechiGasite++;
            }
        }

        int totalIncercari = attempts.size();

        if (perechiGasite == 5) {
            game.setEndTime(LocalDateTime.now());
            return "Ai gasit toate perechile! Punctaj: " + game.getScore();
        }

        if (totalIncercari >= 10) {
            game.setEndTime(LocalDateTime.now());
            return "Ai atins limita de 10 incercari. Punctaj: " + game.getScore();
        }

        if (perecheCorecta) {
            return "Pereche corecta: " + cuvant1 + " si " + cuvant2;
        } else {
            return "Pereche gresita: " + cuvant1 + " si " + cuvant2;
        }
    }


    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getEndTime() != null) {
                Player p = playerRepo.findById(g.getPlayerId());
                Duration d = Duration.between(g.getStartTime(), g.getEndTime());
                results.add(new GameResultDTO(g.getId(), p.getAlias(), g.getScore(), g.getConfiguration(), d.getSeconds(), new ArrayList<>()));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Long.compare(a.getDuration(), b.getDuration());
        });
        return results;
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            throw new RuntimeException("Jucatorul nu exista.");
        }

        List<GameResultDTO> results = new ArrayList<>();

        for (Game g : gameRepo.findAll()) {
            if (g.getPlayerId().equals(player.getId())
                    && g.getEndTime() != null) {


                long duration = Duration.between(g.getStartTime(), g.getEndTime()).getSeconds();
                List<GameResultDTO.PosDTO> attempts = new ArrayList<>();
                for (GameAttempt a : attemptRepo.findAll()) {
                    if (a.getGameId().equals(g.getId())) {
                        attempts.add(new GameResultDTO.PosDTO(a.getPos1(), a.getPos2()));
                    }
                }

                GameResultDTO dto = new GameResultDTO(
                        g.getId(),
                        alias,
                        g.getScore(),
                        g.getConfiguration(),
                        duration,
                        attempts
                );
                results.add(dto);
            }
        }

        results.sort(Comparator.comparingLong(GameResultDTO::getScore).reversed());

        return results;
    }


    @Override
    public List<GameAttempt> getAttemptsForGame(Long gameId) {
        List<GameAttempt> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId)) {
                attempts.add(a);
            }
        }
        return attempts;
    }

    public GameResultDTO getResultsForGame(Long gameId) {
        Game game = gameRepo.findById(gameId);
        if (game == null) {
            throw new IllegalArgumentException("Jocul nu exista.");
        }

        long duration = Duration.between(game.getStartTime(), game.getEndTime()).getSeconds();
        List<GameResultDTO.PosDTO> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(game.getId())) {
                attempts.add(new GameResultDTO.PosDTO(a.getPos1(), a.getPos2()));
            }
        }

        return new GameResultDTO(
                game.getId(),
                playerRepo.findById(game.getPlayerId()).getAlias(),
                game.getScore(),
                game.getConfiguration(),
                duration,
                attempts
        );
    }


    private void notifyGameFinished() {
        for (IGameObserver observer : observers) {
            try {
                observer.scoreboardUpdated();
            } catch (Exception e) {
                System.err.println("Eroare notificare: " + e.getMessage());
            }
        }
    }

    public Game modifyConfiguration(Long gameId, String newConfiguration) {
        Game game = gameRepo.findById(gameId);
        if (game == null) {
            throw new IllegalArgumentException("Jocul nu exista.");
        }

        game.setConfiguration(newConfiguration);
        gameRepo.update(game);
        return game;
    }

    @Override
    public Game getGameById(Long gameId) {
        Game game = gameRepo.findById(gameId);
        if (game == null) {
            throw new IllegalArgumentException("Jocul nu exista.");
        }
        return game;
    }

}
