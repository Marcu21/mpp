package org.example.memory_game.server;

import org.example.memory_game.networking.RequestHandler;
import org.example.memory_game.repository.GameAttemptRepository;
import org.example.memory_game.repository.GameRepository;
import org.example.memory_game.repository.PlayerRepository;
import org.example.memory_game.repository.WordRepository;
import org.example.memory_game.repository.db.*;
import org.example.memory_game.repository.db.PlayerDBRepository;
import org.example.memory_game.repository.hibernate.HibernateGameRepository;
import org.example.memory_game.service.GameService;
import org.example.memory_game.utils.HibernateUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    private static final int PORT = 5555;

    public static void main(String[] args) {
        PlayerRepository playerRepo   = new PlayerDBRepository();
        GameRepository gameRepo     = new HibernateGameRepository(HibernateUtil.getSessionFactory());
        GameAttemptRepository attemptRepo = new GameAttemptDBRepository();
        WordRepository wordRepo     = new WordDBRepository();

        GameService service = new GameService(playerRepo, gameRepo, attemptRepo, wordRepo);

        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket client = server.accept();
                new Thread(new RequestHandler(service, client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
