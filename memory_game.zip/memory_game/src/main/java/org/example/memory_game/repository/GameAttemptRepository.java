package org.example.memory_game.repository;

import org.example.memory_game.domain.GameAttempt;

public interface GameAttemptRepository extends Repository<GameAttempt, Long> {
}