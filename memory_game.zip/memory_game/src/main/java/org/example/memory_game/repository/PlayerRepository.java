package org.example.memory_game.repository;

import org.example.memory_game.domain.Player;

public interface PlayerRepository extends Repository<Player, Long> {
}