package org.example.memory_game.rest;

import org.example.memory_game.domain.dto.GameResultDTO;
import org.example.memory_game.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/results")
public class GameResultRestController {

    private final GameService gameService;

    public GameResultRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @GetMapping("/{gameId}")
    public ResponseEntity<GameResultDTO> getResultsForGame(@PathVariable Long gameId) {
        try {
            GameResultDTO result = gameService.getResultsForGame(gameId);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
