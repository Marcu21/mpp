package org.example.memory_game.networking;

public interface IGameObserver {
    void scoreboardUpdated();
}