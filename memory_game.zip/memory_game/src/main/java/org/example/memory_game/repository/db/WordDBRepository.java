package org.example.memory_game.repository.db;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.memory_game.domain.Word;
import org.example.memory_game.repository.WordRepository;
import org.example.memory_game.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class WordDBRepository implements WordRepository {
    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public WordDBRepository() {
        logger.info("Initializing WordDBRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(Word word) {
        logger.traceEntry("Saving word {}", word);
        String sql = "INSERT INTO Word (text) VALUES (?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, word.getText());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    word.setId(keys.getLong(1));
                }
            }
            logger.trace("Saved {}", word);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<Word> findAll() {
        logger.traceEntry();
        List<Word> words = new ArrayList<>();
        String sql = "SELECT * FROM Word";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Long id = rs.getLong("id");
                String text = rs.getString("text");
                Word w = new Word(id, text);
                words.add(w);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit(words);
        return words;
    }

    @Override
    public void delete(Word word) {
        logger.traceEntry("Deleting word {}", word);
        String sql = "DELETE FROM Word WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, word.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", word);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public void update(Word word) {
        logger.traceEntry("Updating word {}", word);
        String sql = "UPDATE Word SET text=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, word.getText());
            stmt.setLong(2, word.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", word);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public Word findById(Long id) {
        logger.traceEntry("Finding word by id {}", id);
        String sql = "SELECT * FROM Word WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String text = rs.getString("text");
                    Word w = new Word(id, text);
                    logger.traceExit(w);
                    return w;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Word> getAll() {
        return (Collection<Word>) findAll();
    }
}