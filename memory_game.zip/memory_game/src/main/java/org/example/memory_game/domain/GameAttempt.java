package org.example.memory_game.domain;

import java.io.Serializable;

public class GameAttempt extends EntityID<Long> implements Serializable {

    private Long id;
    private Long gameId;
    private int pos1;
    private int pos2;
    private int correct;

    public GameAttempt() {}

    public GameAttempt(Long id, Long gameId, int pos1, int pos2, int correct) {
        setId(id);
        this.gameId = gameId;
        this.pos1 = pos1;
        this.pos2 = pos2;
        this.correct = correct;
    }

    public GameAttempt(Long gameId, int pos1, int pos2, int correct) {
        this.gameId = gameId;
        this.pos1 = pos1;
        this.pos2 = pos2;
        this.correct = correct;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public int getPos1() {
        return pos1;
    }

    public void setPos1(int pos1) {
        this.pos1 = pos1;
    }

    public int getPos2() {
        return pos2;
    }

    public void setPos2(int pos2) {
        this.pos2 = pos2;
    }

    public int getCorrect() {
        return correct;
    }

    public void setCorrect(int correct) {
        this.correct = correct;
    }
}
