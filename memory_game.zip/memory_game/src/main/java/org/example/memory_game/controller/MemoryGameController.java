package org.example.memory_game.controller;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;
import org.example.memory_game.domain.Game;
import org.example.memory_game.domain.GameAttempt;
import org.example.memory_game.domain.dto.GameResultDTO;
import org.example.memory_game.networking.GameServiceProxy;
import org.example.memory_game.networking.IGameObserver;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MemoryGameController implements IGameObserver {

    @FXML
    private TextField aliasField;
    @FXML private TextArea messageArea;
    @FXML private GridPane grid;

    @FXML private TableView<GameResultDTO> leaderboardTable;
    @FXML private TableColumn<GameResultDTO, String> colAlias;
    @FXML private TableColumn<GameResultDTO, Integer> colScore;
    @FXML private TableColumn<GameResultDTO, String> colDuration;

    private final GameServiceProxy service = new GameServiceProxy("localhost", 5555);

    private Long currentGameId = null;
    private String currentAlias = null;
    private final Map<Integer, Button> buttons = new HashMap<>();
    private Integer selectedPos = null;

    @FXML
    public void initialize() {
        initLeaderboardTable();
        populateGrid();
    }

    private void initLeaderboardTable() {
        colAlias.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAlias()));
        colScore.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getScore()));
        colDuration.setCellValueFactory(data -> {
            long seconds = data.getValue().getDuration();
            String formatted = String.format("%02d:%02d", seconds / 60, seconds % 60);
            return new SimpleStringProperty(formatted);
        });
    }

    private void populateGrid() {
        grid.getChildren().clear();
        buttons.clear();

        for (int i = 0; i < 10; i++) {
            Button btn = new Button("");
            btn.setPrefSize(60, 60);
            final int pos = i;

            btn.setOnAction(ev -> handleMove(pos));
            buttons.put(pos, btn);

            grid.add(btn, i % 5, i / 5);
        }
    }


    @FXML
    public void handleStartGame() {
        int ok = 1;
        if (currentAlias != null)
        {
            ok = 0;
        }
        currentAlias = aliasField.getText().trim();
        if (currentAlias.isEmpty()) {
            messageArea.setText("Introdu un alias valid.");
            return;
        }

        try {
            if( ok == 1) {
                service.addObserver(this);
            }

            Game game = service.startGame(currentAlias);
            this.currentGameId = game.getId();
            refreshGrid();
            messageArea.setText("Joc pornit!");

            updateLeaderboard();
        } catch (Exception e) {
            messageArea.setText("Eroare la pornirea jocului: " + e.getMessage());
        }
    }

    private void handleMove(int pos) {
        if (currentGameId == null) {
            messageArea.setText("Mai intai porneste un joc.");
            return;
        }
        Game game = service.getGameById(currentGameId);
        if (game == null) {
            messageArea.setText("Jocul nu exista");
            return;
        }

        if (selectedPos == null) {
            selectedPos = pos;

            try {
                String[] config = game.getConfiguration().split(",");
                String cuvant = config[pos];
                buttons.get(pos).setText(cuvant);
            } catch (Exception e) {
                messageArea.setText("Eroare la afisarea cuvantului: " + e.getMessage());
            }
        } else {
            int pos1 = selectedPos;
            int pos2 = pos;
            selectedPos = null;

            if (pos1 == pos2) {
                messageArea.setText("Selecteaza doua pozitii diferite!");
                buttons.get(pos1).setText("");
                return;
            }

            try {
                String[] config = game.getConfiguration().split(",");
                String cuv1 = config[pos1];
                String cuv2 = config[pos2];
                buttons.get(pos2).setText(cuv2);

                String result = service.makeAttempt(currentGameId, pos1, pos2);
                messageArea.setText(result);
                PauseTransition pause = new PauseTransition(Duration.seconds(1));
                pause.setOnFinished(ev -> {
                    refreshGrid();
                    if (result.contains("Punctaj")) {
                        currentGameId = null;
                        updateLeaderboard();
                    }
                });
                pause.play();
            } catch (Exception e) {
                messageArea.setText("Eroare la mutare: " + e.getMessage());
            }
        }
    }

    private void updateLeaderboard() {
        try {
            List<GameResultDTO> results = service.getResultsForAllPlayers();
            leaderboardTable.getItems().setAll(results);
        } catch (Exception e) {
            messageArea.setText("Eroare la actualizarea clasamentului: " + e.getMessage());
        }
    }

    @Override
    public void scoreboardUpdated() {
        Platform.runLater(this::updateLeaderboard);
    }

    public void handleDisconnect() {
        try {
            service.removeObserver(this);
            messageArea.setText("Deconectare reusita.");
        } catch (Exception e) {
            messageArea.setText("Eroare la deconectare: " + e.getMessage());
        }
    }

    private void refreshGrid() {
        try {
            Game game = service.getGameById(currentGameId);
            List<GameAttempt> attempts = service.getAttemptsForGame(currentGameId);
            String[] config = game.getConfiguration().split(",");

            boolean[] revealed = new boolean[10];

            for (GameAttempt a : attempts) {
                if (a.getCorrect() == 1) {
                    revealed[a.getPos1()] = true;
                    revealed[a.getPos2()] = true;
                }
            }

            for (int i = 0; i < 10; i++) {
                Button btn = buttons.get(i);
                if (revealed[i]) {
                    btn.setText(config[i]);
                    btn.setDisable(true);
                } else {
                    btn.setText("");
                    btn.setDisable(false);
                }
            }
        } catch (Exception e) {
            messageArea.setText("Eroare la refresh grid: " + e.getMessage());
        }
    }


}