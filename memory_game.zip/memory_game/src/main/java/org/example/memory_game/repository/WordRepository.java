package org.example.memory_game.repository;

import org.example.memory_game.domain.Word;

public interface WordRepository extends Repository<Word, Long> {
}