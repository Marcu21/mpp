package org.example.memory_game.utils;

import org.example.memory_game.repository.*;
import org.example.memory_game.repository.db.GameAttemptDBRepository;
import org.example.memory_game.repository.db.PlayerDBRepository;
import org.example.memory_game.repository.db.WordDBRepository;
import org.example.memory_game.repository.hibernate.HibernateGameRepository;
import org.example.memory_game.service.GameService;
import org.example.memory_game.utils.HibernateUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public PlayerRepository playerRepository() {
        return new PlayerDBRepository();
    }

    @Bean
    public GameAttemptRepository gameAttemptRepository() {
        return new GameAttemptDBRepository();
    }

    @Bean
    public GameRepository gameRepository() {
        return new HibernateGameRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public WordRepository wordRepository() {return new WordDBRepository();}

    @Bean
    public GameService gameService() {
        return new GameService(
                playerRepository(),
                gameRepository(),
                gameAttemptRepository(),
                wordRepository()
        );
    }
}
