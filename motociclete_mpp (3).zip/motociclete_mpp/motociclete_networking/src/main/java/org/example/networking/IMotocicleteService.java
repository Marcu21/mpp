package org.example.networking;

import org.example.domain.Echipa;
import org.example.domain.dto.CursaDTO;
import org.example.domain.dto.ParticipantDTO;

import java.util.List;

public interface IMotocicleteService {

    void login(String username, String password, IMotocicleteObserver client) throws Exception;

    void logout(String username, IMotocicleteObserver client) throws Exception;

    void addParticipant(String requestUsername, String nume, String cnp, String echipa, int capacitate) throws Exception;

    List<ParticipantDTO> searchByTeam(String echipa) throws Exception;

    List<CursaDTO> getCurse() throws Exception;

    List<Echipa> getAllEchipe() throws Exception;
}
