package org.example.networking;

import org.example.domain.Echipa;
import org.example.domain.dto.CursaDTO;
import org.example.domain.dto.ParticipantDTO;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

public class RequestHandler implements Runnable {
    private final IMotocicleteService service;
    private final Socket clientSocket;

    public RequestHandler(IMotocicleteService service, Socket clientSocket) {
        this.service = service;
        this.clientSocket = clientSocket;
    }

    public void run() {
        try {
            ObjectOutputStream output = new ObjectOutputStream(clientSocket.getOutputStream());
            output.flush();
            ObjectInputStream input = new ObjectInputStream(clientSocket.getInputStream());

            while (true) {
                Object obj = input.readObject();
                if (obj instanceof Request request) {
                    Response response = handleRequest(request, output);
                    if (response != null) {
                        output.writeObject(response);
                        output.flush();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("[Server] Client disconnected: " + e.getMessage());
        }
    }


    private Response handleRequest(Request request, ObjectOutputStream output) {
        String type = request.getType();
        Object[] data = request.getData();

        try {
            return switch (type) {
                case "login" -> {
                    String username = (String) data[0];
                    String password = (String) data[1];
                    service.login(username, password, new ObserverProxy(output));
                    yield new Response("ok", null);
                }
                case "logout" -> {
                    String username = (String) data[0];
                    service.logout(username, null);
                    yield new Response("ok", null);
                }
                case "add" -> {
                    String requestUsername = (String) data[0];
                    String nume = (String) data[1];
                    String cnp = (String) data[2];
                    String echipa = (String) data[3];
                    int capacitate = (Integer) data[4];

                    service.addParticipant(requestUsername, nume, cnp, echipa, capacitate);
                    yield new Response("ok", null);
                }
                case "search" -> {
                    List<ParticipantDTO> list = service.searchByTeam((String) data[0]);
                    yield new Response("ok", list);
                }
                case "curse" -> {
                    List<CursaDTO> curse = service.getCurse();
                    yield new Response("ok", curse);
                }
                case "echipe" -> {
                    List<Echipa> echipe = service.getAllEchipe();
                    yield new Response("ok", echipe);
                }

                default -> new Response("error", "Unknown request type");
            };
        } catch (Exception e) {
            return new Response("error", e.getMessage());
        }
    }
}
