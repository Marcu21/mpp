package org.example.networking;

import org.example.domain.dto.CursaDTO;
import org.example.domain.dto.ParticipantDTO;

import java.io.ObjectOutputStream;

public class ObserverProxy implements IMotocicleteObserver {
    private final ObjectOutputStream output;

    public ObserverProxy(ObjectOutputStream output) {
        this.output = output;
    }

    @Override
    public void participantAdded(ParticipantDTO participant) throws Exception {
        synchronized (output) {
            output.writeObject(participant);
            output.flush();
        }
    }

    @Override
    public void cursaUpdated(CursaDTO cursa) throws Exception {
        synchronized (output) {
            output.writeObject(cursa);
            output.flush();
        }
    }
}