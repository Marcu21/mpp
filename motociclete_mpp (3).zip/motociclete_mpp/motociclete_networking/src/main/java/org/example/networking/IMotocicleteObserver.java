package org.example.networking;

import org.example.domain.dto.CursaDTO;
import org.example.domain.dto.ParticipantDTO;

public interface IMotocicleteObserver {

    void participantAdded(ParticipantDTO participant) throws Exception;

    void cursaUpdated(CursaDTO cursa) throws Exception;
}
