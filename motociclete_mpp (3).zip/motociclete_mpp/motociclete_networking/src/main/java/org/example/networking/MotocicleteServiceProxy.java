package org.example.networking;

import org.example.domain.Echipa;
import org.example.domain.dto.CursaDTO;
import org.example.domain.dto.ParticipantDTO;

import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class MotocicleteServiceProxy implements IMotocicleteService {
    private final String host;
    private final int port;
    private IMotocicleteObserver client;

    private ObjectInputStream input;
    private ObjectOutputStream output;
    private Socket connection;

    private final Object lock = new Object();
    private Response lastResponse;
    private final BlockingQueue<Response> responses = new LinkedBlockingQueue<>();

    public MotocicleteServiceProxy(String host, int port) {
        this.host = host;
        this.port = port;
    }

    private void initializeConnection() throws IOException {
        connection = new Socket(host, port);
        output = new ObjectOutputStream(connection.getOutputStream());
        output.flush();
        input = new ObjectInputStream(connection.getInputStream());

        new Thread(new ReaderThread()).start();
    }


    @Override
    public void login(String username, String password, IMotocicleteObserver client) throws Exception {
        this.client = client;
        initializeConnection();

        sendRequest(new Request("login", new Object[]{username, password}));
        Response response = readResponse();

        if (response.getType().equals("error")) {
            throw new Exception((String) response.getData());
        }
    }


    @Override
    public void logout(String username, IMotocicleteObserver client) throws Exception {
        Request request = new Request("logout", new Object[]{username});
        sendRequest(request);
        closeConnection();
    }

    @Override
    public void addParticipant(String username, String nume, String cnp, String echipa, int capacitate) throws Exception {
        Request request = new Request("add", new Object[]{username, nume, cnp, echipa, capacitate});
        sendRequest(request);
        Response response = readResponse();
        if (response.getType().equals("error")) {
            throw new Exception((String) response.getData());
        }
    }

    @Override
    public List<ParticipantDTO> searchByTeam(String echipa) throws Exception {
        Request request = new Request("search", new Object[]{echipa});
        sendRequest(request);
        Response response = readResponse();
        if (response.getType().equals("ok")) {
            return (List<ParticipantDTO>) response.getData();
        } else {
            throw new Exception((String) response.getData());
        }
    }

    @Override
    public List<CursaDTO> getCurse() throws Exception {
        Request request = new Request("curse", null);
        sendRequest(request);
        Response response = readResponse();
        if (response.getType().equals("ok")) {
            return (List<CursaDTO>) response.getData();
        } else {
            throw new Exception((String) response.getData());
        }
    }

    @Override
    public List<Echipa> getAllEchipe() throws Exception {
        Request req = new Request("echipe", null);
        sendRequest(req);
        Response resp = readResponse();
        if (resp.getType().equals("ok")) {
            return (List<Echipa>) resp.getData();
        } else {
            throw new Exception((String) resp.getData());
        }
    }


    private void sendRequest(Request request) throws IOException {
        synchronized (lock) {
            output.writeObject(request);
            output.flush();
        }
    }

    private Response readResponse() throws InterruptedException {
        return responses.take();
    }


    private void closeConnection() throws IOException {
        if (input != null) input.close();
        if (output != null) output.close();
        if (connection != null) connection.close();
    }

    private class ReaderThread implements Runnable {
        public void run() {
            try {
                while (true) {
                    Object obj = input.readObject();
                    if (obj instanceof ParticipantDTO) {
                        client.participantAdded((ParticipantDTO) obj);
                    } else if (obj instanceof Response) {
                        responses.put((Response) obj);
                    }
                }
            } catch (Exception e) {
                System.out.println("[Client] Listener thread stopped: " + e.getMessage());
            }
        }
    }
}
