package org.example;

import org.example.domain.Cursa;
import org.example.domain.Echipa;
import org.example.domain.Participant;
import org.example.domain.User;

public class Main {
    public static void main(String[] args) {
        /*UserDBRepository userRepo = new UserDBRepository();
        EchipaDBRepository echipaRepo = new EchipaDBRepository();
        ParticipantDBRepository participantRepo = new ParticipantDBRepository();
        CursaDBRepository cursaRepo = new CursaDBRepository();

        User user1 = new User("admin", "admin");
        User user2 = new User("user1", "pass1");
        userRepo.add(user1);
        userRepo.add(user2);

        Echipa echipa1 = new Echipa("Redbull");
        Echipa echipa2 = new Echipa("Bizonii");
        echipaRepo.add(echipa1);
        echipaRepo.add(echipa2);

        Participant participant1 = new Participant("Emanuel Marcu", "1234567890123", echipa1.getId());
        Participant participant2 = new Participant("Raul Parau", "9876543210987", echipa2.getId());
        Participant participant3 = new Participant("Alex Danciu", "1928374650912", echipa1.getId());
        participantRepo.add(participant1);
        participantRepo.add(participant2);
        participantRepo.add(participant3);

        List<Participant> participantiCursa1 = new ArrayList<>();
        participantiCursa1.add(participant1);
        participantiCursa1.add(participant2);

        Cursa cursa1 = new Cursa(600, participantiCursa1.size(), participantiCursa1);
        cursaRepo.add(cursa1);

        for (User user : userRepo.findAll()) {
            System.out.println(user);
        }

        for (Echipa echipa : echipaRepo.findAll()) {
            System.out.println(echipa);
        }

        for (Participant participant : participantRepo.findAll()) {
            System.out.println(participant);
        }

        for (Cursa cursa : cursaRepo.findAll()) {
            System.out.println(cursa);
        }*/

        HelloApplication.main(args);
    }
}
