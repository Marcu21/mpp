package org.example.controller;

import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.domain.Echipa;
import org.example.domain.dto.CursaDTO;
import org.example.domain.dto.ParticipantDTO;
import org.example.networking.IMotocicleteObserver;
import org.example.networking.IMotocicleteService;

import java.util.ArrayList;
import java.util.List;

public class UserController implements IMotocicleteObserver {

    @FXML private Label loggedUserLabel;
    @FXML private TableView<CursaDTO> raceTable;
    @FXML private TableColumn<CursaDTO, Integer> colEngineCapacity;
    @FXML private TableColumn<CursaDTO, Integer> colNrParticipants;
    @FXML private TableView<ParticipantDTO> participantTable;
    @FXML private TableColumn<ParticipantDTO, String> colParticipantName;
    @FXML private TableColumn<ParticipantDTO, Integer> colParticipantEngine;
    @FXML private TextField nameField;
    @FXML private TextField cnpField;
    @FXML private TextField teamRegisterField;
    @FXML private TextField engineCapacityField;
    @FXML private Label registerErrorLabel;
    @FXML private ChoiceBox<String> teamSearchChoiceBox;

    private IMotocicleteService service;
    private String loggedUsername;

    public void setService(IMotocicleteService service) {
        this.service = service;
    }

    public void setLoggedUser(String username) {
        this.loggedUsername = username;
        loggedUserLabel.setText(username);
        initRacesTable();
        initParticipantTable();
        initChoiceBoxes();
        refreshRacesTable();
    }

    private void initRacesTable() {
        colEngineCapacity.setCellValueFactory(data ->
                new SimpleObjectProperty<>(data.getValue().getCapacitateMotor())
        );
        colNrParticipants.setCellValueFactory(data ->
                new SimpleObjectProperty<>(data.getValue().getNrParticipanti())
        );
    }

    private void initParticipantTable() {
        colParticipantName.setCellValueFactory(data ->
                new javafx.beans.property.SimpleStringProperty(data.getValue().getNume())
        );
        colParticipantEngine.setCellValueFactory(data ->
                new SimpleObjectProperty<>(data.getValue().getCapacitateMotor())
        );
    }

    private void initChoiceBoxes() {
        try {
            List<Echipa> echipe = service.getAllEchipe();
            List<String> numeEchipe = new ArrayList<>();
            for (Echipa e : echipe) {
                numeEchipe.add(e.getNumeEchipa());
            }
            teamSearchChoiceBox.getItems().clear();
            teamSearchChoiceBox.getItems().addAll(numeEchipe);
            if (!numeEchipe.isEmpty()) {
                teamSearchChoiceBox.getSelectionModel().selectFirst();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void refreshRacesTable() {
        try {
            raceTable.setItems(FXCollections.observableArrayList(service.getCurse()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSearchParticipants() {
        String teamName = teamSearchChoiceBox.getValue();
        if (teamName == null || teamName.isEmpty()) {
            participantTable.getItems().clear();
            return;
        }
        try {
            List<ParticipantDTO> dtos = service.searchByTeam(teamName);
            participantTable.setItems(FXCollections.observableArrayList(dtos));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleRegisterParticipant() {
        registerErrorLabel.setVisible(false);
        String name = nameField.getText().trim();
        String cnp = cnpField.getText().trim();
        String enteredTeam = teamRegisterField.getText().trim();
        String engineCapacityStr = engineCapacityField.getText().trim();

        if (name.isEmpty() || cnp.isEmpty()) {
            registerErrorLabel.setText("Nume si CNP obligatorii!");
            registerErrorLabel.setVisible(true);
            return;
        }
        if (engineCapacityStr.isEmpty()) {
            registerErrorLabel.setText("Introduceti capacitatea motorului!");
            registerErrorLabel.setVisible(true);
            return;
        }
        int engineCapacity;
        try {
            engineCapacity = Integer.parseInt(engineCapacityStr);
        } catch (NumberFormatException e) {
            registerErrorLabel.setText("Capacitatea motorului trebuie sa fie un numar!");
            registerErrorLabel.setVisible(true);
            return;
        }

        if (enteredTeam.isEmpty()) {
            registerErrorLabel.setText("Introduceti echipa!");
            registerErrorLabel.setVisible(true);
            return;
        }

        new Thread(() -> {
            try {
                service.addParticipant(loggedUsername, name, cnp, enteredTeam, engineCapacity);

                Platform.runLater(() -> {
                    refreshRacesTable();
                    clearRegistrationFields();
                    handleSearchParticipants();
                    initChoiceBoxes();
                });

            } catch (Exception e) {
                Platform.runLater(() -> {
                    registerErrorLabel.setText("Eroare: " + e.getMessage());
                    registerErrorLabel.setVisible(true);
                });
            }
        }).start();

    }

    private void clearRegistrationFields() {
        nameField.clear();
        cnpField.clear();
        teamRegisterField.clear();
        engineCapacityField.clear();
    }

    @FXML
    private void handleLogout() {
        try {
            service.logout(loggedUsername, this);
        } catch (Exception e) {
            System.out.println("Logout failed: " + e.getMessage());
        }
        Stage stage = (Stage) loggedUserLabel.getScene().getWindow();
        stage.close();
    }

    @Override
    public void participantAdded(ParticipantDTO participant) throws Exception {
        Platform.runLater(() -> {
            refreshRacesTable();
            handleSearchParticipants();
            initChoiceBoxes();
        });
    }

    @Override
    public void cursaUpdated(CursaDTO cursa) throws Exception {
        Platform.runLater(() -> {
            refreshRacesTable();
        });
    }
}
