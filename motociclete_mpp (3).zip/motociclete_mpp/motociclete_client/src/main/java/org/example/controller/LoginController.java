package org.example.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.domain.User;
import org.example.networking.MotocicleteServiceProxy;
import org.example.service.UserService;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;

    private UserService userService;

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Introdu username-ul si parola.");
            errorLabel.setVisible(true);
            return;
        }

        try {
            MotocicleteServiceProxy service = new MotocicleteServiceProxy("localhost", 5555);

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/user-view.fxml"));
            Parent root = loader.load();
            UserController userController = loader.getController();
            service.login(username, password, userController);

            userController.setService(service);
            userController.setLoggedUser(username);

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) usernameField.getScene().getWindow();
            currentStage.close();
        } catch (Exception e) {
            errorLabel.setText("Eroare: " + e.getMessage());
            errorLabel.setVisible(true);
        }
    }


    /*private void loadUserView(User user) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/motociclete_mpp/user-view.fxml"));
            Parent root = loader.load();
            UserController userController = loader.getController();
            userController.setServices(
                    new CursaService(new CursaDBRepository()),
                    new ParticipantService(new ParticipantDBRepository()),
                    new EchipaService(new EchipaDBRepository()),
                    user
            );
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
            Stage currentStage = (Stage) usernameField.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
}
