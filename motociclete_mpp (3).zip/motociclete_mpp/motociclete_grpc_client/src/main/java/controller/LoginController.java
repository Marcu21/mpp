package controller;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.grpc.LoginRequest;
import org.example.grpc.LoginResponse;
import org.example.grpc.MotocicleteServiceGrpc;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;

    private ManagedChannel channel;
    private MotocicleteServiceGrpc.MotocicleteServiceBlockingStub stub;

    @FXML
    public void initialize() {
        channel = ManagedChannelBuilder
                .forAddress("localhost", 50051)
                .usePlaintext()
                .build();

        stub = MotocicleteServiceGrpc.newBlockingStub(channel);
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Introdu username-ul și parola.");
            errorLabel.setVisible(true);
            return;
        }

        try {
            LoginRequest request = LoginRequest.newBuilder()
                    .setUsername(username)
                    .setPassword(password)
                    .build();

            LoginResponse response = stub.login(request);

            if (response.getSuccess()) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/grpc-user-view.fxml"));
                Parent root = loader.load();
                UserController userController = loader.getController();
                userController.initData(
                        username,
                        MotocicleteServiceGrpc.newBlockingStub(channel),
                        MotocicleteServiceGrpc.newStub(channel)
                );


                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.show();

                ((Stage)usernameField.getScene().getWindow()).close();
            } else {
                errorLabel.setText("Eroare: " + response.getErrorMessage());
                errorLabel.setVisible(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
            errorLabel.setText("Eroare la server: " + e.getMessage());
            errorLabel.setVisible(true);
        }
    }

    public void shutdown() {
        if (channel != null) {
            channel.shutdown();
        }
    }
}