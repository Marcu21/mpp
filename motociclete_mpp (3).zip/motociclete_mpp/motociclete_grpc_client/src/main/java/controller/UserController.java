package controller;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;
import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.example.grpc.*;

import java.util.ArrayList;
import java.util.List;

public class UserController {

    @FXML private Label loggedUserLabel;
    @FXML private TableView<CursaDTO> raceTable;
    @FXML private TableColumn<CursaDTO, Integer> colEngineCapacity;
    @FXML private TableColumn<CursaDTO, Integer> colNrParticipants;
    @FXML private TableView<ParticipantDTO> participantTable;
    @FXML private TableColumn<ParticipantDTO, String> colParticipantName;
    @FXML private TableColumn<ParticipantDTO, Integer> colParticipantEngine;
    @FXML private TextField nameField;
    @FXML private TextField cnpField;
    @FXML private TextField teamRegisterField;
    @FXML private TextField engineCapacityField;
    @FXML private Label registerErrorLabel;
    @FXML private ChoiceBox<String> teamSearchChoiceBox;

    private ManagedChannel channel;
    private MotocicleteServiceGrpc.MotocicleteServiceBlockingStub blockingStub;
    private MotocicleteServiceGrpc.MotocicleteServiceStub asyncStub;
    private String loggedUsername;

    public void initData(String username,
                         MotocicleteServiceGrpc.MotocicleteServiceBlockingStub blockingStub,
                         MotocicleteServiceGrpc.MotocicleteServiceStub asyncStub) {
        this.loggedUsername = username;
        this.blockingStub = blockingStub;
        this.asyncStub = asyncStub;

        loggedUserLabel.setText(username);
        initRacesTable();
        initParticipantTable();
        initChoiceBoxes();
        refreshRacesTable();

        startListeningForParticipantUpdates();
    }

    private void initRacesTable() {
        colEngineCapacity.setCellValueFactory(data ->
                new SimpleObjectProperty<>(data.getValue().getCapacitateMotor())
        );
        colNrParticipants.setCellValueFactory(data ->
                new SimpleObjectProperty<>(data.getValue().getNrParticipanti())
        );
    }

    private void initParticipantTable() {
        colParticipantName.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getNume())
        );
        colParticipantEngine.setCellValueFactory(data ->
                new SimpleObjectProperty<>(data.getValue().getCapacitateMotor())
        );
    }

    private void initChoiceBoxes() {
        try {
            GetAllEchipeResponse response = blockingStub.getAllEchipe(EmptyRequest.newBuilder().build());
            List<String> numeEchipe = new ArrayList<>();
            for (Echipa echipa : response.getEchipeList()) {
                numeEchipe.add(echipa.getNume());
            }
            teamSearchChoiceBox.getItems().clear();
            teamSearchChoiceBox.getItems().addAll(numeEchipe);
            if (!numeEchipe.isEmpty()) {
                teamSearchChoiceBox.getSelectionModel().selectFirst();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void refreshRacesTable() {
        try {
            GetCurseResponse response = blockingStub.getCurse(EmptyRequest.newBuilder().build());
            raceTable.setItems(FXCollections.observableArrayList(response.getCurseList()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSearchParticipants() {
        String teamName = teamSearchChoiceBox.getValue();
        if (teamName == null || teamName.isEmpty()) {
            participantTable.getItems().clear();
            return;
        }
        try {
            SearchByTeamRequest request = SearchByTeamRequest.newBuilder()
                    .setEchipa(teamName)
                    .build();

            SearchByTeamResponse response = blockingStub.searchByTeam(request);
            participantTable.setItems(FXCollections.observableArrayList(response.getParticipantiList()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleRegisterParticipant() {
        registerErrorLabel.setVisible(false);

        String name = nameField.getText().trim();
        String cnp = cnpField.getText().trim();
        String enteredTeam = teamRegisterField.getText().trim();
        String engineCapacityStr = engineCapacityField.getText().trim();

        if (name.isEmpty() || cnp.isEmpty()) {
            registerErrorLabel.setText("Nume si CNP obligatorii!");
            registerErrorLabel.setVisible(true);
            return;
        }
        if (engineCapacityStr.isEmpty()) {
            registerErrorLabel.setText("Introduceti capacitatea motorului!");
            registerErrorLabel.setVisible(true);
            return;
        }
        int engineCapacity;
        try {
            engineCapacity = Integer.parseInt(engineCapacityStr);
        } catch (NumberFormatException e) {
            registerErrorLabel.setText("Capacitatea motorului trebuie sa fie un numar!");
            registerErrorLabel.setVisible(true);
            return;
        }
        if (enteredTeam.isEmpty()) {
            registerErrorLabel.setText("Introduceti echipa!");
            registerErrorLabel.setVisible(true);
            return;
        }

        new Thread(() -> {
            try {
                AddParticipantRequest request = AddParticipantRequest.newBuilder()
                        .setRequestUsername(loggedUsername)
                        .setNume(name)
                        .setCnp(cnp)
                        .setEchipa(enteredTeam)
                        .setCapacitate(engineCapacity)
                        .build();

                AddParticipantResponse response = blockingStub.addParticipant(request);

                Platform.runLater(() -> {
                    if (response.getSuccess()) {
                        refreshRacesTable();
                        clearRegistrationFields();
                        handleSearchParticipants();
                        initChoiceBoxes();
                    } else {
                        registerErrorLabel.setText("Eroare: " + response.getErrorMessage());
                        registerErrorLabel.setVisible(true);
                    }
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    registerErrorLabel.setText("Eroare server: " + e.getMessage());
                    registerErrorLabel.setVisible(true);
                });
            }
        }).start();
    }

    private void clearRegistrationFields() {
        nameField.clear();
        cnpField.clear();
        teamRegisterField.clear();
        engineCapacityField.clear();
    }

    @FXML
    private void handleLogout() {
        blockingStub.logout(LogoutRequest.newBuilder().setUsername(loggedUsername).build());
        ((Stage) loggedUserLabel.getScene().getWindow()).close();
    }

    private void startListeningForParticipantUpdates() {
        SubscribeRequest request = SubscribeRequest.newBuilder()
                .setUsername(loggedUsername)
                .build();

        asyncStub.subscribeToParticipantUpdates(request, new StreamObserver<ParticipantAddedUpdate>() {
            @Override
            public void onNext(ParticipantAddedUpdate value) {
                Platform.runLater(() -> {
                    refreshRacesTable();
                    handleSearchParticipants();
                    initChoiceBoxes();
                });
            }
            @Override public void onError(Throwable t) { System.err.println(t); }
            @Override public void onCompleted() { }
        });
    }
}