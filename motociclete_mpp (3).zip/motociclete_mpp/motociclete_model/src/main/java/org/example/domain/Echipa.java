package org.example.domain;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "Echipa")
public class Echipa extends EntityID<Long> implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String numeEchipa;

    public Echipa() {}

    public Echipa(String numeEchipa) {
        this.numeEchipa = numeEchipa;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public String getNumeEchipa() {
        return numeEchipa;
    }

    public void setNumeEchipa(String numeEchipa) {
        this.numeEchipa = numeEchipa;
    }

    @Override
    public String toString() {
        return "Echipa{" +
                "id=" + id +
                ", numeEchipa='" + numeEchipa + '\'' +
                '}';
    }
}


/*public class Echipa extends EntityID<Long> implements Serializable {
    private String numeEchipa;

    public Echipa() {}
    public Echipa(String numeEchipa) {
        this.numeEchipa = numeEchipa;
    }

    public String getNumeEchipa() {
        return numeEchipa;
    }

    public void setNumeEchipa(String numeEchipa) {
        this.numeEchipa = numeEchipa;
    }

    @Override
    public String toString() {
        return "Echipa{" +
                "id=" + getId() +
                "numeEchipa='" + numeEchipa + '\'' +
                '}';
    }
}*/
