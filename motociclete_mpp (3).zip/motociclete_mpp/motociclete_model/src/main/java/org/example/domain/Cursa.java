package org.example.domain;

import java.util.List;

public class Cursa extends EntityID<Long> {
    private int capacitateMotor;
    private int nrParticipanti;
    private List<Participant> participanti;

    public Cursa() {}
    public Cursa(int capacitateMotor, int nrParticipanti, List<Participant> participanti) {
        this.capacitateMotor = capacitateMotor;
        this.nrParticipanti = nrParticipanti;
        this.participanti = participanti;
    }

    public int getCapacitateMotor() {
        return capacitateMotor;
    }

    public void setCapacitateMotor(int capacitateMotor) {
        this.capacitateMotor = capacitateMotor;
    }

    public int getNrParticipanti() {
        return nrParticipanti;
    }

    public void setNrParticipanti(int nrParticipanti) {
        this.nrParticipanti = nrParticipanti;
    }

    public List<Participant> getParticipanti() {
        return participanti;
    }

    public void setParticipanti(List<Participant> participanti) {
        this.participanti = participanti;
    }

    public void addParticipant(Participant participant) {
        this.participanti.add(participant);
    }

    public void removeParticipant(Participant participant) {
        this.participanti.remove(participant);
    }

    @Override
    public String toString() {
        return "Cursa{" +
                "id=" + getId() +
                "capacitateMotor=" + capacitateMotor +
                ", nrParticipanti=" + nrParticipanti +
                ", participanti=" + participanti +
                '}';
    }
}
