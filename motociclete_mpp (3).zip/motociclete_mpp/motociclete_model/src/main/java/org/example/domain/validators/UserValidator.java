package org.example.domain.validators;

import org.example.domain.User;

public class UserValidator implements Validator<User>{
    @Override
    public void validate(User entity) throws ValidationException {
        String errors = "";
        if (entity.getUsername().equals("")) {
            errors += "Username-ul nu poate fi vid!\n";
        }
        if (entity.getPassword().equals("")) {
            errors += "Parola nu poate fi vida!\n";
        }
        if (!errors.equals("")) {
            throw new ValidationException(errors);
        }
    }
}
