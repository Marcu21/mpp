package org.example.domain.validators;

import org.example.domain.Cursa;

public class CursaValidator implements Validator<Cursa> {
    @Override
    public void validate(Cursa entity) throws ValidationException {
        String errors = "";
        if (entity.getCapacitateMotor() <= 0) {
            errors += "Capacitatea trebuie sa fie un numar pozitiv!\n";
        }
        if (entity.getNrParticipanti() < 0) {
            errors += "Numarul de participanti trebuie sa fie un numar pozitiv!\n";
        }
        if (!errors.equals("")) {
            throw new ValidationException(errors);
        }
    }
}
