package org.example.domain;

public class Participant extends EntityID<Long> {
    private String nume;
    private String CNP;
    private Long idEchipa;

    public Participant() {}
    public Participant(String nume, String CNP, Long idEchipa){
        this.nume = nume;
        this.CNP = CNP;
        this.idEchipa = idEchipa;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getCNP() {
        return CNP;
    }

    public void setCNP(String CNP) {
        this.CNP = CNP;
    }

    public Long getIdEchipa() {
        return idEchipa;
    }

    public void setIdEchipa(Long idEchipa) {
        this.idEchipa = idEchipa;
    }

    @Override
    public String toString() {
        return "Participant{" +
                "id=" + getId() +
                ", nume='" + nume + '\'' +
                ", CNP='" + CNP + '\'' +
                ", idEchipa=" + idEchipa +
                '}';
    }
}
