package org.example.domain.dto;

import java.io.Serializable;

public class CursaDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private int capacitateMotor;
    private int nrParticipanti;

    public CursaDTO(int capacitateMotor, int nrParticipanti) {
        this.capacitateMotor = capacitateMotor;
        this.nrParticipanti = nrParticipanti;
    }

    public int getCapacitateMotor() {
        return capacitateMotor;
    }

    public int getNrParticipanti() {
        return nrParticipanti;
    }

    @Override
    public String toString() {
        return "CursaDTO{" +
                "capacitateMotor=" + capacitateMotor +
                ", nrParticipanti=" + nrParticipanti +
                '}';
    }
}
