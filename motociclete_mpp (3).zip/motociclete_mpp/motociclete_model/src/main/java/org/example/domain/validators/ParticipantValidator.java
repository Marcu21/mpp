package org.example.domain.validators;

import org.example.domain.Participant;

public class ParticipantValidator implements Validator<Participant> {
    @Override
    public void validate(Participant entity) throws ValidationException {
        String errors = "";
        if (entity.getNume() == null || entity.getNume().equals("")) {
            errors += "Numele nu poate fi vid!\n";
        }
        if (entity.getCNP() == null || entity.getCNP().equals("")) {
            errors += "CNP-ul nu poate fi vid!\n";
        }
        if (entity.getIdEchipa() < 0) {
            errors += "Id-ul echipei nu poate fi negativ!\n";
        }
        if (!errors.equals("")) {
            throw new ValidationException(errors);
        }
    }
}
