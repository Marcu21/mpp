package org.example.domain.dto;

import java.io.Serializable;

public class ParticipantDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String nume;
    private int capacitateMotor;

    public ParticipantDTO(String nume, int capacitateMotor) {
        this.nume = nume;
        this.capacitateMotor = capacitateMotor;
    }

    public String getNume() {
        return nume;
    }

    public int getCapacitateMotor() {
        return capacitateMotor;
    }

    @Override
    public String toString() {
        return "ParticipantDTO{" +
                "nume='" + nume + '\'' +
                ", capacitateMotor=" + capacitateMotor +
                '}';
    }
}
