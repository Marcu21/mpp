package org.example.domain.validators;

import org.example.domain.Echipa;

public class EchipaValidator implements Validator<Echipa>{
    @Override
    public void validate(Echipa entity) throws ValidationException {
        String errors = "";
        if (entity.getNumeEchipa().equals("")) {
            errors += "Numele echipei nu poate fi vid! ";
        }
        if (!errors.equals("")) {
            throw new ValidationException(errors);
        }
    }
}
