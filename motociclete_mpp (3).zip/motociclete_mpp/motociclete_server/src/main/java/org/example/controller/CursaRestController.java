package org.example.controller;

import org.example.domain.Cursa;
import org.example.domain.Participant;
import org.example.service.CursaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:5174", "http://localhost:5175"})
@RestController
@RequestMapping("/api/curse")
public class CursaRestController {

    private final CursaService cursaService;

    public CursaRestController(CursaService cursaService) {
        this.cursaService = cursaService;
    }

    @PostMapping
    public ResponseEntity<Cursa> createCursa(@RequestBody Cursa cursa) {
        try {
            cursaService.addRace(cursa.getCapacitateMotor(), cursa.getNrParticipanti(), cursa.getParticipanti());

            Cursa saved = cursaService.getRaceByCC(cursa.getCapacitateMotor());

            return new ResponseEntity<>(saved, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping
    public ResponseEntity<List<Cursa>> getAll() {
        return new ResponseEntity<>(List.copyOf(cursaService.getAllRaces()), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cursa> getById(@PathVariable Long id) {
        Cursa cursa = cursaService.getRaceById(id);
        if (cursa != null)
            return new ResponseEntity<>(cursa, HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@PathVariable Long id, @RequestBody Cursa cursa) {
        try {
            cursaService.updateRace(id, cursa.getCapacitateMotor(), cursa.getNrParticipanti(), cursa.getParticipanti());
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        try {
            cursaService.deleteRace(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}

