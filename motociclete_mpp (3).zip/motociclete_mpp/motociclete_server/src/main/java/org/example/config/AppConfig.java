package org.example.config;

import org.example.repository.CursaDBRepository;
import org.example.repository.CursaRepository;
import org.example.repository.hibernate.HibernateUserRepository;
import org.example.service.CursaService;
import org.example.service.UserService;
import org.example.utils.HibernateUtil;
import org.example.utils.JwtUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public CursaRepository cursaRepository() {
        return new CursaDBRepository();
    }

    @Bean
    public CursaService cursaService() {
        return new CursaService(cursaRepository());
    }

    @Bean
    public HibernateUserRepository hibernateUserRepository() {
        return new HibernateUserRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public UserService userService() {
        return new UserService(new HibernateUserRepository(HibernateUtil.getSessionFactory()));
    }

    @Bean
    public JwtUtil jwtUtil() {
        return new JwtUtil();
    }
}