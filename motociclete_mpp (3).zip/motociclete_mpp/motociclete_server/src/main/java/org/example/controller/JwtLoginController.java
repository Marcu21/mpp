package org.example.controller;

import org.example.domain.User;
import org.example.service.UserService;
import org.example.utils.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:5174", "http://localhost:5175"})
@RestController
@RequestMapping("/api/auth")
public class JwtLoginController {

    private final UserService userService;
    private final JwtUtil jwtUtil;

    public JwtLoginController(UserService userService, JwtUtil jwtUtil) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");
        String hashedPassword = UserService.hashPassword(password);

        for (var user : userService.getAllUsers()) {
            if (user.getUsername().equals(username) && user.getPassword().equals(hashedPassword)) {
                String token = jwtUtil.generateToken(username);
                return ResponseEntity.ok(Map.of("token", token));
            }
        }

        return ResponseEntity.status(401).body("Invalid credentials");
    }
}
