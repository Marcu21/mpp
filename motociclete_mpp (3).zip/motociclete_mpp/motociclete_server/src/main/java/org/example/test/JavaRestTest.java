package org.example.test;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.io.IOException;

public class JavaRestTest {
    public static void main(String[] args) throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();

        HttpRequest getRequest1 = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/curse"))
                .GET()
                .build();

        HttpResponse<String> getResponse1 = client.send(getRequest1, HttpResponse.BodyHandlers.ofString());
        System.out.println("GET /api/curse:");
        System.out.println(getResponse1.body());

        String json = """
        {
            "capacitateMotor": 550,
            "nrParticipanti": 0,
            "participanti": []
        }
        """;

        HttpRequest postRequest = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/curse"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> postResponse = client.send(postRequest, HttpResponse.BodyHandlers.ofString());
        System.out.println("POST /api/curse:");
        System.out.println(postResponse.body());

        HttpRequest getRequest2 = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/curse"))
                .GET()
                .build();

        HttpResponse<String> getResponse2 = client.send(getRequest2, HttpResponse.BodyHandlers.ofString());
        System.out.println("GET /api/curse:");
        System.out.println(getResponse2.body());
    }
}
