package org.example.server;

import org.example.domain.Cursa;
import org.example.domain.Participant;
import org.example.domain.dto.CursaDTO;
import org.example.domain.dto.ParticipantDTO;
import org.example.networking.IMotocicleteObserver;
import org.example.networking.IMotocicleteService;
import org.example.service.ParticipantService;
import org.example.service.UserService;
import org.example.service.CursaService;
import org.example.service.EchipaService;
import org.example.domain.Echipa;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MotocicleteService implements IMotocicleteService {
    private final UserService userService;
    private final ParticipantService participantService;
    private final CursaService cursaService;
    private final EchipaService echipaService;
    private final Map<String, IMotocicleteObserver> loggedClients = new ConcurrentHashMap<>();

    public MotocicleteService(UserService userService, ParticipantService participantService,
                              CursaService cursaService, EchipaService echipaService) {
        this.userService = userService;
        this.participantService = participantService;
        this.cursaService = cursaService;
        this.echipaService = echipaService;
    }

    @Override
    public void login(String username, String password, IMotocicleteObserver client) throws Exception {
        String hashedPassword = hashPassword(password);
        System.out.println(hashedPassword);
        for (var user : userService.getAllUsers()) {
            if (user.getUsername().equals(username) && user.getPassword().equals(hashedPassword)) {
                if (loggedClients.containsKey(username))
                    throw new Exception("User already logged in.");
                loggedClients.put(username, client);
                return;
            }
        }
        throw new Exception("Invalid credentials.");
    }

    @Override
    public void logout(String username, IMotocicleteObserver client) throws Exception {
        loggedClients.remove(username);
    }

    @Override
    public void addParticipant(String requestUsername, String nume, String cnp, String echipa, int capacitate) throws Exception {
        if (nume == null || nume.isEmpty() || cnp == null || cnp.isEmpty()) {
            throw new Exception("Nume si CNP sunt obligatorii!");
        }
        if (echipa == null || echipa.isEmpty()) {
            throw new Exception("Echipa este obligatorie!");
        }
        if (cursaService.getRaceByCC(capacitate) == null) {
            throw new Exception("Nu exista o cursa cu aceasta capacitate!");
        }

        Echipa echipaObj = echipaService.getTeamByName(echipa);
        long echipaId;
        if (echipaObj != null) {
            echipaId = echipaObj.getId();
        } else {
            echipaService.addTeam(echipa);
            echipaId = echipaService.getTeamByName(echipa).getId();
        }

        participantService.addParticipant(nume, cnp, echipaId);
        Participant participant = participantService.getParticipantByNameAndCnp(nume, cnp);

        if (participant != null) {
            cursaService.registerParticipantToRace(capacitate, participant);
            ParticipantDTO dto = new ParticipantDTO(participant.getNume(), capacitate);

            new Thread(() -> {
                for (Map.Entry<String, IMotocicleteObserver> entry : loggedClients.entrySet()) {
                    if (!entry.getKey().equals(requestUsername)) {
                        try {
                            entry.getValue().participantAdded(dto);
                        } catch (Exception e) {
                            System.err.println("Eroare notificare " + entry.getKey() + ": " + e.getMessage());
                        }
                    }
                }
            }).start();
        } else {
            throw new Exception("Participantul nu a putut fi inregistrat.");
        }
    }



    @Override
    public List<ParticipantDTO> searchByTeam(String echipa) throws Exception {
        List<ParticipantDTO> dtos = new ArrayList<>();
        Echipa echipaObj = echipaService.getTeamByName(echipa);
        if (echipaObj == null) return dtos;

        Long echipaId = echipaObj.getId();
        List<Participant> participanti = new ArrayList<>(participantService.getAllParticipants());
        List<Cursa> curse = new ArrayList<>(cursaService.getAllRaces());

        for (Participant p : participanti) {
            if (!p.getIdEchipa().equals(echipaId)) continue;

            for (Cursa cursa : curse) {
                List<Participant> participantiCursa = cursa.getParticipanti();
                for (Participant part : participantiCursa) {
                    if (part.getId().equals(p.getId())) {
                        ParticipantDTO dto = new ParticipantDTO(p.getNume(), cursa.getCapacitateMotor());
                        dtos.add(dto);
                    }
                }
            }
        }

        return dtos;
    }

    @Override
    public List<CursaDTO> getCurse() throws Exception {
        List<Cursa> curse = new ArrayList<>(cursaService.getAllRaces());
        List<CursaDTO> dtos = new ArrayList<>();
        for (Cursa c : curse) {
            dtos.add(new CursaDTO(c.getCapacitateMotor(), c.getNrParticipanti()));
        }
        return dtos;
    }

    private void notifyParticipantAdded(ParticipantDTO dto) throws Exception {
        for (IMotocicleteObserver client : loggedClients.values()) {
            client.participantAdded(dto);
        }
    }

    @Override
    public List<Echipa> getAllEchipe() throws Exception {
        return new ArrayList<>(echipaService.getAllTeams());
    }

    private static String hashPassword(String rawData) {
        try {
            MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = sha256.digest(rawData.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }


}
