package org.example.server;

import org.example.networking.RequestHandler;
import org.example.repository.*;
import org.example.repository.hibernate.HibernateEchipaRepository;
import org.example.service.CursaService;
import org.example.service.EchipaService;
import org.example.service.ParticipantService;
import org.example.service.UserService;
import org.example.utils.HibernateUtil;
import org.example.repository.hibernate.HibernateUserRepository;
import org.example.repository.hibernate.HibernateEchipaRepository;
import org.example.utils.HibernateUtil;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    private static final int PORT = 5555;

    public static void main(String[] args) {
        UserRepository userRepo = new HibernateUserRepository(HibernateUtil.getSessionFactory());
        ParticipantRepository participantRepo = new ParticipantDBRepository();
        CursaRepository cursaRepo = new CursaDBRepository();
        EchipaRepository echipaRepo = new HibernateEchipaRepository(HibernateUtil.getSessionFactory());

        UserService userService = new UserService(userRepo);
        ParticipantService participantService = new ParticipantService(participantRepo);
        CursaService cursaService = new CursaService(cursaRepo);
        EchipaService echipaService = new EchipaService(echipaRepo);

        MotocicleteService service = new MotocicleteService(
                userService, participantService, cursaService, echipaService);

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket client = serverSocket.accept();
                System.out.println("Client connected: " + client);
                new Thread(new RequestHandler(service, client)).start();
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }
}
