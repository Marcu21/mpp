package org.example.repository;

import org.example.domain.Participant;

public interface ParticipantRepository extends Repository<Participant, Long>{
}
