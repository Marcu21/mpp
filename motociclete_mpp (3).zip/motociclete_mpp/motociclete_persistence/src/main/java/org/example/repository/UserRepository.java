package org.example.repository;

import org.example.domain.User;

public interface UserRepository extends Repository<User, Long> {
}
