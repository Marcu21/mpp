package org.example.repository.hibernate;

import org.example.domain.User;
import org.example.repository.UserRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.Collection;
import java.util.List;

public class HibernateUserRepository implements UserRepository {

    private final SessionFactory sessionFactory;

    public HibernateUserRepository(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void add(User user) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.persist(user);
            tran.commit();
        }
    }

    @Override
    public Iterable<User> findAll() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("from User", User.class).list();
        }
    }

    @Override
    public User findById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(User.class, id);
        }
    }

    @Override
    public void update(User user) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.merge(user);
            tran.commit();
        }
    }

    @Override
    public void delete(User user) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.remove(session.contains(user) ? user : session.merge(user));
            tran.commit();
        }
    }

    @Override
    public Collection<User> getAll() {
        return (Collection<User>) findAll();
    }
}
