package org.example.repository.hibernate;

import org.example.domain.Echipa;
import org.example.repository.EchipaRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.Collection;
import java.util.List;

public class HibernateEchipaRepository implements EchipaRepository {

    private final SessionFactory sessionFactory;

    public HibernateEchipaRepository(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void add(Echipa echipa) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.persist(echipa);
            tran.commit();
        }
    }

    @Override
    public Iterable<Echipa> findAll() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("from Echipa", Echipa.class).list();
        }
    }

    @Override
    public Echipa findById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Echipa.class, id);
        }
    }

    @Override
    public void update(Echipa echipa) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.merge(echipa);
            tran.commit();
        }
    }

    @Override
    public void delete(Echipa echipa) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.remove(session.contains(echipa) ? echipa : session.merge(echipa));
            tran.commit();
        }
    }

    @Override
    public Collection<Echipa> getAll() {
        return (Collection<Echipa>) findAll();
    }
}
