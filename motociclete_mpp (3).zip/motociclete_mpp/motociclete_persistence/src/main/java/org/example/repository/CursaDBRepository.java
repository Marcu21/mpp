package org.example.repository;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.domain.Cursa;
import org.example.domain.Participant;
import org.example.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CursaDBRepository implements CursaRepository {
    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public CursaDBRepository() {
        logger.info("Initializing CursaDBRepository");
        dbUtils = new JdbcUtils();
        this.con = dbUtils.getConnection();
    }

    @Override
    public void add(Cursa cursa) {
        logger.traceEntry("Saving cursa {}", cursa);
        String sql = "INSERT INTO Cursa (capacitateMotor, nrParticipanti) VALUES (?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, cursa.getCapacitateMotor());
            stmt.setInt(2, cursa.getNrParticipanti());
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    cursa.setId(generatedKeys.getLong(1));
                }
            }

            for (Participant participant : cursa.getParticipanti()) {
                addParticipantToCursa(cursa.getId(), participant.getId());
            }

            logger.trace("Saved {}", cursa);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<Cursa> findAll() {
        logger.traceEntry();
        List<Cursa> curse = new ArrayList<>();
        String sql = "SELECT * FROM Cursa";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            List<Cursa> tempCurse = new ArrayList<>();

            while (rs.next()) {
                Long id = rs.getLong("id");
                int capacitateMotor = rs.getInt("capacitateMotor");
                int nrParticipanti = rs.getInt("nrParticipanti");

                Cursa cursa = new Cursa(capacitateMotor, nrParticipanti, new ArrayList<>());
                cursa.setId(id);
                tempCurse.add(cursa);
            }

            for (Cursa cursa : tempCurse) {
                List<Participant> participanti = getParticipantiForCursa(cursa.getId());
                cursa.setParticipanti(participanti);
                curse.add(cursa);
            }

        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(curse);
        return curse;
    }


    @Override
    public List<Participant> getParticipantiForCursa(Long idCursa) {
        List<Participant> participanti = new ArrayList<>();
        String sql = """
            SELECT p.id, p.nume, p.CNP, p.idEchipa
            FROM Participant p
            JOIN Cursa_Participant cp ON p.id = cp.idParticipant
            WHERE cp.idCursa = ?
            """;

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, idCursa);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Long id = rs.getLong("id");
                    String nume = rs.getString("nume");
                    String CNP = rs.getString("CNP");
                    Long idEchipa = rs.getLong("idEchipa");

                    Participant participant = new Participant(nume, CNP, idEchipa);
                    participant.setId(id);
                    participanti.add(participant);
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        return participanti;
    }

    @Override
    public void addParticipantToCursa(Long idCursa, Long idParticipant) {
        logger.traceEntry("Adding participant {} to cursa {}", idParticipant, idCursa);
        String sql = "INSERT INTO Cursa_Participant (idCursa, idParticipant) VALUES (?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, idCursa);
            stmt.setLong(2, idParticipant);
            stmt.executeUpdate();
            logger.trace("Added participant {} to cursa {}", idParticipant, idCursa);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public void deleteAllParticipantsFromCursa(Long idCursa) {
        logger.traceEntry("Deleting all participants from cursa with id {}", idCursa);
        String sql = "DELETE FROM Cursa_Participant WHERE idCursa=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, idCursa);
            stmt.executeUpdate();
            logger.trace("Deleted all participants from cursa {}", idCursa);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public void update(Cursa cursa) {
        logger.traceEntry("Updating cursa {}", cursa);

        String sql = "UPDATE Cursa SET capacitateMotor=?, nrParticipanti=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, cursa.getCapacitateMotor());
            stmt.setInt(2, cursa.getNrParticipanti());
            stmt.setLong(3, cursa.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", cursa);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        deleteAllParticipantsFromCursa(cursa.getId());

        for (Participant participant : cursa.getParticipanti()) {
            addParticipantToCursa(cursa.getId(), participant.getId());
        }

        logger.traceExit();
    }

    @Override
    public void delete(Cursa cursa) {
        logger.traceEntry("Deleting cursa {}", cursa);
        String sql = "DELETE FROM Cursa WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, cursa.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", cursa);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public Cursa findById(Long id) {
        logger.traceEntry("Finding cursa by id {}", id);
        String sql = "SELECT * FROM Cursa WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int capacitateMotor = rs.getInt("capacitateMotor");
                    int nrParticipanti = rs.getInt("nrParticipanti");
                    List<Participant> participanti = getParticipantiForCursa(id);

                    Cursa cursa = new Cursa(capacitateMotor, nrParticipanti, participanti);
                    cursa.setId(id);
                    logger.traceExit(cursa);
                    return cursa;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Cursa> getAll() {
        return (Collection<Cursa>) findAll();
    }
}
