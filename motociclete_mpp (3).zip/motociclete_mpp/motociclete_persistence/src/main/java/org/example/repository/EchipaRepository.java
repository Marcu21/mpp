package org.example.repository;

import org.example.domain.Echipa;

public interface EchipaRepository extends Repository<Echipa, Long> {
}
