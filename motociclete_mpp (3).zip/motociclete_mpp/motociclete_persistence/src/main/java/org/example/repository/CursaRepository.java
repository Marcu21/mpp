package org.example.repository;

import org.example.domain.Cursa;
import org.example.domain.Participant;
import java.util.List;

public interface CursaRepository extends Repository<Cursa, Long> {
    List<Participant> getParticipantiForCursa(Long idCursa);

    void addParticipantToCursa(Long idCursa, Long idParticipant);

    void deleteAllParticipantsFromCursa(Long idCursa);
}
