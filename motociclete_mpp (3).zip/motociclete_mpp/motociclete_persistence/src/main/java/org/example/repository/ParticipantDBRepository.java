package org.example.repository;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.domain.Participant;
import org.example.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ParticipantDBRepository implements ParticipantRepository {
    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public ParticipantDBRepository() {
        logger.info("Initializing ParticipantDBRepository");
        dbUtils = new JdbcUtils();
        this.con = dbUtils.getConnection();
    }

    @Override
    public void add(Participant participant) {
        logger.traceEntry("Saving participant {}", participant);
        String sql = "INSERT INTO Participant (nume, CNP, idEchipa) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, participant.getNume());
            stmt.setString(2, participant.getCNP());
            stmt.setLong(3, participant.getIdEchipa());
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    participant.setId(generatedKeys.getLong(1));
                }
            }
            logger.trace("Saved {}", participant);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<Participant> findAll() {
        logger.traceEntry();
        List<Participant> participanti = new ArrayList<>();
        String sql = "SELECT * FROM Participant";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Long id = rs.getLong("id");
                String nume = rs.getString("nume");
                String CNP = rs.getString("CNP");
                Long idEchipa = rs.getLong("idEchipa");
                Participant participant = new Participant(nume, CNP, idEchipa);
                participant.setId(id);
                participanti.add(participant);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(participanti);
        return participanti;
    }

    @Override
    public Participant findById(Long id) {
        logger.traceEntry("Finding participant by id {}", id);
        String sql = "SELECT * FROM Participant WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String nume = rs.getString("nume");
                    String CNP = rs.getString("CNP");
                    Long idEchipa = rs.getLong("idEchipa");

                    Participant participant = new Participant(nume, CNP, idEchipa);
                    participant.setId(id);
                    logger.traceExit(participant);
                    return participant;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public void delete(Participant participant) {
        logger.traceEntry("Deleting participant {}", participant);
        String sql = "DELETE FROM Participant WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, participant.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", participant);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public void update(Participant participant) {
        logger.traceEntry("Updating participant {}", participant);
        String sql = "UPDATE Participant SET nume=?, CNP=?, idEchipa=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, participant.getNume());
            stmt.setString(2, participant.getCNP());
            stmt.setLong(3, participant.getIdEchipa());
            stmt.setLong(4, participant.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", participant);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public Collection<Participant> getAll() {
        return (Collection<Participant>) findAll();
    }
}
