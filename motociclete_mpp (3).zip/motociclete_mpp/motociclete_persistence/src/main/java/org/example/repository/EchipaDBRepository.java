package org.example.repository;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.domain.Echipa;
import org.example.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class EchipaDBRepository implements EchipaRepository {
    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public EchipaDBRepository() {
        logger.info("Initializing EchipaDBRepository");
        dbUtils = new JdbcUtils();
        this.con = dbUtils.getConnection();
    }

    @Override
    public void add(Echipa echipa) {
        logger.traceEntry("Saving echipa {}", echipa);
        String sql = "INSERT INTO Echipa (numeEchipa) VALUES (?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, echipa.getNumeEchipa());
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    echipa.setId(generatedKeys.getLong(1));
                }
            }
            logger.trace("Saved {}", echipa);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<Echipa> findAll() {
        logger.traceEntry();
        List<Echipa> echipe = new ArrayList<>();
        String sql = "SELECT * FROM Echipa";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Long id = rs.getLong("id");
                String numeEchipa = rs.getString("numeEchipa");
                Echipa echipa = new Echipa(numeEchipa);
                echipa.setId(id);
                echipe.add(echipa);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(echipe);
        return echipe;
    }

    @Override
    public void delete(Echipa echipa) {
        logger.traceEntry("Deleting echipa {}", echipa);
        String sql = "DELETE FROM Echipa WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, echipa.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", echipa);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public void update(Echipa echipa) {
        logger.traceEntry("Updating echipa {}", echipa);
        String sql = "UPDATE Echipa SET numeEchipa=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, echipa.getNumeEchipa());
            stmt.setLong(2, echipa.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", echipa);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public Echipa findById(Long id) {
        logger.traceEntry("Finding echipa by id {}", id);
        String sql = "SELECT * FROM Echipa WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String numeEchipa = rs.getString("numeEchipa");
                    Echipa echipa = new Echipa(numeEchipa);
                    echipa.setId(id);
                    logger.traceExit(echipa);
                    return echipa;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Echipa> getAll() {
        return (Collection<Echipa>) findAll();
    }
}
