package org.example.service;

import org.example.domain.User;
import org.example.domain.validators.UserValidator;
import org.example.repository.UserRepository;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;

public class UserService {
    private final UserRepository userRepository;
    private final UserValidator userValidator;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
        this.userValidator = new UserValidator();
    }

    public void addUser(String username, String password) {
        User user = new User(username, password);
        userValidator.validate(user);
        userRepository.add(user);
    }

    public User getUserById(Long id) {
        return userRepository.findById(id);
    }

    public Collection<User> getAllUsers() {
        return userRepository.getAll();
    }

    public void updateUser(Long id, String newUsername, String newPassword) {
        User user = userRepository.findById(id);
        if (user != null) {
            user.setUsername(newUsername);
            user.setPassword(newPassword);
            userValidator.validate(user);
            userRepository.update(user);
        } else {
            throw new IllegalArgumentException("Utilizatorul cu ID-ul " + id + " nu exista!");
        }
    }

    public void deleteUser(Long id) {
        User user = userRepository.findById(id);
        if (user != null) {
            userRepository.delete(user);
        } else {
            throw new IllegalArgumentException("Utilizatorul cu ID-ul " + id + " nu exista!");
        }
    }

    public User login(String username, String password) throws Exception {
        for (User user : getAllUsers()) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        throw new Exception("Invalid credentials");
    }

    public static String hashPassword(String rawData) {
        try {
            MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = sha256.digest(rawData.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

}
