package org.example.service;

import org.example.domain.Participant;
import org.example.domain.validators.ParticipantValidator;
import org.example.repository.ParticipantRepository;

import java.util.Collection;

public class ParticipantService {
    private final ParticipantRepository participantRepository;
    private final ParticipantValidator participantValidator;

    public ParticipantService(ParticipantRepository participantRepository) {
        this.participantRepository = participantRepository;
        this.participantValidator = new ParticipantValidator();
    }

    public void addParticipant(String name, String cnp, Long teamId) {
        Participant participant = new Participant(name, cnp, teamId);
        participantValidator.validate(participant);
        participantRepository.add(participant);
    }

    public Participant getParticipantById(Long id) {
        return participantRepository.findById(id);
    }

    public Collection<Participant> getAllParticipants() {
        return participantRepository.getAll();
    }

    public void updateParticipant(Long id, String newName, String newCnp, Long newTeamId) {
        Participant participant = participantRepository.findById(id);
        if (participant != null) {
            participant.setNume(newName);
            participant.setCNP(newCnp);
            participant.setIdEchipa(newTeamId);
            participantValidator.validate(participant);
            participantRepository.update(participant);
        } else {
            throw new IllegalArgumentException("Participantul cu ID-ul " + id + " nu exista!");
        }
    }

    public void deleteParticipant(Long id) {
        Participant participant = participantRepository.findById(id);
        if (participant != null) {
            participantRepository.delete(participant);
        } else {
            throw new IllegalArgumentException("Participantul cu ID-ul " + id + " nu exista!");
        }
    }

    public Participant getParticipantByNameAndCnp(String name, String cnp) {
        for(Participant participant : participantRepository.getAll()) {
            if(participant.getNume().equals(name) && participant.getCNP().equals(cnp)) {
                return participant;
            }
        }
        return null;
    }

}
