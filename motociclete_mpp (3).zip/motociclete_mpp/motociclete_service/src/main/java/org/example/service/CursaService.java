package org.example.service;

import org.example.domain.Cursa;
import org.example.domain.Participant;
import org.example.domain.validators.CursaValidator;
import org.example.repository.CursaRepository;

import java.util.*;

public class CursaService {
    private final CursaRepository cursaRepository;
    private final CursaValidator cursaValidator;

    public CursaService(CursaRepository cursaRepository) {
        this.cursaRepository = cursaRepository;
        this.cursaValidator = new CursaValidator();
    }

    public void addRace(int engineCapacity, int numberOfParticipants, List<Participant> participants) {
        Cursa cursa = new Cursa(engineCapacity, numberOfParticipants, participants);
        cursaValidator.validate(cursa);
        cursaRepository.add(cursa);
    }

    public Cursa getRaceById(Long id) {
        return cursaRepository.findById(id);
    }

    public Collection<Cursa> getAllRaces() {
        return cursaRepository.getAll();
    }

    public void updateRace(Long id, int newEngineCapacity, int newNumberOfParticipants, List<Participant> newParticipants) {
        Cursa existingRace = cursaRepository.findById(id);
        if (existingRace != null) {
            existingRace.setCapacitateMotor(newEngineCapacity);
            existingRace.setNrParticipanti(newNumberOfParticipants);
            existingRace.setParticipanti(newParticipants);
            cursaValidator.validate(existingRace);
            cursaRepository.update(existingRace);
        } else {
            throw new IllegalArgumentException("Cursa cu ID-ul " + id + " nu exista!");
        }
    }

    public void deleteRace(Long id) {
        Cursa cursa = cursaRepository.findById(id);
        if (cursa != null) {
            cursaRepository.delete(cursa);
        } else {
            throw new IllegalArgumentException("Cursa cu ID-ul " + id + " nu exista!");
        }
    }

    public List<Participant> getParticipantsForRace(Long raceId) {
        return cursaRepository.getParticipantiForCursa(raceId);
    }

    public void registerParticipantToRace(int engineCapacity, Participant participant) {
        Cursa race = getRaceByCC(engineCapacity);
        if (race == null) {
            throw new IllegalArgumentException("Nu exista cursa de " + engineCapacity + "cc!");
        }
        List<Participant> participanti = new ArrayList<Participant>(race.getParticipanti());
        participanti.add(participant);
        int nrParticipanti = participanti.size();
        race.setParticipanti(participanti);
        race.setNrParticipanti(nrParticipanti);
        updateRace(race.getId(), race.getCapacitateMotor(), nrParticipanti, participanti);
    }


    public Cursa getRaceByCC(int cc) {
        for (Cursa cursa : cursaRepository.getAll()) {
            if (cursa.getCapacitateMotor() == cc) {
                return cursa;
            }
        }
        return null;
    }


    public Cursa getRaceForParticipant(Long participantId) {
        for(Cursa cursa : cursaRepository.getAll()) {
            for(Participant participant : cursa.getParticipanti()) {
                if(participant.getId().equals(participantId)) {
                    return cursa;
                }
            }
        }
        return null;
    }

}
