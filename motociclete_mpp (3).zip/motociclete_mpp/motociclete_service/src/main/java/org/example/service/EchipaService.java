package org.example.service;

import org.example.domain.Echipa;
import org.example.domain.validators.EchipaValidator;
import org.example.repository.EchipaRepository;

import java.util.Collection;

public class EchipaService {
    private final EchipaRepository echipaRepository;
    private final EchipaValidator echipaValidator;

    public EchipaService(EchipaRepository echipaRepository) {
        this.echipaRepository = echipaRepository;
        this.echipaValidator = new EchipaValidator();
    }

    public void addTeam(String teamName) {
        Echipa team = new Echipa(teamName);
        echipaValidator.validate(team);
        echipaRepository.add(team);
    }

    public Echipa getTeamById(Long id) {
        return echipaRepository.findById(id);
    }

    public Collection<Echipa> getAllTeams() {
        return echipaRepository.getAll();
    }

    public void updateTeam(Long id, String newTeamName) {
        Echipa team = echipaRepository.findById(id);
        if (team != null) {
            team.setNumeEchipa(newTeamName);
            echipaValidator.validate(team);
            echipaRepository.update(team);
        } else {
            throw new IllegalArgumentException("Echipa cu ID-ul " + id + " nu exista!");
        }
    }

    public void deleteTeam(Long id) {
        Echipa team = echipaRepository.findById(id);
        if (team != null) {
            echipaRepository.delete(team);
        } else {
            throw new IllegalArgumentException("Echipa cu ID-ul " + id + " nu exista!");
        }
    }

    public Echipa getTeamByName(String teamName) {
        for(Echipa team : echipaRepository.getAll()) {
            if(team.getNumeEchipa().equals(teamName)) {
                return team;
            }
        }
        return null;
    }
}
