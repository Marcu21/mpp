package org.example.bani.domain.dto;

import java.io.Serializable;
import java.util.List;

public class GameResultDTO implements Serializable {

    private Long gameId;
    private String alias;
    private int sumaFinala;
    private String startTime;
    private List<String> valori;
    private List<AttemptDTO> attempts;

    public GameResultDTO(Long gameId,
                         String alias,
                         int sumaFinala,
                         String startTime,
                         List<String> valori,
                         List<AttemptDTO> attempts) {
        this.gameId = gameId;
        this.alias = alias;
        this.sumaFinala = sumaFinala;
        this.startTime = startTime;
        this.valori = valori;
        this.attempts = attempts;
    }

    public Long getGameId() {
        return gameId;
    }

    public String getAlias() {
        return alias;
    }

    public int getSumaFinala() {
        return sumaFinala;
    }

    public List<String> getValori() {
        return valori;
    }

    public String getStartTime() {
        return startTime;
    }

    public List<AttemptDTO> getAttempts() {
        return attempts;
    }

    public static class AttemptDTO implements Serializable {
        private int diceRoll;
        private int position;
        private int modificareSuma;

        public AttemptDTO(int diceRoll, int position, int modificareSuma) {
            this.diceRoll = diceRoll;
            this.position = position;
            this.modificareSuma = modificareSuma;
        }

        public int getDiceRoll() {
            return diceRoll;
        }

        public int getPosition() {
            return position;
        }

        public int getModificareSuma() {
            return modificareSuma;
        }
    }
}

