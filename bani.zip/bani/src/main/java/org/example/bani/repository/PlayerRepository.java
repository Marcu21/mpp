package org.example.bani.repository;

import org.example.bani.domain.Player;

public interface PlayerRepository extends Repository<Player, Long> {
}