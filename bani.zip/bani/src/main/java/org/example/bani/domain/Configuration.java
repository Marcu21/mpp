package org.example.bani.domain;

import java.io.Serializable;

public class Configuration extends EntityID<Long> implements Serializable {

    private static final long serialVersionUID = 1L;

    private String valori;

    public Configuration() {
    }

    public Configuration(String valori) {
        this.valori = valori;
    }

    public Configuration(Long id, String valori) {
        setId(id);
        this.valori = valori;
    }

    public String getValori() {
        return valori;
    }

    public void setValori(String valori) {
        this.valori = valori;
    }
}