package org.example.bani.repository;

import org.example.bani.domain.GameAttempt;

public interface GameAttemptRepository extends Repository<GameAttempt, Long> {
}