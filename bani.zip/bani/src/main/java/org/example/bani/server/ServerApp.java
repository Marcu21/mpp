package org.example.bani.server;

import org.example.bani.networking.RequestHandler;
import org.example.bani.repository.ConfigurationRepository;
import org.example.bani.repository.GameAttemptRepository;
import org.example.bani.repository.GameRepository;
import org.example.bani.repository.PlayerRepository;
import org.example.bani.repository.db.*;
import org.example.bani.repository.hibernate.HibernateGameRepository;
import org.example.bani.repository.hibernate.HibernateGameRepository;
import org.example.bani.repository.hibernate.HibernatePlayerRepository;
import org.example.bani.service.GameService;
import org.example.bani.utils.HibernateUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    private static final int PORT = 5555;

    public static void main(String[] args) {
        PlayerRepository playerRepo   = new HibernatePlayerRepository(HibernateUtil.getSessionFactory());
        GameRepository gameRepo     = new HibernateGameRepository(HibernateUtil.getSessionFactory());
        GameAttemptRepository attemptRepo = new GameAttemptDBRepository();
        ConfigurationRepository configurationRepo     = new ConfigurationDBRepository();

        GameService service = new GameService(playerRepo, gameRepo, attemptRepo, configurationRepo);

        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket client = server.accept();
                new Thread(new RequestHandler(service, client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
