package org.example.bani.networking;

public interface IGameObserver {
    void scoreboardUpdated();
}