package org.example.bani.repository;

import org.example.bani.domain.Configuration;

public interface ConfigurationRepository extends Repository<Configuration, Long> {
}