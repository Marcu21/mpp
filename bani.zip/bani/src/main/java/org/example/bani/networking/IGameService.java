package org.example.bani.networking;

import org.example.bani.domain.Configuration;
import org.example.bani.domain.Game;
import org.example.bani.domain.GameAttempt;
import org.example.bani.domain.dto.GameResultDTO;

import java.util.List;

public interface IGameService {
    void addObserver(IGameObserver observer);
    void removeObserver(IGameObserver observer);

    Game startGame(String alias);
    String makeAttempt(Long gameId);

    List<GameResultDTO> getResultsForAllPlayers();
    List<GameResultDTO> getDetailedResultsForPlayer(String alias);
    List<GameAttempt> getAttemptsForGame(Long gameId);

    Game getGameById(Long gameId);
    Configuration getConfigurationById(Long configId);
}
