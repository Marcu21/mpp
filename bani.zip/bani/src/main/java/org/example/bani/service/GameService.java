package org.example.bani.service;

import org.example.cuvinte.domain.*;
import org.example.cuvinte.domain.dto.GameResultDTO;
import org.example.cuvinte.networking.IGameObserver;
import org.example.cuvinte.networking.IGameService;
import org.example.cuvinte.repository.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

public class GameService implements IGameService {

    private final PlayerRepository playerRepo;
    private final GameRepository gameRepo;
    private final GameAttemptRepository attemptRepo;
    private final ConfigurationRepository configurationRepo;
    private final List<IGameObserver> observers = new ArrayList<>();

    private final Random random = new Random();

    public GameService(PlayerRepository playerRepo,
                       GameRepository gameRepo,
                       GameAttemptRepository attemptRepo,
                       ConfigurationRepository configurationRepo) {
        this.playerRepo = playerRepo;
        this.gameRepo = gameRepo;
        this.attemptRepo = attemptRepo;
        this.configurationRepo = configurationRepo;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        observers.remove(observer);
    }

    @Override
    public Game startGame(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            player = new Player(null, alias);
            playerRepo.add(player);
        }

        List<Configuration> configurations = (List<Configuration>) configurationRepo.findAll();
        Random random = new Random();

        Configuration conf = configurations.get(random.nextInt(configurations.size()));

        Game game = new Game(player.getId(), conf.getId(), LocalDateTime.now());
        game.setScore(0);
        gameRepo.add(game);

        return game;
    }


    @Override
    public String makeAttempt(Long gameId, String word) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }

        String result = procesareCuvinte(game, word);

        if(getAttemptsForGame(gameId).size() == 4)
            game.setEndTime(LocalDateTime.now());

        gameRepo.update(game);

        StringBuilder response = new StringBuilder(result);

        if (game.getEndTime() != null) {
            notifyGameFinished();
            response.append("\nJoc finalizat! Punctaj total: ").append(game.getScore());
        }

        return response.toString();
    }

    private String procesareCuvinte(Game game, String word) {
        Configuration configuratie = configurationRepo.findById(game.getConfigurationId());

        List<String> cuvinteIncercate = new ArrayList<>();
        for(GameAttempt attempt: getAttemptsForGame(game.getId())) {
            cuvinteIncercate.add(attempt.getWord());
        }

        if (cuvinteIncercate.contains(word)) {
            return "Cuvantul a fost deja incercat.";
        }

        List<String> cuvinteCorecte = Arrays.asList(configuratie.getWords().split(","));

        if (cuvinteCorecte.contains(word)) {
            GameAttempt attempt = new GameAttempt(game.getId(), word, 1);
            attemptRepo.add(attempt);
            game.setScore(game.getScore() + word.length());
            return "Cuvant corect: " + word + "\n+ " + word.length() + " puncte";
        }
        else {
            int maxMatch = 0;
            for (String corect : cuvinteCorecte) {
                if (cuvinteIncercate.contains(corect)) continue;

                int match = 0;
                for (int i = 0; i < Math.min(word.length(), corect.length()); i++) {
                    if (word.charAt(i) == corect.charAt(i)) {
                        match++;
                    }
                }
                maxMatch = Math.max(maxMatch, match);
            }

            GameAttempt attempt = new GameAttempt(game.getId(), word, 0);
            attemptRepo.add(attempt);
            game.setScore(game.getScore() + maxMatch);

            return "Cuvant gresit: " + word +
                    "\n+ " + maxMatch + " puncte";
        }

    }


    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getEndTime() != null) {
                Player p = playerRepo.findById(g.getPlayerId());
                String[] configuration = configurationRepo.findById(g.getConfigurationId()).getWords().split(",");
                List<String> correctWords = Arrays.asList(configuration);
                results.add(new GameResultDTO(g.getId(), p.getAlias(), g.getScore(), g.getStartTime().toString(), correctWords, new ArrayList<>()));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Integer.compare(a.getCorrectWords().size(), b.getCorrectWords().size());
        });
        return results;
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            throw new RuntimeException("Jucatorul nu exista.");
        }

        List<GameResultDTO> results = new ArrayList<>();

        for (Game g : gameRepo.findAll()) {
            if (g.getPlayerId().equals(player.getId())
                    && g.getEndTime() != null) {


                List<GameResultDTO.PosDTO> attempts = new ArrayList<>();
                for (GameAttempt a : attemptRepo.findAll()) {
                    if (a.getGameId().equals(g.getId())) {
                        attempts.add(new GameResultDTO.PosDTO(a.getWord(), a.getCorrect()));
                    }
                }

                String[] configuration = configurationRepo.findById(g.getConfigurationId()).getWords().split(",");
                List<String> correctWords = Arrays.asList(configuration);
                GameResultDTO dto = new GameResultDTO(
                        g.getId(),
                        alias,
                        g.getScore(),
                        g.getStartTime().toString(),
                        correctWords,
                        attempts
                );
                results.add(dto);
            }
        }

        results.sort(Comparator.comparingLong(GameResultDTO::getScore).reversed());

        return results;
    }


    @Override
    public List<GameAttempt> getAttemptsForGame(Long gameId) {
        List<GameAttempt> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId)) {
                attempts.add(a);
            }
        }
        return attempts;
    }

    public GameResultDTO getResultsForGame(Long gameId) {
        Game game = gameRepo.findById(gameId);
        if (game == null) {
            throw new IllegalArgumentException("Jocul nu exista.");
        }

        long duration = Duration.between(game.getStartTime(), game.getEndTime()).getSeconds();
        List<GameResultDTO.PosDTO> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(game.getId())) {
                attempts.add(new GameResultDTO.PosDTO(a.getWord(), a.getCorrect()));
            }
        }
        String[] configuration = configurationRepo.findById(game.getConfigurationId()).getWords().split(",");
        List<String> correctWords = Arrays.asList(configuration);

        return new GameResultDTO(
                game.getId(),
                playerRepo.findById(game.getPlayerId()).getAlias(),
                game.getScore(),
                game.getStartTime().toString(),
                correctWords,
                attempts
        );
    }


    private void notifyGameFinished() {
        for (IGameObserver observer : observers) {
            try {
                observer.scoreboardUpdated();
            } catch (Exception e) {
                System.err.println("Eroare notificare: " + e.getMessage());
            }
        }
    }

    public Configuration addConfiguration(String letters, String words) {
        if (letters == null || letters.isEmpty() || words == null || words.isEmpty()) {
            throw new IllegalArgumentException("Configuratia nu poate fi goala.");
        }

        Configuration configuration = new Configuration(letters, words);
        configurationRepo.add(configuration);
        return configuration;
    }

    @Override
    public Game getGameById(Long gameId) {
        Game game = gameRepo.findById(gameId);
        if (game == null) {
            throw new IllegalArgumentException("Jocul nu exista.");
        }
        return game;
    }

    @Override
    public Configuration getConfigurationById(Long configId) {
        Configuration configuration = configurationRepo.findById(configId);
        if (configuration == null) {
            throw new IllegalArgumentException("Configuratia nu exista.");
        }
        return configuration;
    }

    public List<GameResultDTO> getResultsForPlayerMin2Guessed(String alias) {
        List<GameResultDTO> allResults = getDetailedResultsForPlayer(alias);
        List<GameResultDTO> filtered = new ArrayList<>();

        for (GameResultDTO dto : allResults) {
            int count = 0;
            List<String> uniqueGuessedWords = new ArrayList<>();

            for (GameResultDTO.PosDTO attempt : dto.getAttempts()) {
                if (attempt.getCorrect() == 1 && !uniqueGuessedWords.contains(attempt.getWord())) {
                    uniqueGuessedWords.add(attempt.getWord());
                    count++;
                }
            }

            if (count >= 2) {
                filtered.add(dto);
            }
        }

        return filtered;
    }


}
