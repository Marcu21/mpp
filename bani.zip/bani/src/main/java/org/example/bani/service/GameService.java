package org.example.bani.service;

import org.example.bani.domain.*;
import org.example.bani.domain.dto.GameResultDTO;
import org.example.bani.networking.IGameObserver;
import org.example.bani.networking.IGameService;
import org.example.bani.repository.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class GameService implements IGameService {

    private final PlayerRepository playerRepo;
    private final GameRepository gameRepo;
    private final GameAttemptRepository attemptRepo;
    private final ConfigurationRepository configurationRepo;
    private final List<IGameObserver> observers = new ArrayList<>();

    private final Random random = new Random();

    public GameService(PlayerRepository playerRepo,
                       GameRepository gameRepo,
                       GameAttemptRepository attemptRepo,
                       ConfigurationRepository configurationRepo) {
        this.playerRepo = playerRepo;
        this.gameRepo = gameRepo;
        this.attemptRepo = attemptRepo;
        this.configurationRepo = configurationRepo;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        observers.remove(observer);
    }

    @Override
    public Game startGame(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            player = new Player(null, alias);
            playerRepo.add(player);
        }

        List<Configuration> configurations = (List<Configuration>) configurationRepo.findAll();
        Random random = new Random();

        Configuration conf = configurations.get(random.nextInt(configurations.size()));

        Game game = new Game(player.getId(), conf.getId(), LocalDateTime.now());
        game.setSumaFinala(50);
        gameRepo.add(game);

        return game;
    }


    @Override
    public String makeAttempt(Long gameId) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }

        String result = procesareMutare(game);

        if(getAttemptsForGame(gameId).size() == 3)
            game.setEndTime(LocalDateTime.now());

        gameRepo.update(game);

        StringBuilder response = new StringBuilder(result);

        if (game.getEndTime() != null) {
            notifyGameFinished();
            response.append("\nJoc finalizat! Suma finala total: ").append(game.getSumaFinala());
        }

        return response.toString();
    }

    private String procesareMutare(Game game) {
        Configuration configuratie = configurationRepo.findById(game.getConfigurationId());

        List<Integer> valori = Arrays.stream(configuratie.getValori().split(","))
                .map(String::trim)
                .map(Integer::parseInt)
                .toList();

        List<GameAttempt> attempts = getAttemptsForGame(game.getId());

        int lastPosition = -1;
        for (GameAttempt a : attempts) {
            lastPosition = a.getPosition();
        }

        int diceRoll = new Random().nextInt(3) + 1;
        int newPosition = (lastPosition + diceRoll) % 5;

        boolean passedStart = (lastPosition + diceRoll) >= 5;
        boolean alreadyVisited = attempts.stream()
                .anyMatch(a -> a.getPosition() == newPosition);

        int sumaInitiala = game.getSumaFinala();

        StringBuilder mesaj = new StringBuilder("Ai dat cu zarul: ").append(diceRoll)
                .append("\nEsti la pozitia: ").append(newPosition + 1);

        if(passedStart)
        {
            game.setSumaFinala(game.getSumaFinala() + 5);
            mesaj.append("\nAi trecut de start!");
        }

        if(alreadyVisited)
        {
            mesaj.append("\nAi mai fost la aceasta pozitie");
        }
        else
        {
            int modificareSuma = valori.get(newPosition);
            game.setSumaFinala(game.getSumaFinala() - modificareSuma);
            mesaj.append("\nPozitie noua: - ").append(modificareSuma).append(" lei");
        }

        GameAttempt attempt = new GameAttempt(game.getId(), diceRoll, newPosition, game.getSumaFinala() - sumaInitiala);
        attemptRepo.add(attempt);
        mesaj.append("\nSuma actuala: ").append(game.getSumaFinala()).append(" lei");

        return mesaj.toString();
    }


    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getEndTime() != null) {
                Player p = playerRepo.findById(g.getPlayerId());
                String[] configuration = configurationRepo.findById(g.getConfigurationId()).getValori().split(",");
                List<String> valori = Arrays.asList(configuration);
                results.add(new GameResultDTO(g.getId(), p.getAlias(), g.getSumaFinala(), g.getStartTime().toString(), valori, new ArrayList<>()));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getSumaFinala(), a.getSumaFinala());
            return cmp != 0 ? cmp : a.getStartTime().compareTo(b.getStartTime());
        });
        return results;
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            throw new RuntimeException("Jucatorul nu exista.");
        }

        List<GameResultDTO> results = new ArrayList<>();

        for (Game g : gameRepo.findAll()) {
            if (g.getPlayerId().equals(player.getId())
                    && g.getEndTime() != null) {


                List<GameResultDTO.AttemptDTO> attempts = new ArrayList<>();
                for (GameAttempt a : attemptRepo.findAll()) {
                    if (a.getGameId().equals(g.getId())) {
                        attempts.add(new GameResultDTO.AttemptDTO(a.getDiceRoll(), a.getPosition(), a.getModificareSuma()));
                    }
                }

                String[] configuration = configurationRepo.findById(g.getConfigurationId()).getValori().split(",");
                List<String> valori = Arrays.asList(configuration);
                GameResultDTO dto = new GameResultDTO(
                        g.getId(),
                        alias,
                        g.getSumaFinala(),
                        g.getStartTime().toString(),
                        valori,
                        attempts
                );
                results.add(dto);
            }
        }

        results.sort(Comparator.comparingLong(GameResultDTO::getSumaFinala).reversed());

        return results;
    }


    @Override
    public List<GameAttempt> getAttemptsForGame(Long gameId) {
        List<GameAttempt> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId)) {
                attempts.add(a);
            }
        }
        return attempts;
    }

    public GameResultDTO getResultsForGame(Long gameId) {
        Game game = gameRepo.findById(gameId);
        if (game == null) {
            throw new IllegalArgumentException("Jocul nu exista.");
        }

        List<GameResultDTO.AttemptDTO> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(game.getId())) {
                attempts.add(new GameResultDTO.AttemptDTO(a.getDiceRoll(), a.getPosition(), a.getModificareSuma()));
            }
        }
        String[] configuration = configurationRepo.findById(game.getConfigurationId()).getValori().split(",");
        List<String> valori = Arrays.asList(configuration);

        return new GameResultDTO(
                game.getId(),
                playerRepo.findById(game.getPlayerId()).getAlias(),
                game.getSumaFinala(),
                game.getStartTime().toString(),
                valori,
                attempts
        );
    }


    private void notifyGameFinished() {
        for (IGameObserver observer : observers) {
            try {
                observer.scoreboardUpdated();
            } catch (Exception e) {
                System.err.println("Eroare notificare: " + e.getMessage());
            }
        }
    }

    public Configuration addConfiguration(String valori) {
        if (valori == null || valori.isEmpty()) {
            throw new IllegalArgumentException("Configuratia nu poate fi goala.");
        }

        Configuration configuration = new Configuration(valori);
        configurationRepo.add(configuration);
        return configuration;
    }

    @Override
    public Game getGameById(Long gameId) {
        Game game = gameRepo.findById(gameId);
        if (game == null) {
            throw new IllegalArgumentException("Jocul nu exista.");
        }
        return game;
    }

    @Override
    public Configuration getConfigurationById(Long configId) {
        Configuration configuration = configurationRepo.findById(configId);
        if (configuration == null) {
            throw new IllegalArgumentException("Configuratia nu exista.");
        }
        return configuration;
    }

}
