package org.example.bani.repository.hibernate;

import org.example.bani.domain.Player;
import org.example.bani.repository.PlayerRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.Collection;

public class HibernatePlayerRepository implements PlayerRepository {

    private final SessionFactory sessionFactory;

    public HibernatePlayerRepository(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void add(Player player) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.persist(player);
            tran.commit();
        }
    }

    @Override
    public Iterable<Player> findAll() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("from Player", Player.class).list();
        }
    }

    @Override
    public Player findById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Player.class, id);
        }
    }

    @Override
    public void update(Player player) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.merge(player);
            tran.commit();
        }
    }

    @Override
    public void delete(Player player) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.remove(session.contains(player) ? player : session.merge(player));
            tran.commit();
        }
    }

    @Override
    public Collection<Player> getAll() {
        return (Collection<Player>) findAll();
    }
}
