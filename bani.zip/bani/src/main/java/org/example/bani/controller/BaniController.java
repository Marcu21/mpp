package org.example.bani.controller;

import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.bani.domain.Configuration;
import org.example.bani.domain.Game;
import org.example.bani.domain.dto.GameResultDTO;
import org.example.bani.networking.GameServiceProxy;
import org.example.bani.networking.IGameObserver;

import java.util.List;

public class BaniController implements IGameObserver {

    @FXML
    private TextField aliasField;
    @FXML private TextArea messageArea;

    @FXML private TableView<GameResultDTO> leaderboardTable;
    @FXML private TableColumn<GameResultDTO, String> colAlias;
    @FXML private TableColumn<GameResultDTO, Integer> colSuma;
    @FXML private TableColumn<GameResultDTO, String> colStart;

    private final GameServiceProxy service = new GameServiceProxy("localhost", 5555);

    private Long currentGameId = null;
    private String currentAlias = null;
    @FXML private Label configLabel;
    @FXML private Label sumaLabel;
    @FXML private Button attemptButton;



    @FXML
    public void initialize() {
        initLeaderboardTable();
    }

    private void initLeaderboardTable() {
        colAlias.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAlias()));
        colSuma.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getSumaFinala()));
        colStart.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStartTime()));
    }

    private void updateConfigLetters(String letters) {
        configLabel.setText(letters);
    }

    private void updateSumaLabel(int suma) {
        sumaLabel.setText(suma + " lei");
    }

    @FXML
    public void handleStartGame() {
        int ok = 1;
        if (currentAlias != null)
        {
            ok = 0;
        }
        currentAlias = aliasField.getText().trim();
        if (currentAlias.isEmpty()) {
            messageArea.setText("Introdu un alias valid.");
            return;
        }

        try {
            if(ok == 1) {
                service.addObserver(this);
            }

            Game game = service.startGame(currentAlias);
            this.currentGameId = game.getId();
            Configuration config = service.getConfigurationById(game.getConfigurationId());
            if (config == null) {
                messageArea.setText("Configuratia jocului nu a fost gasita.");
                return;
            }
            String[] valori = config.getValori().split(",");
            updateConfigLetters(String.join(", ", valori));
            updateSumaLabel(game.getSumaFinala());
            attemptButton.setDisable(false);
            messageArea.setText("Joc pornit!");

            updateLeaderboard();
        } catch (Exception e) {
            messageArea.setText("Eroare la pornirea jocului: " + e.getMessage());
        }
    }

    @FXML
    private void handleAttempt() {
        if (currentGameId == null) {
            messageArea.setText("Mai intai porneste un joc.");
            return;
        }
        Game game = service.getGameById(currentGameId);
        if (game == null) {
            messageArea.setText("Jocul nu exista");
            return;
        }

        try {
            String rezultat = service.makeAttempt(currentGameId);
            messageArea.setText(rezultat);
            game = service.getGameById(currentGameId);
            updateSumaLabel(game.getSumaFinala());
            if (rezultat.contains("Joc finalizat")) {
                currentGameId = null;
                attemptButton.setDisable(true);
                updateLeaderboard();
            }

        } catch (Exception e) {
            messageArea.setText("Eroare la mutare: " + e.getMessage());
        }
    }

    private void updateLeaderboard() {
        try {
            List<GameResultDTO> results = service.getResultsForAllPlayers();
            leaderboardTable.getItems().setAll(results);
        } catch (Exception e) {
            messageArea.setText("Eroare la actualizarea clasamentului: " + e.getMessage());
        }
    }

    @Override
    public void scoreboardUpdated() {
        Platform.runLater(this::updateLeaderboard);
    }

    public void handleDisconnect() {
        try {
            service.removeObserver(this);
            messageArea.setText("Deconectare reusita.");
        } catch (Exception e) {
            messageArea.setText("Eroare la deconectare: " + e.getMessage());
        }
    }


}