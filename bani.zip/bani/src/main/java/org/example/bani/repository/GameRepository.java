package org.example.bani.repository;

import org.example.bani.domain.Game;

public interface GameRepository extends Repository<Game, Long> {
}
