package org.example.bani.domain;

import java.io.Serializable;

public class GameAttempt extends EntityID<Long> implements Serializable {

    private Long id;
    private Long gameId;
    private int diceRoll;
    private int position;
    private int modificareSuma;

    public GameAttempt() {}

    public GameAttempt(Long id, Long gameId, int position, int modificareSuma) {
        setId(id);
        this.gameId = gameId;
        this.position = position;
        this.modificareSuma = modificareSuma;
    }

    public GameAttempt(Long gameId, int position, int modificareSuma) {
        this.gameId = gameId;
        this.position = position;
        this.modificareSuma = modificareSuma;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public int getModificareSuma() {
        return modificareSuma;
    }

    public void setModificareSuma(int modificareSuma) {
        this.modificareSuma = modificareSuma;
    }
}
