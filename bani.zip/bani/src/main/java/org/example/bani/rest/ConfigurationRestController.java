package org.example.bani.rest;

import org.example.cuvinte.domain.Configuration;
import org.example.cuvinte.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/configurations")
public class ConfigurationRestController {

    private final GameService gameService;

    public ConfigurationRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @PostMapping
    public ResponseEntity<Configuration> addGameConfiguration(@RequestBody Configuration request) {
        try {
            Configuration saved = gameService.addConfiguration(request.getLetters(), request.getWords());
            return new ResponseEntity<>(saved, HttpStatus.CREATED);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}