package org.example.bani.repository.db;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.cuvinte.domain.Configuration;
import org.example.cuvinte.repository.ConfigurationRepository;
import org.example.cuvinte.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ConfigurationDBRepository implements ConfigurationRepository {
    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public ConfigurationDBRepository() {
        logger.info("Initializing WordDBRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(Configuration configuration) {
        logger.traceEntry("Saving configuration {}", configuration);
        String sql = "INSERT INTO Configuration (letters, words) VALUES (?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, configuration.getLetters());
            stmt.setString(2, configuration.getWords());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    configuration.setId(keys.getLong(1));
                }
            }
            logger.trace("Saved {}", configuration);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<Configuration> findAll() {
        logger.traceEntry();
        List<Configuration> configurations = new ArrayList<>();
        String sql = "SELECT * FROM Configuration";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Long id = rs.getLong("id");
                String letters = rs.getString("letters");
                String words = rs.getString("words");
                Configuration c = new Configuration(id, letters, words);
                configurations.add(c);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit(configurations);
        return configurations;
    }

    @Override
    public void delete(Configuration configuration) {
        logger.traceEntry("Deleting configuration {}", configuration);
        String sql = "DELETE FROM Configuration WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, configuration.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", configuration);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public void update(Configuration configuration) {
        logger.traceEntry("Updating configuration {}", configuration);
        String sql = "UPDATE Configuration SET letters=?, words=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, configuration.getLetters());
            stmt.setString(2, configuration.getWords());
            stmt.setLong(3, configuration.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", configuration);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public Configuration findById(Long id) {
        logger.traceEntry("Finding configuration by id {}", id);
        String sql = "SELECT * FROM Configuration WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String letters = rs.getString("letters");
                    String words = rs.getString("words");
                    Configuration c = new Configuration(id, letters, words);
                    logger.traceExit(c);
                    return c;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Configuration> getAll() {
        return (Collection<Configuration>) findAll();
    }
}