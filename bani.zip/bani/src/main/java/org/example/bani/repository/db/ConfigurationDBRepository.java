package org.example.bani.repository.db;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.bani.domain.Configuration;
import org.example.bani.repository.ConfigurationRepository;
import org.example.bani.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ConfigurationDBRepository implements ConfigurationRepository {
    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public ConfigurationDBRepository() {
        logger.info("Initializing ConfigurationDBRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(Configuration configuration) {
        logger.traceEntry("Saving configuration {}", configuration);
        String sql = "INSERT INTO Configuration (valori) VALUES (?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, configuration.getValori());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    configuration.setId(keys.getLong(1));
                }
            }
            logger.trace("Saved {}", configuration);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<Configuration> findAll() {
        logger.traceEntry();
        List<Configuration> configurations = new ArrayList<>();
        String sql = "SELECT * FROM Configuration";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Long id = rs.getLong("id");
                String valori = rs.getString("valori");
                Configuration c = new Configuration(id, valori);
                configurations.add(c);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit(configurations);
        return configurations;
    }

    @Override
    public void delete(Configuration configuration) {
        logger.traceEntry("Deleting configuration {}", configuration);
        String sql = "DELETE FROM Configuration WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, configuration.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", configuration);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public void update(Configuration configuration) {
        logger.traceEntry("Updating configuration {}", configuration);
        String sql = "UPDATE Configuration SET valori=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, configuration.getValori());
            stmt.setLong(2, configuration.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", configuration);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public Configuration findById(Long id) {
        logger.traceEntry("Finding configuration by id {}", id);
        String sql = "SELECT * FROM Configuration WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String valori = rs.getString("valori");
                    Configuration c = new Configuration(id, valori);
                    logger.traceExit(c);
                    return c;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Configuration> getAll() {
        return (Collection<Configuration>) findAll();
    }
}