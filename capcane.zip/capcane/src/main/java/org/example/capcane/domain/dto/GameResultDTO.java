package org.example.capcane.domain.dto;

import java.io.Serializable;
import java.util.List;

public class GameResultDTO implements Serializable {

    private Long gameId;
    private String alias;
    private int score;
    private long durationSeconds;

    private List<PosDTO> holes;
    private List<PosDTO> attempts;

    public GameResultDTO(Long gameId,
                         String alias,
                         int score,
                         long duration,
                         List<PosDTO> holes,
                         List<PosDTO> attempts) {
        this.gameId = gameId;
        this.alias = alias;
        this.score = score;
        this.durationSeconds = duration;
        this.holes = holes;
        this.attempts = attempts;
    }

    public Long getGameId() { return gameId; }
    public String getAlias() { return alias; }
    public int getScore() { return score; }
    public long getDurationSeconds() { return durationSeconds; }
    public List<PosDTO> getHoles() { return holes; }
    public List<PosDTO> getAttempts() { return attempts; }

    public static class PosDTO implements Serializable {
        private int row;
        private int col;

        public PosDTO(int row, int col) {
            this.row = row;
            this.col = col;
        }
        public int getRow() { return row; }
        public int getCol() { return col; }
    }
}
