package org.example.capcane;

public class MainApp {
    public static void main(String[] args) {
        HelloApplication.main(args);
    }
}
