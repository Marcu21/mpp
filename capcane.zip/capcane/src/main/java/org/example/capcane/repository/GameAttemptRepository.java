package org.example.capcane.repository;

import org.example.capcane.domain.GameAttempt;

public interface GameAttemptRepository extends Repository<GameAttempt, Long> {
}