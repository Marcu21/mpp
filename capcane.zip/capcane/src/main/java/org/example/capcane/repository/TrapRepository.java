package org.example.capcane.repository;

import org.example.capcane.domain.Trap;

public interface TrapRepository extends Repository<Trap, Long>{
}
