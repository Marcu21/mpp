package org.example.capcane.domain;

import java.io.Serializable;

public class Trap extends EntityID<Long> implements Serializable {

    private Long id;
    private Long gameId;
    private int row;
    private int col;

    public Trap() {}

    public Trap(Long id, Long gameId, int row, int col) {
        setId(id);
        this.gameId = gameId;
        this.row = row;
        this.col = col;
    }

    public Trap(Long gameId, int row, int col) {
        this.gameId = gameId;
        this.row = row;
        this.col = col;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    @Override
    public String toString() {
        return "Trap{" +
                "id=" + id +
                ", gameId=" + gameId +
                ", row=" + row +
                ", col=" + col +
                '}';
    }
}
