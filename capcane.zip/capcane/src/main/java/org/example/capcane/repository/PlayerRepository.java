package org.example.capcane.repository;

import org.example.capcane.domain.Player;

public interface PlayerRepository extends Repository<Player, Long> {
}