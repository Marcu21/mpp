package org.example.capcane.repository;

import org.example.capcane.domain.Game;

public interface GameRepository extends Repository<Game, Long> {
}
