package org.example.capcane.service;

import org.example.capcane.domain.*;
import org.example.capcane.domain.dto.GameResultDTO;
import org.example.capcane.networking.IGameObserver;
import org.example.capcane.networking.IGameService;
import org.example.capcane.repository.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GameService implements IGameService {

    private final PlayerRepository playerRepo;
    private final GameRepository gameRepo;
    private final GameAttemptRepository attemptRepo;
    private final TrapRepository trapRepo;
    private final List<IGameObserver> observers = new ArrayList<>();

    private final Random random = new Random();

    public GameService(PlayerRepository playerRepo,
                       GameRepository gameRepo,
                       GameAttemptRepository attemptRepo,
                       TrapRepository trapRepo) {
        this.playerRepo = playerRepo;
        this.gameRepo = gameRepo;
        this.attemptRepo = attemptRepo;
        this.trapRepo = trapRepo;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        observers.remove(observer);
    }

    @Override
    public Game startGame(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            player = new Player(null, alias);
            playerRepo.add(player);
        }

        Game game = new Game(player.getId(), LocalDateTime.now());
        gameRepo.add(game);

        Set<String> existingPositions = new HashSet<>();

        for (int col = 1; col <= 5; col++) {
            int row;
            String key;
            do {
                row = random.nextInt(5) + 1;
                key = row + "," + col;
            } while (existingPositions.contains(key));

            trapRepo.add(new Trap(game.getId(), row, col));
            existingPositions.add(key);
        }

        int extraCol = random.nextInt(5) + 1;
        while (true) {
            int row = random.nextInt(5) + 1;
            String key = row + "," + extraCol;
            if (!existingPositions.contains(key)) {
                trapRepo.add(new Trap(game.getId(), row, extraCol));
                break;
            }
        }

        return game;
    }

    @Override
    public String makeAttempt(Long gameId, int row, int col) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }

        int expectedCol = getAttemptsForGame(gameId).size() + 1;
        if (col != expectedCol) {
            return "Trebuie sa alegi o pozitie de pe coloana " + expectedCol + "!";
        }

        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId) && a.getRow() == row && a.getCol() == col) {
                return "Pozitia este deja ocupata!";
            }
        }

        GameAttempt attempt = new GameAttempt(gameId, row, col);
        attemptRepo.add(attempt);

        String result = procesareCapcane(game, row, col);

        gameRepo.update(game);
        if (game.getEndTime() != null) {
            notifyGameFinished();
        }

        return result;
    }


    private String procesareCapcane(Game game, int row, int col) {
        if (isTrapAtPosition(game.getId(), row, col)) {
            game.setEndTime(LocalDateTime.now());
            return buildEndMessage("Ai cazut in capcana. Punctaj: " + game.getScore(), game.getId());
        }

        game.setScore(game.getScore() + 2 * col);

        if (col == 5) {
            game.setEndTime(LocalDateTime.now());
            return buildEndMessage("Ai castigat! Punctaj: " + game.getScore(), game.getId());
        }

        return "Pas corect. Continua la coloana urmatoare.";
    }

    private boolean isTrapAtPosition(Long gameId, int row, int col) {
        for (Trap h : trapRepo.findAll()) {
            if (h.getGameId().equals(gameId) && h.getRow() == row && h.getCol() == col) {
                return true;
            }
        }
        return false;
    }

    private String buildEndMessage(String baseMessage, Long gameId) {
        StringBuilder sb = new StringBuilder(baseMessage);
        sb.append("\nCapcanele au fost la: ");
        for (Trap t : trapRepo.findAll()) {
            if (t.getGameId().equals(gameId)) {
                sb.append("(").append(t.getRow()).append(",").append(t.getCol()).append(") ");
            }
        }
        return sb.toString();
    }







/*    @Override
    public String makeAttempt(Long gameId, int row, int col) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }

        int expectedRow = getAttemptsForGame(gameId).size() + 1;
        if (row != expectedRow) {
            return "Trebuie sa alegi o pozitie de pe linia " + expectedRow + "!";
        }

        GameAttempt attempt = new GameAttempt(gameId, LocalDateTime.now(), row, col);
        attemptRepo.add(attempt);

        boolean isHole = false;
        for (Hole h : holeRepo.findAll()) {
            if (h.getGameId().equals(gameId) && h.getRow() == row && h.getCol() == col) {
                isHole = true;
                break;
            }
        }

        if (isHole) {
            game.setEndTime(LocalDateTime.now());
            gameRepo.update(game);
            notifyGameFinished();

            StringBuilder holesMsg = new StringBuilder("Ai cazut in groapa. Joc terminat.\nGropile au fost la: ");
            for (Hole h : holeRepo.findAll()) {
                if (h.getGameId().equals(gameId)) {
                    holesMsg.append("(").append(h.getRow()).append(",").append(h.getCol()).append(") ");
                }
            }

            return holesMsg.toString();
        }


        game.setScore(game.getScore() + row);

        if (row == 4) {
            game.setEndTime(LocalDateTime.now());
            gameRepo.update(game);
            notifyGameFinished();

            StringBuilder holesMsg = new StringBuilder("Ai castigat! Felicitari!\nGropile au fost la: ");
            for (Hole h : holeRepo.findAll()) {
                if (h.getGameId().equals(gameId)) {
                    holesMsg.append("(").append(h.getRow()).append(",").append(h.getCol()).append(") ");
                }
            }

            return holesMsg.toString();
        }


        gameRepo.update(game);
        return "Pas corect. Continua la linia urmatoare.";
    }*/

    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getEndTime() != null) {
                Player p = playerRepo.findById(g.getPlayerId());
                Duration d = Duration.between(g.getStartTime(), g.getEndTime());
                results.add(new GameResultDTO(g.getId(), p.getAlias(), g.getScore(), d.getSeconds(), new ArrayList<>(), new ArrayList<>()));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Long.compare(a.getDurationSeconds(), b.getDurationSeconds());
        });
        return results;
    }

    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) throw new RuntimeException("Jucator inexistent.");

        List<GameResultDTO> results = new ArrayList<>();
        for (Game g : gameRepo.findAll()) {
            if (g.getPlayerId().equals(player.getId()) && g.getEndTime() != null) {
                Duration d = Duration.between(g.getStartTime(), g.getEndTime());

                List<GameResultDTO.PosDTO> traps = new ArrayList<>();
                for (Trap t : trapRepo.findAll()) {
                    if (t.getGameId().equals(g.getId())) {
                        traps.add(new GameResultDTO.PosDTO(t.getRow(), t.getCol()));
                    }
                }

                List<GameResultDTO.PosDTO> attempts = new ArrayList<>();
                for (GameAttempt a : attemptRepo.findAll()) {
                    if (a.getGameId().equals(g.getId())) {
                        attempts.add(new GameResultDTO.PosDTO(a.getRow(), a.getCol()));
                    }
                }

                results.add(new GameResultDTO(g.getId(), alias, g.getScore(), d.getSeconds(), traps, attempts));
            }
        }
        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Long.compare(a.getDurationSeconds(), b.getDurationSeconds());
        });
        return results;
    }

    @Override
    public List<GameAttempt> getAttemptsForGame(Long gameId) {
        List<GameAttempt> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId)) {
                attempts.add(a);
            }
        }
        return attempts;
    }

    @Override
    public List<Trap> getTrapsForGame(Long gameId) {
        List<Trap> traps = new ArrayList<>();
        for (Trap t : trapRepo.findAll()) {
            if (t.getGameId().equals(gameId)) {
                traps.add(t);
            }
        }
        return traps;
    }

    private void notifyGameFinished() {
        for (IGameObserver observer : observers) {
            try {
                observer.scoreboardUpdated();
            } catch (Exception e) {
                System.err.println("Eroare notificare: " + e.getMessage());
            }
        }
    }

    public Trap modifyTrap(long gameId, int row, int col, int newRow, int newCol) {
        Game game = gameRepo.findById(gameId);
        if (game == null) {
            throw new RuntimeException("Jocul nu exista");
        }
        Trap trap = null;
        for (Trap t : trapRepo.findAll()) {
            if (t.getGameId().equals(gameId) && t.getRow() == row && t.getCol() == col) {
                trap = t;
                break;
            }
        }

        if (trap == null) {
            throw new RuntimeException("Capcana nu exista la pozitia specificata");
        }

        //daca e out of bound atunci stergem trapul
        if (newRow < 1 || newRow > 5 || newCol < 1 || newCol > 5)
        {
            trapRepo.delete(trap);
            return null;
        }
        else
        {
            trap.setRow(newRow);
            trap.setCol(newCol);
            trapRepo.update(trap);
            return trap;
        }

    }

}
