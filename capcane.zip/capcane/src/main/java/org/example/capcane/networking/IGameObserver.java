package org.example.capcane.networking;

public interface IGameObserver {
    void scoreboardUpdated();
}