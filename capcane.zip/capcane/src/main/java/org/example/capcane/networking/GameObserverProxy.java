package org.example.capcane.networking;

import org.example.capcane.networking.IGameObserver;

import java.io.ObjectOutputStream;

public class GameObserverProxy implements IGameObserver {
    private final ObjectOutputStream output;

    public GameObserverProxy(ObjectOutputStream output) {
        this.output = output;
    }

    @Override
    public void scoreboardUpdated() {
        try {
            synchronized (output) {
                output.writeObject(new Response("scoreboardUpdated", null));
                output.flush();
            }
        } catch (Exception e) {
            System.out.println("[Server] Push failed: " + e.getMessage());
        }
    }
}
