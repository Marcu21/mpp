package org.example.capcane.repository.db;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.capcane.domain.Trap;
import org.example.capcane.repository.TrapRepository;
import org.example.capcane.utils.JdbcUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class TrapDBRepository implements TrapRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public TrapDBRepository() {
        logger.info("Initializing TrapDBRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(Trap trap) {
        logger.traceEntry("Saving trap {}", trap);
        String sql = "INSERT INTO Trap (game_id, row, col) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setLong(1, trap.getGameId());
            stmt.setInt(2, trap.getRow());
            stmt.setInt(3, trap.getCol());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    trap.setId(keys.getLong(1));
                }
            }

            logger.trace("Saved {}", trap);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }

        logger.traceExit();
    }

    @Override
    public Iterable<Trap> findAll() {
        logger.traceEntry();
        List<Trap> traps = new ArrayList<>();
        String sql = "SELECT * FROM Trap";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Trap trap = extractTrap(rs);
                traps.add(trap);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(traps);
        return traps;
    }

    @Override
    public void delete(Trap trap) {
        logger.traceEntry("Deleting trap {}", trap);
        String sql = "DELETE FROM Trap WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, trap.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", trap);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public void update(Trap trap) {
        logger.traceEntry("Updating hole {}", trap);
        String sql = "UPDATE Trap SET game_id=?, row=?, col=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, trap.getGameId());
            stmt.setInt(2, trap.getRow());
            stmt.setInt(3, trap.getCol());
            stmt.setLong(4, trap.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", trap);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public Trap findById(Long id) {
        logger.traceEntry("Finding hole by id {}", id);
        String sql = "SELECT * FROM Trap WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Trap trap = extractTrap(rs);
                    logger.traceExit(trap);
                    return trap;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Trap> getAll() {
        return (Collection<Trap>) findAll();
    }

    private Trap extractTrap(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        Long gameId = rs.getLong("game_id");
        int row = rs.getInt("row");
        int col = rs.getInt("col");
        return new Trap(id, gameId, row, col);
    }
}
