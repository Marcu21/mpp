package org.example.capcane.server;

import org.example.capcane.networking.RequestHandler;
import org.example.capcane.repository.GameAttemptRepository;
import org.example.capcane.repository.GameRepository;
import org.example.capcane.repository.TrapRepository;
import org.example.capcane.repository.PlayerRepository;
import org.example.capcane.repository.db.*;
import org.example.capcane.repository.db.PlayerDBRepository;
import org.example.capcane.repository.hibernate.HibernateGameRepository;
import org.example.capcane.service.GameService;
import org.example.capcane.utils.HibernateUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    private static final int PORT = 5555;

    public static void main(String[] args) {
        PlayerRepository playerRepo   = new PlayerDBRepository();
        TrapRepository trapRepo     = new TrapDBRepository();
        GameRepository gameRepo     = new HibernateGameRepository(HibernateUtil.getSessionFactory());
        GameAttemptRepository attemptRepo = new GameAttemptDBRepository();

        GameService service = new GameService(playerRepo, gameRepo, attemptRepo, trapRepo);

        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket client = server.accept();
                new Thread(new RequestHandler(service, client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
