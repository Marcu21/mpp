package org.example.capcane.utils;

import org.example.capcane.repository.*;
import org.example.capcane.repository.db.GameAttemptDBRepository;
import org.example.capcane.repository.db.TrapDBRepository;
import org.example.capcane.repository.db.PlayerDBRepository;
import org.example.capcane.repository.hibernate.HibernateGameRepository;
import org.example.capcane.service.GameService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public PlayerRepository playerRepository() {
        return new PlayerDBRepository();
    }

    @Bean
    public TrapRepository trapRepository() {
        return new TrapDBRepository();
    }

    @Bean
    public GameAttemptRepository gameAttemptRepository() {
        return new GameAttemptDBRepository();
    }

    @Bean
    public GameRepository gameRepository() {
        return new HibernateGameRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public GameService gameService() {
        return new GameService(
                playerRepository(),
                gameRepository(),
                gameAttemptRepository(),
                trapRepository()
        );
    }
}
