package org.example.capcane.repository.db;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.capcane.domain.GameAttempt;
import org.example.capcane.repository.GameAttemptRepository;
import org.example.capcane.utils.JdbcUtils;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class GameAttemptDBRepository implements GameAttemptRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public GameAttemptDBRepository() {
        logger.info("Initializing GameAttemptDBRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(GameAttempt attempt) {
        logger.traceEntry("Saving game attempt {}", attempt);
        String sql = "INSERT INTO GameAttempt (game_id, row, col) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setLong(1, attempt.getGameId());
            stmt.setInt(2, attempt.getRow());
            stmt.setInt(3, attempt.getCol());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    attempt.setId(keys.getLong(1));
                }
            }

            logger.trace("Saved {}", attempt);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<GameAttempt> findAll() {
        logger.traceEntry();
        List<GameAttempt> attempts = new ArrayList<>();
        String sql = "SELECT * FROM GameAttempt";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                GameAttempt attempt = extractAttempt(rs);
                attempts.add(attempt);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(attempts);
        return attempts;
    }

    @Override
    public void delete(GameAttempt attempt) {
        logger.traceEntry("Deleting game attempt {}", attempt);
        String sql = "DELETE FROM GameAttempt WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, attempt.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", attempt);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public void update(GameAttempt attempt) {
        logger.traceEntry("Updating game attempt {}", attempt);
        String sql = "UPDATE GameAttempt SET game_id=?, row=?, col=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, attempt.getGameId());
            stmt.setInt(2, attempt.getRow());
            stmt.setInt(3, attempt.getCol());
            stmt.setLong(4, attempt.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", attempt);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public GameAttempt findById(Long id) {
        logger.traceEntry("Finding game attempt by id {}", id);
        String sql = "SELECT * FROM GameAttempt WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    GameAttempt attempt = extractAttempt(rs);
                    logger.traceExit(attempt);
                    return attempt;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<GameAttempt> getAll() {
        return (Collection<GameAttempt>) findAll();
    }

    private GameAttempt extractAttempt(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        Long gameId = rs.getLong("game_id");
        int row = rs.getInt("row");
        int col = rs.getInt("col");
        return new GameAttempt(id, gameId, row, col);
    }
}
