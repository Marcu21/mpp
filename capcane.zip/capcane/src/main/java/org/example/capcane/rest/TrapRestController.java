package org.example.capcane.rest;

import org.example.capcane.domain.Trap;
import org.example.capcane.domain.dto.RestDTO;
import org.example.capcane.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/traps")
public class TrapRestController {

    private final GameService gameService;

    public TrapRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @PutMapping
    public ResponseEntity<Trap> modifyConfiguration(@RequestBody RestDTO request) {
        try {
            Trap saved = gameService.modifyTrap(request.getGameId(), request.getOldRow(), request.getOldCol(), request.getNewRow(), request.getNewCol());
            return new ResponseEntity<>(saved, HttpStatus.CREATED);
        } catch (Exception ex) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
