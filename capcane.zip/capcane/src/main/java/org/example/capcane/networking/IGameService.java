package org.example.capcane.networking;

import org.example.capcane.domain.Game;
import org.example.capcane.domain.GameAttempt;
import org.example.capcane.domain.Trap;
import org.example.capcane.domain.dto.GameResultDTO;

import java.util.List;

public interface IGameService {
    void addObserver(IGameObserver observer);
    void removeObserver(IGameObserver observer);

    Game startGame(String alias);
    String makeAttempt(Long gameId, int row, int col);

    List<GameResultDTO> getResultsForAllPlayers();
    List<GameResultDTO> getDetailedResultsForPlayer(String alias);
    List<GameAttempt> getAttemptsForGame(Long gameId);
    List<Trap> getTrapsForGame(Long gameId);
}
