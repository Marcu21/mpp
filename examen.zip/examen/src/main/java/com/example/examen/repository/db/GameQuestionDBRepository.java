package com.example.examen.repository.db;

import com.example.examen.domain.GameQuestion;
import com.example.examen.repository.GameQuestionRepository;
import com.example.examen.utils.JdbcUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class GameQuestionDBRepository implements GameQuestionRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public GameQuestionDBRepository() {
        logger.info("Initializing GameQuestionDBRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(GameQuestion gameQuestion) {
        logger.traceEntry("Saving game question {}", gameQuestion);
        String sql = "INSERT INTO GameQuestion (game_id, question_id) VALUES (?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setLong(1, gameQuestion.getGameId());
            stmt.setLong(2, gameQuestion.getQuestionId());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    gameQuestion.setId(keys.getLong(1));
                }
            }

            logger.trace("Saved {}", gameQuestion);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<GameQuestion> findAll() {
        logger.traceEntry();
        List<GameQuestion> result = new ArrayList<>();
        String sql = "SELECT * FROM GameQuestion";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                GameQuestion gameQuestion = extractGameQuestion(rs);
                result.add(gameQuestion);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(result);
        return result;
    }

    @Override
    public void delete(GameQuestion gameQuestion) {
        logger.traceEntry("Deleting game question {}", gameQuestion);
        String sql = "DELETE FROM GameQuestion WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, gameQuestion.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", gameQuestion);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public void update(GameQuestion gameQuestion) {
        logger.traceEntry("Updating game question {}", gameQuestion);
        String sql = "UPDATE GameQuestion SET game_id=?, question_id=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, gameQuestion.getGameId());
            stmt.setLong(2, gameQuestion.getQuestionId());
            stmt.setLong(3, gameQuestion.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", gameQuestion);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }
        logger.traceExit();
    }

    @Override
    public GameQuestion findById(Long id) {
        logger.traceEntry("Finding game question by id {}", id);
        String sql = "SELECT * FROM GameQuestion WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    GameQuestion gameQuestion = extractGameQuestion(rs);
                    logger.traceExit(gameQuestion);
                    return gameQuestion;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<GameQuestion> getAll() {
        return (Collection<GameQuestion>) findAll();
    }

    private GameQuestion extractGameQuestion(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        Long gameId = rs.getLong("game_id");
        Long questionId = rs.getLong("question_id");
        return new GameQuestion(id, gameId, questionId);
    }
}
