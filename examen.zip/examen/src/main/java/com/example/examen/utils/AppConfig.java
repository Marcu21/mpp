package com.example.examen.utils;

import com.example.examen.repository.*;
import com.example.examen.repository.db.QuestionDBRepository;
import com.example.examen.repository.db.GameQuestionDBRepository;
import com.example.examen.repository.db.GameAttemptDBRepository;
import com.example.examen.repository.hibernate.HibernateGameRepository;
import com.example.examen.repository.hibernate.HibernatePlayerRepository;
import com.example.examen.service.GameService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public PlayerRepository playerRepository() {
        return new HibernatePlayerRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public QuestionRepository questionRepository() {return new QuestionDBRepository();}

    @Bean
    public GameQuestionRepository gameQuestionRepository() {return new GameQuestionDBRepository();}

    @Bean
    public GameAttemptRepository gameAttemptRepository() {
        return new GameAttemptDBRepository();
    }

    @Bean
    public GameRepository gameRepository() {
        return new HibernateGameRepository(HibernateUtil.getSessionFactory());
    }

    @Bean
    public GameService gameService() {
        return new GameService(
                playerRepository(),
                gameRepository(),
                gameAttemptRepository(),
                questionRepository(),
                gameQuestionRepository()
        );
    }
}
