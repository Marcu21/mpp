package com.example.examen.domain;

import java.io.Serializable;

public class Question extends EntityID<Long> implements Serializable {

    private Long id;
    private String question;
    private String answer;
    private int nivel;

    public Question() {}

    public Question(Long id, String question, String answer, int nivel) {
        this.id = id;
        this.question = question;
        this.answer = answer;
        this.nivel = nivel;
    }

    public Question(Long id, String question, String answer) {
        this(id, question, answer, 1);
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }
}
