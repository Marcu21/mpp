package com.example.examen.service;

import com.example.examen.domain.*;
import com.example.examen.domain.dto.GameResultDTO;
import com.example.examen.networking.IGameObserver;
import com.example.examen.networking.IGameService;
import com.example.examen.repository.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

public class GameService implements IGameService {

    private final PlayerRepository playerRepo;
    private final GameRepository gameRepo;
    private final GameAttemptRepository attemptRepo;
    private final QuestionRepository questionRepo;
    private final GameQuestionRepository gameQuestionRepo;
    private final List<IGameObserver> observers = new ArrayList<>();

    private final Random random = new Random();

    public GameService(PlayerRepository playerRepo,
                       GameRepository gameRepo,
                       GameAttemptRepository attemptRepo,
                       QuestionRepository questionRepo,
                       GameQuestionRepository gameQuestionRepo) {
        this.playerRepo = playerRepo;
        this.gameRepo = gameRepo;
        this.attemptRepo = attemptRepo;
        this.questionRepo = questionRepo;
        this.gameQuestionRepo = gameQuestionRepo;
    }

    @Override
    public void addObserver(IGameObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(IGameObserver observer) {
        observers.remove(observer);
    }

    @Override
    public Game startGame(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            return null;
        }

        Game game = new Game(player.getId(), LocalDateTime.now());
        gameRepo.add(game);

        return game;
    }


    @Override
    public String makeAttempt(Long gameId, String playerAnswer) {
        Game game = gameRepo.findById(gameId);
        if (game == null || game.getEndTime() != null) {
            return "Jocul este deja finalizat sau inexistent.";
        }


        String result = procesareTrivia(game, playerAnswer);

        if (hasWonTriviaGame(gameId) || hasLostTriviaGame(gameId)) {
            game.setEndTime(LocalDateTime.now());
        }

        gameRepo.update(game);

        if (game.getEndTime() != null) {
            notifyGameFinished();
            return buildEndMessage(result, gameId);
        }

        return result;
    }


    private String procesareTrivia(Game game, String playerAnswer) {
        Question question = getLastQuestionForGame(game.getId());
        List<GameAttempt> attempts = getAttemptsForGame(game.getId());

        int correct = 0;
        int level = question.getNivel();
        int points;
        if(question.getAnswer().equals(playerAnswer)) {
            points = 4 * level * level;
            game.setScore(game.getScore() + points);
            correct = 1;
        }
        else {
            points = -2;
            game.setScore(game.getScore() + points);
        }


        GameAttempt attempt = new GameAttempt(
                game.getId(),
                playerAnswer,
                points
        );
        attemptRepo.add(attempt);

        if (correct == 1) {
            return "Raspuns corect pentru nivelul " + level + "! +" + points + " puncte";
        } else {
            return "Raspuns gresit pentru nivelul " + level + "! -2 puncte";
        }
    }




    private String buildEndMessage(String baseMessage, Long gameId) {
        Game game = gameRepo.findById(gameId);
        StringBuilder sb = new StringBuilder(baseMessage);
        sb.append("\nPunctaj final: ").append(game.getScore());

        return sb.toString();
    }

    private boolean hasWonTriviaGame(Long gameId) {
        List<Question> questions = getQuestionsForGame(gameId);
        List<GameAttempt> attempts = getAttemptsForGame(gameId);

        int[] correctPerLevel = new int[4];

        for (int i = 0; i < Math.min(attempts.size(), questions.size()); i++) {
            GameAttempt attempt = attempts.get(i);
            Question question = questions.get(i);

            int level = question.getNivel();
            if (attempt.getPoints() > 0) {
                correctPerLevel[level]++;
            }
        }

        return correctPerLevel[1] >= 2 && correctPerLevel[2] >= 2 && correctPerLevel[3] >= 2;
    }


    private boolean hasLostTriviaGame(Long gameId) {
        List<Question> questions = getQuestionsForGame(gameId);
        List<GameAttempt> attempts = getAttemptsForGame(gameId);

        int[] wrongPerLevel = new int[4];

        for (int i = 0; i < Math.min(attempts.size(), questions.size()); i++) {
            GameAttempt attempt = attempts.get(i);
            Question question = questions.get(i);

            int level = question.getNivel();
            if (attempt.getPoints() <= 0) {
                wrongPerLevel[level]++;
            }
        }

        return wrongPerLevel[1] >= 2 || wrongPerLevel[2] >= 2 || wrongPerLevel[3] >= 2;
    }



    @Override
    public List<GameResultDTO> getResultsForAllPlayers() {
        List<GameResultDTO> results = new ArrayList<>();

        for (Game game : gameRepo.findAll()) {
            if (game.getEndTime() == null) continue;

            Player player = playerRepo.findById(game.getPlayerId());
            List<Question> questions = getQuestionsForGame(game.getId());
            List<GameAttempt> attempts = getAttemptsForGame(game.getId());

            List<GameResultDTO.QuestionAnswerDTO> answerResults = new ArrayList<>();
            for (int i = 0; i < attempts.size(); i++) {
                Question q = questions.get(i);
                GameAttempt a = attempts.get(i);

                answerResults.add(new GameResultDTO.QuestionAnswerDTO(
                        q.getQuestion(),
                        a.getPlayerAnswer(),
                        a.getPoints()
                ));
            }

            long duration = Duration.between(game.getStartTime(), game.getEndTime()).getSeconds();

            results.add(new GameResultDTO(
                    game.getId(),
                    player.getAlias(),
                    game.getScore(),
                    duration,
                    answerResults
            ));
        }

        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Long.compare(a.getGameId(), b.getGameId());
        });

        return results;
    }


    @Override
    public List<GameResultDTO> getDetailedResultsForPlayer(String alias) {
        Player player = null;
        for (Player p : playerRepo.findAll()) {
            if (p.getAlias().equalsIgnoreCase(alias)) {
                player = p;
                break;
            }
        }

        if (player == null) {
            throw new RuntimeException("Jucator inexistent.");
        }

        List<GameResultDTO> results = new ArrayList<>();

        for (Game game : gameRepo.findAll()) {
            if (!game.getPlayerId().equals(player.getId())) continue;
            if (game.getEndTime() == null) continue;

            List<Question> questions = getQuestionsForGame(game.getId());
            List<GameAttempt> attempts = getAttemptsForGame(game.getId());

            List<GameResultDTO.QuestionAnswerDTO> answerResults = new ArrayList<>();
            for (int i = 0; i < attempts.size(); i++) {
                Question q = questions.get(i);
                GameAttempt a = attempts.get(i);

                answerResults.add(new GameResultDTO.QuestionAnswerDTO(
                        q.getQuestion(),
                        a.getPlayerAnswer(),
                        a.getPoints()
                ));
            }

            long duration = Duration.between(game.getStartTime(), game.getEndTime()).getSeconds();

            results.add(new GameResultDTO(
                    game.getId(),
                    player.getAlias(),
                    game.getScore(),
                    duration,
                    answerResults
            ));
        }

        results.sort((a, b) -> {
            int cmp = Integer.compare(b.getScore(), a.getScore());
            return cmp != 0 ? cmp : Long.compare(a.getDurationSeconds(), b.getDurationSeconds());
        });

        return results;
    }


    @Override
    public List<GameAttempt> getAttemptsForGame(Long gameId) {
        List<GameAttempt> attempts = new ArrayList<>();
        for (GameAttempt a : attemptRepo.findAll()) {
            if (a.getGameId().equals(gameId)) {
                attempts.add(a);
            }
        }
        return attempts;
    }

    @Override
    public List<Question> getQuestionsForGame(Long gameId) {
        Game game  = gameRepo.findById(gameId);
        if (game == null) {
            throw new RuntimeException("Joc inexistent.");
        }
        List<Question> questions = new ArrayList<>();
        for (GameQuestion gp : gameQuestionRepo.findAll()) {
            if (gp.getGameId().equals(gameId)) {
                Question question = questionRepo.findById(gp.getQuestionId());
                if (question != null) {
                    questions.add(question);
                }
            }
        }
        return questions;
    }

    public Question getLastQuestionForGame(Long gameId) {
        List<Question> questions = getQuestionsForGame(gameId);
        if (questions.isEmpty()) {
            return null;
        }
        return questions.get(questions.size() - 1);
    }

    private void notifyGameFinished() {
        for (IGameObserver observer : observers) {
            try {
                observer.scoreboardUpdated();
            } catch (Exception e) {
                System.err.println("Eroare notificare: " + e.getMessage());
            }
        }
    }


    public Question modifyQuestionForGame(Question updatedQuestion)
    {
        Question original = questionRepo.findById(updatedQuestion.getId());
        if (original == null) {
            throw new RuntimeException("Intrebarea nu exista");
        }

        original.setQuestion(updatedQuestion.getQuestion());
        original.setAnswer(updatedQuestion.getAnswer());
        original.setNivel(updatedQuestion.getNivel());

        questionRepo.update(original);
        return original;
    }

    public List<Question> getAllQuestions()
    {
        List<Question> questions = new ArrayList<>();
        for (Question q : questionRepo.findAll()) {
            questions.add(q);
        }
        return questions;
    }

    @Override
    public Question getNextQuestion(Long gameId) {
        List<GameAttempt> attempts = getAttemptsForGame(gameId);

        int[] correct = new int[4];
        int[] wrong = new int[4];

        for (int i = 0; i < attempts.size(); i++) {
            Question q = getQuestionsForGame(gameId).get(i);
            GameAttempt a = attempts.get(i);
            int level = q.getNivel();

            if (a.getPoints() > 0) {
                correct[level]++;
            } else {
                wrong[level]++;
            }
        }

        int currentLevel = 1;
        while (currentLevel <= 3 && correct[currentLevel] == 2) {
            currentLevel++;
        }

        if (currentLevel > 3 || wrong[currentLevel] == 2) {
            return null;
        }

        // intrebari primite
        Set<Long> answeredIds = new HashSet<>();
        List<Question> gameQuestions = getQuestionsForGame(gameId);
        for (int i = 0; i < attempts.size() && i < gameQuestions.size(); i++) {
            answeredIds.add(gameQuestions.get(i).getId());
        }


        // intrebari posibile
        List<Question> posible = new ArrayList<>();
        for (Question q : getAllQuestions()) {
            if (q.getNivel() == currentLevel && !answeredIds.contains(q.getId())) {
                posible.add(q);
            }
        }

        if (posible.isEmpty()) {
            return null;
        }

        Question selected = posible.get(new Random().nextInt(posible.size()));
        gameQuestionRepo.add(new GameQuestion(gameId, selected.getId()));
        return selected;
    }


}
