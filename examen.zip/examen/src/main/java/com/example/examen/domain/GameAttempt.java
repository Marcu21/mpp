package com.example.examen.domain;

import java.io.Serializable;

public class GameAttempt extends EntityID<Long> implements Serializable {

    private Long id;
    private Long gameId;
    private String playerAnswer;
    private int points;

    public GameAttempt() {}

    public GameAttempt(Long id, Long gameId, String playerAnswer, int points) {
        this.id = id;
        this.gameId = gameId;
        this.playerAnswer = playerAnswer;
        this.points = points;
    }

    public GameAttempt(Long gameId, String playerAnswer, int points) {
        this.gameId = gameId;
        this.playerAnswer = playerAnswer;
        this.points = points;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public String getPlayerAnswer() {
        return playerAnswer;
    }

    public void setPlayerAnswer(String playerAnswer) {
        this.playerAnswer = playerAnswer;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }
}
