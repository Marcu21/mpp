package com.example.examen.networking;

import com.example.examen.domain.Question;
import com.example.examen.domain.Game;
import com.example.examen.domain.GameAttempt;
import com.example.examen.domain.dto.GameResultDTO;

import java.util.List;

public interface IGameService {
    void addObserver(IGameObserver observer);
    void removeObserver(IGameObserver observer);

    Game startGame(String alias);
    String makeAttempt(Long gameId, String playerLetter);

    List<GameResultDTO> getResultsForAllPlayers();
    List<GameResultDTO> getDetailedResultsForPlayer(String alias);
    List<GameAttempt> getAttemptsForGame(Long gameId);
    List<Question> getQuestionsForGame(Long gameId);

    Question getNextQuestion(Long gameId);
}
