package com.example.examen.networking;

public interface IGameObserver {
    void scoreboardUpdated();
}