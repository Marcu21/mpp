package com.example.examen.server;

import com.example.examen.networking.RequestHandler;
import com.example.examen.repository.*;
import com.example.examen.repository.db.*;
import com.example.examen.repository.hibernate.HibernateGameRepository;
import com.example.examen.repository.hibernate.HibernatePlayerRepository;
import com.example.examen.service.GameService;
import com.example.examen.utils.HibernateUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerApp {
    private static final int PORT = 5555;

    public static void main(String[] args) {
        PlayerRepository playerRepo   = new HibernatePlayerRepository(HibernateUtil.getSessionFactory());
        QuestionRepository questionRepo     = new QuestionDBRepository();
        GameRepository gameRepo     = new HibernateGameRepository(HibernateUtil.getSessionFactory());
        GameAttemptRepository attemptRepo = new GameAttemptDBRepository();
        GameQuestionRepository gameQuestionRepo = new GameQuestionDBRepository();

        GameService service = new GameService(playerRepo, gameRepo, attemptRepo, questionRepo, gameQuestionRepo);

        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket client = server.accept();
                new Thread(new RequestHandler(service, client)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
