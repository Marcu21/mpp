package com.example.examen.domain.dto;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

public class GameResultDTO implements Serializable {

    private Long gameId;
    private String alias;
    private int score;
    private long durationSeconds;

    private List<QuestionAnswerDTO> results;

    public GameResultDTO(Long gameId,
                         String alias,
                         int score,
                         long duration,
                         List<QuestionAnswerDTO> results) {
        this.gameId = gameId;
        this.alias = alias;
        this.score = score;
        this.durationSeconds = duration;
        this.results = results;
    }

    public Long getGameId() { return gameId; }
    public String getAlias() { return alias; }
    public int getScore() { return score; }
    public long getDurationSeconds() {
        return durationSeconds;
    }
    public List<QuestionAnswerDTO> getResults() {
        return results;
    }

    public static class QuestionAnswerDTO implements Serializable {
        private String question;
        private String answer;
        private int points;

        public QuestionAnswerDTO() {}

        public QuestionAnswerDTO(String question, String answer, int points) {
            this.question = question;
            this.answer = answer;
            this.points = points;
        }
        public String getQuestion() {
            return question;
        }

        public String getAnswer() {
            return answer;
        }

        public int getPoints() {
            return points;
        }
    }
}
