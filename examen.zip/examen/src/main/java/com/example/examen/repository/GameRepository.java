package com.example.examen.repository;

import com.example.examen.domain.Game;

public interface GameRepository extends Repository<Game, Long> {
}
