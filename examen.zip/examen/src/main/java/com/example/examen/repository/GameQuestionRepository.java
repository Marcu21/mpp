package com.example.examen.repository;

import com.example.examen.domain.GameQuestion;

public interface GameQuestionRepository extends Repository<GameQuestion, Long>{
}

