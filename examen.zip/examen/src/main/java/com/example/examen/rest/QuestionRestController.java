package com.example.examen.rest;

import com.example.examen.domain.Question;
import com.example.examen.service.GameService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = { "http://localhost:5173", "http://localhost:5174", "http://localhost:5175" })
@RestController
@RequestMapping("/api/questions")
public class QuestionRestController {

    private final GameService gameService;

    public QuestionRestController(GameService gameService) {
        this.gameService = gameService;
    }

    @PutMapping
    public ResponseEntity<Question> modifyQuestion(@RequestBody Question updatedQuestion) {
        try {
            Question result = gameService.modifyQuestionForGame(updatedQuestion);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (RuntimeException ex) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
