package com.example.examen.repository;

import com.example.examen.domain.GameAttempt;

public interface GameAttemptRepository extends Repository<GameAttempt, Long> {
}