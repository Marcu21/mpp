package com.example.examen.domain;

import java.io.Serializable;

public class GameQuestion extends EntityID<Long> implements Serializable {

    private Long id;
    private Long gameId;
    private Long questionId;

    public GameQuestion() {}

    public GameQuestion(Long id, Long gameId, Long questionId) {
        setId(id);
        this.gameId = gameId;
        this.questionId = questionId;
    }

    public GameQuestion(Long gameId, Long questionId) {
        this.gameId = gameId;
        this.questionId = questionId;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public Long getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Long questionId) {
        this.questionId = questionId;
    }
}
