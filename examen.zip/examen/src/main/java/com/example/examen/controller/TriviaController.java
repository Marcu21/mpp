package com.example.examen.controller;

import com.example.examen.domain.Game;
import com.example.examen.domain.Question;
import com.example.examen.domain.dto.GameResultDTO;
import com.example.examen.networking.GameServiceProxy;
import com.example.examen.networking.IGameObserver;
import javafx.application.Platform;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class TriviaController implements IGameObserver {

    @FXML private TextField aliasField;
    @FXML private TextField raspunsField;
    @FXML private TextArea messageArea;
    @FXML private Label questionLabel;

    @FXML private TableView<GameResultDTO> leaderboardTable;
    @FXML private TableColumn<GameResultDTO, String> colAlias;
    @FXML private TableColumn<GameResultDTO, Integer> colScore;
    @FXML private TableColumn<GameResultDTO, Long> colDuration;

    private final GameServiceProxy service = new GameServiceProxy("localhost", 5555);

    private Long currentGameId = null;
    private String currentAlias = null;

    @FXML
    public void initialize() {
        initLeaderboardTable();
    }

    private void initLeaderboardTable() {
        colAlias.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getAlias()));
        colScore.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getScore()));
        colDuration.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getDurationSeconds()));
    }

    @FXML
    public void handleStartGame() {
        int ok = 1;
        if (currentAlias != null)
        {
            ok = 0;
        }
        currentAlias = aliasField.getText().trim();
        if (currentAlias.isEmpty()) {
            messageArea.setText("Introdu un alias valid.");
            return;
        }

        try {
            if(ok == 1) {
                service.addObserver(this);
            }

            Game game = service.startGame(currentAlias);
            if(game.getId() == null)
            {
                messageArea.setText("Jucatorul nu este inregistrat");
                return;
            }
            currentGameId = game.getId();

            messageArea.setText("Joc inceput!");
            loadNextQuestion();

            updateLeaderboard();
        } catch (Exception e) {
            messageArea.setText("Jucatorul nu este inregistrat");
        }
    }

    @FXML
    private void handleSubmit() {
        if (currentGameId == null) {
            messageArea.setText("Mai intai porneste un joc.");
            return;
        }

        String answer = raspunsField.getText().trim();
        if (answer.isEmpty()) {
            messageArea.setText("Scrie un raspuns inainte de a trimite");
            return;
        }

        try {
            String result = service.makeAttempt(currentGameId, answer);
            messageArea.setText(result);
            raspunsField.clear();

            if (result.contains("Punctaj")) {
                currentGameId = null;
                questionLabel.setText("Intrebarea apare aici...");
                updateLeaderboard();
            } else {
                loadNextQuestion();
            }

        } catch (Exception e) {
            messageArea.setText("Eroare la trimiterea raspunsului: " + e.getMessage());
        }
    }

    private void loadNextQuestion() {
        try {
            Question next = service.getNextQuestion(currentGameId);
            if (next != null) {
                questionLabel.setText(next.getQuestion());
            } else {
                questionLabel.setText("Nu mai sunt intrebari disponibile");
            }
        } catch (Exception e) {
            messageArea.setText("Eroare la incarcarea intrebarii: " + e.getMessage());
        }
    }

    private void updateLeaderboard() {
        try {
            List<GameResultDTO> results = service.getResultsForAllPlayers();
            leaderboardTable.getItems().setAll(results);
        } catch (Exception e) {
            messageArea.setText("Eroare la actualizarea clasamentului: " + e.getMessage());
        }
    }

    @Override
    public void scoreboardUpdated() {
        Platform.runLater(this::updateLeaderboard);
    }

    public void handleDisconnect() {
        try {
            service.removeObserver(this);
            messageArea.setText("Deconectare reusita.");
        } catch (Exception e) {
            messageArea.setText("Eroare la deconectare: " + e.getMessage());
        }
    }
}
