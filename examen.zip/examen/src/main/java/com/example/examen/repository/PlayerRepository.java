package com.example.examen.repository;

import com.example.examen.domain.Player;

public interface PlayerRepository extends Repository<Player, Long> {
}