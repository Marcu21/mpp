package com.example.examen.repository.db;

import com.example.examen.domain.Question;
import com.example.examen.repository.QuestionRepository;
import com.example.examen.utils.JdbcUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class QuestionDBRepository implements QuestionRepository {

    private static final Logger logger = LogManager.getLogger();
    private final JdbcUtils dbUtils;
    private final Connection con;

    public QuestionDBRepository() {
        logger.info("Initializing QuestionDBRepository");
        dbUtils = new JdbcUtils();
        con = dbUtils.getConnection();
    }

    @Override
    public void add(Question question) {
        logger.traceEntry("Saving question {}", question);
        String sql = "INSERT INTO Question (question, answer, nivel) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, question.getQuestion());
            stmt.setString(2, question.getAnswer());
            stmt.setInt(3, question.getNivel());
            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    question.setId(keys.getLong(1));
                }
            }

            logger.trace("Saved {}", question);
        } catch (SQLException ex) {
            logger.error("Error DB", ex);
            throw new RuntimeException("Error DB " + ex);
        }
        logger.traceExit();
    }

    @Override
    public Iterable<Question> findAll() {
        logger.traceEntry();
        List<Question> result = new ArrayList<>();
        String sql = "SELECT * FROM Question";

        try (PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Question question = extractQuestion(rs);
                result.add(question);
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit(result);
        return result;
    }

    @Override
    public void delete(Question question) {
        logger.traceEntry("Deleting question {}", question);
        String sql = "DELETE FROM Question WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, question.getId());
            stmt.executeUpdate();
            logger.trace("Deleted {}", question);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public void update(Question question) {
        logger.traceEntry("Updating question {}", question);
        String sql = "UPDATE Question SET question=?, answer=?, nivel=? WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, question.getQuestion());
            stmt.setString(2, question.getAnswer());
            stmt.setInt(3, question.getNivel());
            stmt.setLong(4, question.getId());
            stmt.executeUpdate();
            logger.trace("Updated {}", question);
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
    }

    @Override
    public Question findById(Long id) {
        logger.traceEntry("Finding question by id {}", id);
        String sql = "SELECT * FROM Question WHERE id=?";

        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Question question = extractQuestion(rs);
                    logger.traceExit(question);
                    return question;
                }
            }
        } catch (SQLException e) {
            logger.error("Error DB", e);
            throw new RuntimeException("Error DB " + e);
        }

        logger.traceExit();
        return null;
    }

    @Override
    public Collection<Question> getAll() {
        return (Collection<Question>) findAll();
    }

    private Question extractQuestion(ResultSet rs) throws SQLException {
        Long id = rs.getLong("id");
        String questionText = rs.getString("question");
        String answer = rs.getString("answer");
        int level = rs.getInt("nivel");
        return new Question(id, questionText, answer, level);
    }
}
