package com.example.examen.repository;

import com.example.examen.domain.Question;

public interface QuestionRepository extends Repository<Question, Long>{
}
